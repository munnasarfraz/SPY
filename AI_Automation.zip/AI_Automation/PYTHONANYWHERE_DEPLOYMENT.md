# PythonAnywhere Deployment Guide

## Prerequisites
- PythonAnywhere account (free or paid)
- Your Django project ready for deployment

## Step 1: Upload Your Project to PythonAnywhere

### Option A: Using Git (Recommended)
```bash
# On PythonAnywhere bash console
git clone https://github.com/yourusername/yourproject.git
cd yourproject
```

### Option B: Manual Upload
1. Zip your project folder
2. Upload via PythonAnywhere Files tab
3. Extract in your home directory

## Step 2: Set Up Virtual Environment

```bash
# Create virtual environment
python3.9 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install requirements
pip install -r requirements.txt
```

## Step 3: Configure Django Settings

1. **Update `core/settings_production.py`:**
   - Replace `yourusername` with your actual PythonAnywhere username
   - Replace `yourproject` with your actual project folder name

2. **Update `core/wsgi_production.py`:**
   - Replace `yourusername` with your actual PythonAnywhere username
   - Replace `yourproject` with your actual project folder name

## Step 4: Collect Static Files

```bash
# Activate virtual environment
source venv/bin/activate

# Collect static files
python manage.py collectstatic --settings=core.settings_production
```

## Step 5: Run Database Migrations

```bash
# Activate virtual environment
source venv/bin/activate

# Run migrations
python manage.py migrate --settings=core.settings_production

# Create superuser (optional)
python manage.py createsuperuser --settings=core.settings_production
```

## Step 6: Configure Web App

1. Go to **Web** tab on PythonAnywhere
2. Click **Add a new web app**
3. Choose **Manual configuration**
4. Select **Python 3.9** (or your preferred version)

### WSGI Configuration
Replace the WSGI file content with:

```python
import os
import sys

# Add your project directory to the sys.path
path = '/home/yourusername/yourproject'
if path not in sys.path:
    sys.path.append(path)

# Set the Django settings module for production
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings_production')

# Import Django WSGI application
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
```

### Virtual Environment
Set your virtual environment path:
```
/home/yourusername/yourproject/venv
```

## Step 7: Configure Static Files

1. Go to **Web** tab
2. Under **Static files**, add:
   - **URL**: `/static/`
   - **Directory**: `/home/yourusername/yourproject/staticfiles`

3. For media files, add:
   - **URL**: `/media/`
   - **Directory**: `/home/yourusername/yourproject/public/static`

## Step 8: Reload Web App

Click **Reload** button in the Web tab.

## Step 9: Test Your Application

Visit your PythonAnywhere URL:
```
https://yourusername.pythonanywhere.com
```

## Troubleshooting

### Common Issues:

1. **Import Errors**: Check that your virtual environment path is correct
2. **Static Files Not Loading**: Verify static files configuration and run `collectstatic`
3. **Database Errors**: Ensure migrations are run with production settings
4. **Permission Errors**: Check file permissions on PythonAnywhere

### Debug Mode:
If you need to debug, temporarily set `DEBUG = True` in `settings_production.py`

## Security Notes:

1. **Never commit production settings to version control**
2. **Use environment variables for sensitive data**
3. **Keep `DEBUG = False` in production**
4. **Regularly update dependencies**

## Performance Tips:

1. **Enable caching** if needed
2. **Use CDN** for static files
3. **Optimize database queries**
4. **Monitor memory usage**

## Support:

- PythonAnywhere Documentation: https://help.pythonanywhere.com/
- Django Deployment Documentation: https://docs.djangoproject.com/en/stable/howto/deployment/
