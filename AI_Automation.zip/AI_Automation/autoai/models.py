# Add import for Django models
from django.db import models
from django.contrib.auth.models import User

class JobAuditLog(models.Model):
    job = models.ForeignKey('Lab_1', on_delete=models.CASCADE, related_name='audit_logs')
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    event_type = models.CharField(max_length=100)  # e.g. 'step', 'start', 'end', 'error', 'manual_action'
    message = models.TextField(blank=True)
    step_name = models.CharField(max_length=200, blank=True, null=True)
    status = models.CharField(max_length=50, blank=True, null=True)  # e.g. 'success', 'fail'
    created_at = models.DateTimeField(auto_now_add=True)
    execution_id = models.CharField(max_length=100, blank=True, null=True)  # Unique execution identifier
    duration = models.DurationField(null=True, blank=True)  # Execution duration
    test_cases_total = models.IntegerField(default=0)  # Total test cases in execution
    test_cases_passed = models.IntegerField(default=0)  # Passed test cases
    test_cases_failed = models.IntegerField(default=0)  # Failed test cases
    test_cases_incomplete = models.IntegerField(default=0)  # Incomplete test cases
    environment = models.CharField(max_length=100, blank=True, null=True)  # Test environment
    browser_info = models.CharField(max_length=200, blank=True, null=True)  # Browser details
    error_details = models.TextField(blank=True, null=True)  # Detailed error information

    def __str__(self):
        return f"{self.job.job_name} - {self.event_type} - {self.created_at}"

    class Meta:
        ordering = ['-created_at']


class JobExecution(models.Model):
    """Detailed model for tracking individual job executions"""
    job = models.ForeignKey('Lab_1', on_delete=models.CASCADE, related_name='executions')
    execution_id = models.CharField(max_length=100, unique=True)  # Unique execution identifier
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    start_time = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=50, choices=[
        ('running', 'Running'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
        ('timeout', 'Timeout')
    ], default='running')
    
    # Execution statistics
    total_steps = models.IntegerField(default=0)
    passed_steps = models.IntegerField(default=0)
    failed_steps = models.IntegerField(default=0)
    skipped_steps = models.IntegerField(default=0)
    
    # Environment details
    environment = models.CharField(max_length=100, blank=True, null=True)
    browser_type = models.CharField(max_length=50, blank=True, null=True)
    browser_version = models.CharField(max_length=50, blank=True, null=True)
    
    # Error tracking
    error_message = models.TextField(blank=True, null=True)
    stack_trace = models.TextField(blank=True, null=True)
    
    # Performance metrics
    execution_duration = models.DurationField(null=True, blank=True)
    memory_usage = models.CharField(max_length=100, blank=True, null=True)
    
    def __str__(self):
        return f"{self.job.job_name} - {self.execution_id} - {self.status}"
    
    def get_duration(self):
        """Calculate execution duration"""
        if self.end_time and self.start_time:
            return self.end_time - self.start_time
        return None
    
    def get_success_rate(self):
        """Calculate success rate percentage"""
        if self.total_steps > 0:
            return round((self.passed_steps / self.total_steps) * 100, 2)
        return 0
    
    class Meta:
        ordering = ['-start_time']


class JobExecutionStep(models.Model):
    """Detailed tracking of individual steps within a job execution"""
    execution = models.ForeignKey(JobExecution, on_delete=models.CASCADE, related_name='steps')
    step_name = models.CharField(max_length=200)
    step_description = models.TextField(blank=True, null=True)
    step_order = models.IntegerField()
    
    # Step execution details
    start_time = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=50, choices=[
        ('pending', 'Pending'),
        ('running', 'Running'),
        ('passed', 'Passed'),
        ('failed', 'Failed'),
        ('skipped', 'Skipped'),
        ('blocked', 'Blocked')
    ], default='pending')
    
    # Step data
    input_data = models.TextField(blank=True, null=True)
    expected_result = models.TextField(blank=True, null=True)
    actual_result = models.TextField(blank=True, null=True)
    
    # Error details
    error_message = models.TextField(blank=True, null=True)
    screenshot_path = models.CharField(max_length=500, blank=True, null=True)
    
    # Performance
    duration = models.DurationField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.execution.execution_id} - Step {self.step_order}: {self.step_name}"
    
    def get_duration(self):
        """Calculate step duration"""
        if self.end_time and self.start_time:
            return self.end_time - self.start_time
        return None
    
    class Meta:
        ordering = ['step_order']


# Create your models here.
class Receipe_1(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null = True, blank=True)
    receipe_name = models.CharField(max_length=100)
    receipe_desciption = models.TextField()
    receipe_image = models.ImageField(upload_to="receipe")

class conf_1(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null = True, blank=True)
    browser_type = models.CharField(max_length=50, blank=True, null=True)
    speed = models.CharField(max_length=50, blank=True, null=True)
    waittime = models.CharField(max_length=50, blank=True, null=True)
    retry = models.CharField(max_length=50, blank=True, null=True)
    llm = models.CharField(max_length=100, blank=True, null=True)
    g_api_key = models.CharField(max_length=500, blank=True, null=True)
    ai_provider = models.CharField(max_length=100, default="gemini")
    project_id = models.IntegerField(blank=True, null=True)
    

class Project_1(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    project = models.CharField(max_length=100,blank=True, null=True)
    project_Type = models.CharField(max_length=100,blank=True, null=True)
    url = models.CharField(max_length=100,blank=True, null=True)
    active = models.BooleanField(default=True)
    email_Flag = models.BooleanField(default=True)
    email_IDs = models.CharField(max_length=100,blank=True, null=True)
    start_maximized = models.BooleanField(default=True)
    disable_extensions = models.BooleanField(default=False)
    ignore_certificate_errors = models.BooleanField(default=False)
    disable_popup_blocking = models.BooleanField(default=False)
    incognito = models.BooleanField(default=False)
    headless  = models.BooleanField(default=False)
    

class KeyWord_1(models.Model):
    keyword_Name = models.CharField(max_length=100,blank=True, null=True)
    keyword_Desc = models.TextField(blank=True, null=True)
    u = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    p = models.ForeignKey(Project_1, on_delete=models.SET_NULL, null=True, blank=True)

class Steps_1(models.Model):
    k = models.ForeignKey(KeyWord_1, on_delete=models.SET_NULL, null = True, blank=True)
    object_Name = models.CharField(max_length=100,blank=True, null=True)
    input_Value = models.CharField(max_length=100,blank=True, null=True)
    expected_Value = models.CharField(max_length=100,blank=True, null=True)
    action = models.CharField(max_length=100,blank=True, null=True)
    window_Type = models.CharField(max_length=100,blank=True, null=True)
    step_Descriptions = models.CharField(max_length=100,blank=True, null=True)
    
class MainBatch_1(models.Model):
    main_BatchName = models.CharField(max_length=100,blank=True, null=True)
    keyword_Data = models.CharField(max_length=100,blank=True, null=True)
    iteration_CountForSameData = models.CharField(max_length=100,blank=True, null=True)
    iteration_CountForDifferentData = models.CharField(max_length=100,blank=True, null=True)
    project_id = models.CharField(max_length=100,blank=True, null=True)
    isSkip = models.BooleanField(default=False)
    readOnly = models.BooleanField(default=False)
    remarks = models.CharField(max_length=200,blank=True, null=True)
  
class Suite_1(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null = True, blank=True)
    project_id = models.IntegerField(blank=True, null=True)
    suite_name = models.CharField(max_length=50,blank=True, null=True)
    suite_description = models.CharField(max_length=200,blank=True, null=True)
    execute = models.CharField(max_length=200,blank=True, null=True)
    priority = models.CharField(max_length=200,blank=True, null=True)
    language = models.CharField(max_length=200,blank=True, null=True)
    module = models.CharField(max_length=100,blank=True, null=True)
    build = models.CharField(max_length=100,blank=True, null=True)
    test_cycle = models.CharField(max_length=100,blank=True, null=True)
    test_env = models.CharField(max_length=100,blank=True, null=True)
    impact = models.CharField(max_length=100,blank=True, null=True)
    main_BatchName_id = models.CharField(max_length=100,blank=True, null=True)
    schedule_time = models.CharField(max_length=100,blank=True, null=True)
    remarks = models.CharField(max_length=100,blank=True, null=True)
    machine_name = models.CharField(max_length=100,blank=True, null=True)
    
class MyAppUser( models.Model ) :
    def __unicode__( self ) :
       return self.user.username

    user    = models.ForeignKey( User, on_delete=models.CASCADE )
    organization = models.TextField( blank = True )
    location = models.CharField( max_length = 150, blank = True ) 
    phone   = models.CharField( max_length = 135, blank = True )
    birth   = models.CharField( max_length = 50, blank = True )
    role = models.CharField( max_length = 135, blank = True )
    image = models.CharField( max_length = 135, blank = True )
    gender = models.CharField(max_length=50,blank=True, null=True)
    
class Report_1( models.Model ) :
    user    = models.ForeignKey( User, on_delete=models.CASCADE )
    project_id = models.IntegerField(blank=True, null=True)
    tcs_Name = models.CharField( max_length = 50, blank = True ) 
    status = models.BooleanField(default=True)
    test_Env = models.CharField( max_length = 100, blank = True )  
    time = models.DateTimeField(auto_now_add=True, blank=True)
    run_by = models.CharField( max_length = 100, blank = True )  
        
class Report_Steps_1( models.Model ) :
    r  = models.ForeignKey( Report_1, on_delete=models.CASCADE )
    project_id = models.IntegerField(blank=True, null=True)
    status = models.BooleanField(True, False, default = True)
    step_Description = models.CharField( max_length = 200, blank = True )
    actual_Value = models.CharField( max_length = 100, blank = True )  
    expected_Value = models.CharField( max_length = 100, blank = True )  
    time = models.DateTimeField(auto_now_add=True, blank=True)

class Lab_1( models.Model ) :
    user    = models.ForeignKey( User, on_delete=models.CASCADE )
    project_id = models.IntegerField(blank=True, null=True)
    job_name = models.CharField( max_length = 50, blank = True ) 
    job_id = models.CharField( max_length = 50, blank = True ) 
    datetime = models.DateTimeField(auto_now_add=True, blank=True)
    priority = models.CharField(max_length=200,blank=True, null=True)
    impact = models.CharField(max_length=200,blank=True, null=True)
    suits = models.CharField(max_length=200,blank=True, null=True)
    execution = models.CharField(max_length=200,blank=True, null=True)
    executiondate = models.DateTimeField(auto_now_add=True, blank=True)
    
class Data_Param_1( models.Model ) :
    k = models.ForeignKey(KeyWord_1, on_delete=models.SET_NULL, null = True, blank=True)
    var_Name = models.CharField(max_length=100,blank=True, null=True)
    var_Value = models.CharField(max_length=100,blank=True, null=True)
    var_AI = models.CharField(max_length=100,blank=True, null=True)
    ai_Prompt = models.TextField()
    llm_Model = models.CharField(max_length=100,blank=True, null=True)