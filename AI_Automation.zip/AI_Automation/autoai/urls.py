from django.urls import path
from . import views
from home.views import get_latest_alerts, get_latest_messages, mark_alert_read, mark_message_read

urlpatterns = [
    path('conf/<id>/', views.conf, name='conf'),
    path('suite/', views.suite, name='suite'),
    path('delete-suite/<id>/', views.delete_suite, name='delete_suite'),
    path('update-suite/<id>/', views.update_suite, name='update_suite'),
    
    path('execution/', views.execution, name='execution'),
    
    path('keyword/<id>/', views.keyword, name='keyword'),
    path('delete-keyword/<id>/<kid>/', views.delete_keyword, name='delete_keyword'),
    path('update-keyword/<id>/<kid>/', views.update_keyword, name='update_keyword'),
    path('kwd/', views.kwd, name='list_keyword'),
    path('updatekwd/<id>/', views.updatekwd, name='updatekwd'),
    path('deletekwd/<id>/', views.deletekwd, name='updatekwd'),
    
    path('batch/', views.batch, name='batch'),
    path('delete-batch/<id>/', views.delete_batch, name='delete_batch'),
    path('update-batch/<id>/', views.update_batch, name='update_batch'),
    
    path('project/', views.project, name='project'),
    path('delete-project/<id>/', views.delete_project, name='delete_project'),
    path('update-project/<id>/', views.update_project, name='update_project'),
    path('intermediate/', views.intermediate, name='intermediate'),
    path('report/', views.report, name='report'),
    path('report_steps/<id>/', views.report_steps, name='report_steps'),
    path('job/', views.add_job, name='add_job'),
    path('jobs/', views.show_jobs, name='show_jobs'),
    path('data-param/<id>/', views.data_param, name='data_param'),
    path('update_dataparam/<id>/<kid>/', views.update_dataparam, name='update_dataparam'),
    path('delete-dataparam/<id>/<kid>/', views.delete_dataparam, name='delete_dataparam'),
    
    # AJAX endpoints for real-time updates
    path('ajax/alerts/', get_latest_alerts, name='get_latest_alerts'),
    path('ajax/messages/', get_latest_messages, name='get_latest_messages'),
    path('ajax/alerts/<int:alert_id>/read/', mark_alert_read, name='mark_alert_read'),
    path('ajax/messages/<int:message_id>/read/', mark_message_read, name='mark_message_read'),
    
    path('job-hist/', views.job_history, name='job_history'),
    path('traceability-coverage/', views.traceability_coverage, name='traceability_coverage'),
    path('get-suite-components/<int:job_id>/', views.get_suite_components, name='get_suite_components'),
]