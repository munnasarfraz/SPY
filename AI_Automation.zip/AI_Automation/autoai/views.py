from django.shortcuts import render, redirect
import traceback
from django.core.paginator import EmptyPage, PageNotAnInteger

from .models import *

from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, PageNotAnInteger

import time
from selenium.common.exceptions import NoSuchElementException
from django.utils.timezone import now
import uuid
from datetime import datetime, timedelta
from django.utils import timezone

from django.test import LiveServerTestCase
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.edge.options import Options
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from django.shortcuts import render 
from django.http import JsonResponse 
import openai 
from .models import conf_1
import requests
import platform
# import google.generativeai as genai
import os
from django.conf import settings
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
os_type = platform.system()

openai.api_key = 'sk-proj-M6YBwAMxYni0RgRCjYhLT3BlbkFJC7zJl9B0RYRvrN5E9HLh'

from threading import Thread
from selenium.common.exceptions import (
    NoSuchElementException,
    InvalidSelectorException,
    InvalidArgumentException,
    WebDriverException
)

# Create your views here.
@login_required(login_url='/register/')
def keyword(request, id):
    print("request.method :", request.method)
    if request.method == "POST":
        data = request.POST
        object_Name = data.get('ObjectName')
        input_Value = data.get('InputValue')
        action = data.get('Action') 
        expected_Value = data.get('ExpectedValue')
        window_Type = data.get('WindowType')
        step_Descriptions = data.get('StepDescription')
        
        hidIndex = data.get('hidIndex')
        print('hidIndex-->', hidIndex)
        Steps_1.objects.create(
            object_Name = object_Name,
            input_Value = input_Value,
            action = action,
            expected_Value = expected_Value,
            window_Type = window_Type,
            step_Descriptions = step_Descriptions,
            k_id = id
            # project_id = request.session['project_id'],
            # user_id = request.session['user_id'],
            # name = request.session['component_name']
        )
        messages.success(request, "TCs rows added successfullt")
        return redirect('/keyword/'+id+'/')
    #context = {"page":'Add Recepi'}
    # print(request.session['component_name'])
    queryset = Steps_1.objects.filter(k_id=id)
    queryset1 = KeyWord_1.objects.get(id = id)
    #print(queryset1.query)
    # if request.session['component_name']!=None:
    #     queryset = KeyWord_1.objects.filter(name=request.session['component_name'])
    #     #print(queryset.query)
    # else:
    #     queryset = KeyWord_1.objects.all()
        
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    
    
    # if request.GET.get("Search"):
    #     print(request.GET.get("Search"))
    #     queryset = queryset.filter(receipe_name__icontains = request.GET.get("Search")) 


    context = {'keywords':queryset, 'component':queryset1}
    return render(request, 'autoai/keyword.html', context)

def keyword1(request, id):
    print("request.method :", request.method)
    #print(request.session['component_name'])
    queryset = Steps_1.objects.filter(k_id=id)
    
                
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    context = {'keywords':queryset, 'kwd_id':id}
    return render(request, '/autoai/keyword.html', context)


def delete_keyword(request, id, kid):
    queryset = Steps_1.objects.get(id=id)
    queryset.delete()
    #return HttpResponse("a")
    messages.error(request, "TCs rows deleted successfullt")
    return redirect('/autoai/keyword/'+kid+'/')

def update_keyword(request, id, kid):
    print(id)
    queryset = Steps_1.objects.get(id = id)
    queryset1 = KeyWord_1.objects.get(id = kid)
    #print(queryset.query)
    if request.method == "POST":
        data = request.POST
        
        object_Name = data.get('ObjectName')
        input_Value = data.get('InputValue')
        action = data.get('Action') 
        expected_Value = data.get('ExpectedValue')
        window_Type = data.get('WindowType')
        step_Descriptions = data.get('StepDescription')
        hidIndex = data.get('hidIndex')
                
        queryset.object_Name = object_Name
        queryset.input_Value = input_Value
        queryset.action = action
        queryset.window_Type = window_Type
        queryset.expected_Value = expected_Value
        queryset.step_Descriptions = step_Descriptions
                
        queryset.save()
        messages.success(request, "TCs rows updated successfullt")
        return redirect('/autoai/keyword/'+kid+'/')
    #if queryset.action.count
    
    context = {'keywords':queryset, 'component':queryset1}
    return render(request, '/autoai/keyword.html', context )

def batch(request):
    if request.method == "POST":
        data = request.POST
        mainBatchName = data.get('MainBatchName')
        batchData = request.POST.get('keywords')
        iterationSameData = data.get('IterationSameData')
        iterationDiffrentData = data.get('IterationDiffrentData') 
        skip = data.get('Skip')
        if skip==None:
            skip = 0
        else:
            skip = 1
        readOnly = data.get('ReadOnly')
        if readOnly==None:
            readOnly = 0
        else:
            readOnly = 1
        
        batchData.strip('[]').split(',')
        
        print('XXXXX=', batchData)
        batchData = batchData.replace('::::', ',')
        batchData = batchData.replace('::', '')
        print('XXXXX=', batchData)
    
        if iterationSameData==None or iterationSameData=='':
            iterationSameData = 0
        if iterationDiffrentData==None or iterationDiffrentData =='':
            iterationDiffrentData = 0
                
        MainBatch_1.objects.create(
            main_BatchName = mainBatchName,
            iteration_CountForSameData = iterationSameData,
            iteration_CountForDifferentData = iterationDiffrentData,
            isSkip = skip,
            readOnly = readOnly,
            keyword_Data = batchData,
            project_id = request.session['project_id']
        )
        messages.success(request, "main batch saved successfully")
        return redirect('/batch/')
    
    queryset = MainBatch_1.objects.filter(project_id=request.session['project_id'])
    #queryset1 = KeyWord_1.objects.filter(project_id=request.session['project_id'])
    queryset1 = KeyWord_1.objects.filter(p_id=request.session['project_id'], u_id=request.session['user_id'])
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    context = {'batch': queryset, 'kwd':queryset1}
    return render(request, 'autoai/mainbatch.html', context)


def delete_batch(request, id):
    queryset = MainBatch_1.objects.get(id = id)
    queryset.delete()
    #return HttpResponse("a")
    messages.error(request, "main batch deleted successfully")
    return redirect('/batch/')

def update_batch(request, id):
    queryset = MainBatch_1.objects.get(id = id)
    
    if request.method == "POST":
        data = request.POST
        mainBatchName = data.get('MainBatchName')
        iterationSameData = data.get('IterationSameData')
        iterationDiffrentData = data.get('IterationDiffrentData') 
        skip = data.get('Skip')
        if skip==None:
            skip = False
        else:
            skip = True
        print("SKIP=====", skip)
        readOnly = data.get('ReadOnly')
        if readOnly==None:
            readOnly = False
        else:
            readOnly = True
        print("READ ONLY=====", readOnly)
        batchData = data.get('BatchData')
        
        print("batchData -->", batchData)
        
        if iterationSameData==None or iterationSameData=='':
            iterationSameData = 0
        if iterationDiffrentData==None or iterationDiffrentData =='':
            iterationDiffrentData = 0
          
        queryset.main_BatchName = mainBatchName
        queryset.iteration_CountForSameData = iterationSameData
        queryset.iteration_CountForDifferentData = iterationDiffrentData
        queryset.isSkip = skip
        queryset.readOnly = readOnly
        queryset.keyword_Data = batchData
        queryset.project_id = request.session['project_id']
        #print("Session ===== ", queryset.query)
               
        queryset.save()
        messages.success(request, "main batch updated successfully")
        return redirect('/batch/')
    #if queryset.action.count
    queryset1 = KeyWord_1.objects.filter(p_id=request.session['project_id'], u_id=request.session['user_id'])
    context = {'batch':queryset, 'kwd':queryset1}
    return render(request, 'autoai/updatebatch.html', context )


@login_required(login_url='/register/')
def recepies(request):
    if request.method == "POST":
        data = request.POST
        
        receipe_image = request.FILES.get('receipe_image')
        receipe_name = data.get('receipe_name') 
        receipe_desciption = data.get('receipe_desciption')
        print(receipe_name)
        print(receipe_desciption)
        print(receipe_image)
        
        Receipe_1.objects.create(
            receipe_image= receipe_image,
            receipe_name= receipe_name,
            receipe_desciption= receipe_desciption,
        )
        
        return redirect('/recepies/')
    #context = {"page":'Add Recepi'}
    
    queryset = Receipe_1.objects.all()
    
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 2)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    
    # for Search ###################################################
    if request.GET.get("Search"):
        print(request.GET.get("Search"))
        queryset = queryset.filter(receipe_name__icontains = request.GET.get("Search")) 
    # for Search ###################################################

    context = {'recepies': queryset}
    return render(request, 'autoai/recepies.html', context)

def delete_recepi(request, id):
    print(id)
    queryset = Receipe_1.objects.get(id = id)
    queryset.delete()
    #return HttpResponse("a")
    return redirect('/recepies/')
    
def update_recepi(request, id):
    queryset = Receipe_1.objects.get(id = id)
    
    if request.method == "POST":
        data = request.POST
        
        receipe_image = request.FILES.get('receipe_image')
        receipe_name = data.get('receipe_name') 
        receipe_desciption = data.get('receipe_desciption')
                
        queryset.receipe_name = receipe_name
        queryset.receipe_desciption = receipe_desciption
        
        if receipe_image:
            queryset.receipe_image = receipe_image
        
        queryset.save()
        return redirect('/recepies/')
           
    context = {'recepie':queryset}
    return render(request, 'autoai/update_recepies.html', context )

def login_page(request):
    if request.method == 'POST':
        print('###############################')
        form_type = request.POST.get('form_type')

        if form_type == 'signin':
    
            username = request.POST.get('username')
            password = request.POST.get('password')
            xpassword = password
            print('Xpassword', xpassword)
            print(username, password)
            user = User.objects.filter(username = username)
            if not user.exists():
                print('Not Exist')
                messages.error(request, "username "+username+" not exist")
                return redirect('/login/')  
            user = authenticate(username = username, password=password)
            print('USER___', user)
            if user == None:
                messages.error(request, "Invalid password for user : "+username)
                pass
            else:
                
                queryset = Project_1.objects.filter(user_id=user.id)
                print('___D', queryset.count())
                if queryset.count()==0:
                    request.session['user_id'] = user.id
                    login(request, user)
                    return redirect('/intermediate/')  
                else:
                    value = request.POST.get('project_id') 
                    print("__A")
                    if value == None:
                        print("__B")
                        messages.success(request, "select domain to proceed login")
                        login(request, user)
                    else:
                        login(request, user)
                        print("__C")
                        #request.session['project_id'] = value
                        request.session['project_id'] = value
                        request.session['user_id'] = user.id
                        return redirect('/')  
                        
                    
                #request.session['username'] = username
                #return redirect('/login/')  
                
                #print(request.session['project_id'])
                context = {'query':queryset, 'xpwd':xpassword}
                return render(request, 'autoai/login.html', context )
            
                #return redirect('/')
    #return render(request, 'login_frm.html')
    return render(request, 'autoai/login.html')

def logout_page(request):
    try:
        logout(request)
        if request.session:
            request.session.clear()
    except:
        pass
    return redirect('/register/')
    

def register(request):
    print('###############################')

    form_type = request.POST.get('form_type')
    print('###############################', form_type)
    if form_type == 'signup':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        
        user = User.objects.filter(email = email)
        if user.exists():
            messages.error(request, "email "+str(email)+" allready taken")
            return redirect('/register/')

        user = User.objects.create(
            first_name = first_name,
            last_name = last_name,
            username = username,
            email = email
            )
        user.set_password(password)
        user.save()
        print('XVVVVVV_', user.pk)
        
        MyAppUser.objects.create(
            user_id = user.pk
        )
        messages.error(request, "User saved !")
        return redirect('/register/')
    elif form_type == 'signin':
        email = request.POST.get('email')
        password = request.POST.get('password')

        print("Email:", email)
        print("Password:", password)

        xpassword = password
        print('Xpassword', xpassword)

        try:
            user_obj = User.objects.get(email=email)
        except User.DoesNotExist:
            messages.error(request, f"Email {email} does not exist.")
            return redirect('/register/')
        print('###########_username', user_obj.username)
        # Use username (not email) for authenticate
        user = authenticate(username=user_obj.username, password=password)
        print('###########_user', user)

        if user is None:
            messages.error(request, f"Invalid password for user: {email}")
            return redirect('/register/')
        else:
            
            queryset = Project_1.objects.filter(user_id=user.id)
            print('___D', queryset.count())
            if queryset.count()==0:
                request.session['user_id'] = user.id
                login(request, user)
                return redirect('/intermediate/')  
            else:
                value = request.POST.get('project_id') 
                print("__value", value)
                if value == None:
                    print("__B")
                    messages.success(request, "select domain to proceed login")
                    login(request, user)
                else:
                    login(request, user)
                    print("__C")
                    #request.session['project_id'] = value
                    request.session['project_id'] = value
                    request.session['user_id'] = user.id
                    return redirect('/')  
                    
                
            #request.session['username'] = username
            #return redirect('/login/')  
            
            #print(request.session['project_id'])
            context = {'query':queryset, 'xpwd':xpassword}
            return render(request, 'autoai/register_frm.html', context )

    return render(request, 'autoai/register_frm.html')

def profile_update(request, id):
    queryset = User.objects.get(id = id) 
    queryset_1 = MyAppUser.objects.get(user_id = id)
    if request.method=="POST":
        # Handle profile photo upload if present
        if 'photo' in request.FILES:
            file_obj = request.FILES['photo']
            # Ensure avatars directory exists inside MEDIA_ROOT
            avatars_dir = os.path.join(settings.MEDIA_ROOT, 'avatars')
            os.makedirs(avatars_dir, exist_ok=True)
            safe_name = f"avatars/{id}_{int(time.time())}_{file_obj.name}"
            stored_path = default_storage.save(safe_name, ContentFile(file_obj.read()))
            # Store URL for template consumption
            queryset_1.image = settings.MEDIA_URL + stored_path
            queryset_1.save()
            messages.success(request, "Profile photo updated successfully!")
            return redirect('/profile/'+id+'/')

        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
           
        queryset.first_name = first_name
        queryset.last_name = last_name
        queryset.save()
        
        organization = request.POST.get('OrgName')
        location = request.POST.get('Location')
        phone = request.POST.get('Phone')
        birth = request.POST.get('Birth')
        role = request.POST.get('role')
        gender = request.POST.get('gender')
        
        queryset_1.organization = organization
        queryset_1.location = location
        queryset_1.phone = phone
        queryset_1.birth = birth
        queryset_1.role = role
        queryset_1.gender = gender
        queryset_1.save()
               
        messages.success(request, "Profile updated successfully!")
        return redirect('/profile/'+id+'/')
       
    
    context = {'users_1':queryset, 'appusers_1':queryset_1}
    return render(request, 'autoai/profile.html', context )
    
# def conf(request, id):
#     #queryset = userConfig.objects.get(id = id)
#     if request.method=="POST":

#         browser_type = request.POST.get("browser_type")
#         speed = request.POST.get("speed")
#         waittime = request.POST.get("waittime")
#         retry = request.POST.get("retry")
#         llm = request.POST.get("llm")
#         g_api_key = request.POST.get("g_api_key")
        
#         hiddentext = request.POST.get('hiddentext')
    
#         if speed is None:
#             speed = "off"
              
        
#         try:
#             queryset = conf_1.objects.get(id = id)
#             queryset.browser_type = browser_type
#             queryset.speed = speed
#             queryset.waittime = waittime
#             queryset.retry = retry
#             queryset.llm = llm
#             queryset.g_api_key = g_api_key
#             queryset.user_id = int(id)
#             queryset.project_id = int(request.session['project_id'])
#             queryset.save()
#             messages.error(request, "Configuration Updated !")
#             return redirect('/conf/'+id+'/')
#         except conf_1.DoesNotExist:
#             print('XXXXXX=', request.session['project_id'])
#             conf_1.objects.create(
#                 browser_type = browser_type,
#                 speed = speed,
#                 waittime = waittime,
#                 retry = retry,
#                 llm = llm,
#                 g_api_key = g_api_key,
#                 user_id = int(id),
#                 project_id = int(request.session['project_id'])
#                 )
#             messages.success(request, "Configuration saved !")
#             return redirect('/conf/'+id+'/')

#     queryset = conf_1.objects.filter(id = id)
#     if not queryset:
#         context = {'conf':""}        
#     else:
#         context = {'conf':queryset}
#     #print(queryset.query)
# # else:
# #         context = {'conf_1':""}
#     return render(request, 'Config.html', context )

def test_ai_response(ai_provider, api_key, prompt, llm):
    try:
        if ai_provider == "gemini":
            # url = "https://generativelanguage.googleapis.com/v1beta/models/{llm}:generateContent"
            model_map = {
                "gemini-2.0-flash": "models/gemini-1.5-flash-latest",  # map to valid endpoint model
                "gemini-1.5-flash": "models/gemini-1.5-flash-latest",
                "gemini-pro": "models/gemini-pro"
            }

            model_path = model_map.get(llm, "models/gemini-pro")  # default fallback
            url = f"https://generativelanguage.googleapis.com/v1beta/{model_path}:generateContent"


            headers = {"Content-Type": "application/json"}
            params = {"key": api_key}
            data = {
                "contents": [{
                    "parts": [{"text": prompt}]
                }]
            }
            response = requests.post(url, headers=headers, params=params, json=data)
            if response.status_code == 200:
                return True, "✅ Gemini is responding successfully!", "success"
            else:
                return False, f"❌ Gemini Error: {response.json().get('error', {}).get('message', 'Unknown error')}", "danger"

        elif ai_provider == "openai":
            url = "https://api.openai.com/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            data = {
                "model": {llm},
                "messages": [{"role": "user", "content": prompt}]
            }
            response = requests.post(url, headers=headers, json=data)
            if response.status_code == 200:
                return "✅ OpenAI is responding successfully!", "success"
            else:
                return f"❌ OpenAI Error: {response.json().get('error', {}).get('message', 'Unknown error')}", "danger"

        elif ai_provider == "deepseek":
            return "ℹ️ DeepSeek validation not implemented yet.", "warning"

        return "❓ Unknown AI provider.", "danger"

    except Exception as e:
        return f"❌ Exception occurred: {str(e)}", "danger"

@login_required(login_url='/register/')
def conf(request, id):
    if request.method == "POST":
        browser_type = request.POST.get("browser_type")
        speed = request.POST.get("speed") or "off"
        waittime = request.POST.get("waittime")
        retry = request.POST.get("retry")
        ai_provider = request.POST.get("ai_provider")
        llm = request.POST.get("llm")
        g_api_key = request.POST.get("g_api_key")

        # Check if Test Button was Clicked
        if "test_ai_connect" in request.POST:
            test_prompt = request.POST.get("test_prompt", "Say Hello!")

            # 🧠 Test AI API Key
            # ✅ This line must come before using `success`
            success, ai_test_result, ai_test_status = test_ai_response(ai_provider, g_api_key, test_prompt, llm)

            # ✅ Only now use `success`
            request.session['ai_connected_status'] = (
                f"{ai_provider.capitalize()}" if success else "❌ AI Connection Failed"
            )

            context = {
                "conf": {
                    "browser_type": browser_type,
                    "speed": speed,
                    "waittime": waittime,
                    "retry": retry,
                    "ai_provider": ai_provider,
                    "llm": llm,
                    "g_api_key": g_api_key
                },
                "project": {"project": None},
                "ai_test_result": ai_test_result,
                "ai_test_status": ai_test_status
            }
            return render(request, 'autoai/Config.html', context)

        # 🧩 Handle Save/Update
        try:
            queryset = conf_1.objects.get(id=id)
            queryset.browser_type = browser_type
            queryset.speed = speed
            queryset.waittime = waittime
            queryset.retry = retry
            queryset.ai_provider = ai_provider
            queryset.llm = llm
            queryset.g_api_key = g_api_key
            queryset.user_id = int(id)
            queryset.project_id = int(request.session['project_id'])
            queryset.save()
            messages.success(request, "Configuration Updated!")
        except conf_1.DoesNotExist:
            conf_1.objects.create(
                browser_type=browser_type,
                speed=speed,
                waittime=waittime,
                retry=retry,
                ai_provider=ai_provider,
                llm=llm,
                g_api_key=g_api_key,
                user_id=int(id),
                project_id=int(request.session['project_id'])
            )
            messages.success(request, "Configuration Saved!")

        return redirect('/conf/' + str(id) + '/')

    # GET Method
    queryset = conf_1.objects.filter(id=id).first()
    context = {'conf': queryset or "", 'project': {'project': None}}
    return render(request, 'autoai/Config.html', context)


def project(request):
    if request.method == "POST":
        data = request.POST
        project = data.get('project')
        project_Type = data.get('project_Type')
        url = data.get('url')
        active = data.get('active') 
        email_Flag = data.get('email_Flag')
        email_IDs = data.get('email_IDs')
        
        disable_extensions = data.get('disable_extensions')
        start_maximized = data.get('start_maximized')
        ignore_certificate_errors = data.get('ignore_certificate_errors')
        disable_popup_blocking = data.get('disable_popup_blocking')
        incognito = data.get('incognito')
        headless = data.get('headless')
        
        if disable_extensions == 'on': disable_extensions = True
        if disable_extensions == None: disable_extensions = False
            
        if start_maximized == 'on': start_maximized = True
        if start_maximized == None: start_maximized = False
              
        if ignore_certificate_errors == 'on': ignore_certificate_errors = True
        if ignore_certificate_errors == None: ignore_certificate_errors = False
        
        if disable_popup_blocking == 'on': disable_popup_blocking = True
        if disable_popup_blocking == None: disable_popup_blocking = False
        
        if incognito == 'on': incognito = True
        if incognito == None: incognito = False
        
        if headless == 'on': headless = True
        if headless == None: headless = False
        
                
        if active == None:
            active = 0
        else:
            active = 1
            
        if email_Flag == None:
            email_Flag = 0
        else:
            email_Flag = 1
            
        Project_1.objects.create(
            project = project,
            project_Type = project_Type,
            url = url,
            active = active,
            email_Flag = email_Flag,
            email_IDs = email_IDs,
            start_maximized = start_maximized,
            disable_extensions = disable_extensions ,           
            ignore_certificate_errors = ignore_certificate_errors,
            disable_popup_blocking = disable_popup_blocking,
            incognito = incognito,
            headless = headless,
            user_id = request.session['user_id']
        )
        print('YYYY-', Project_1.id)
        #request.session['project_id'] = 1
        #print('PROJ--', request.session['project_id'])

        messages.success(request, "Domain : "+ project +" added successfully")
        return redirect('/project/')
    
    queryset = Project_1.objects.filter(user_id=request.session['user_id'])
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 5)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    context = {'project': queryset}
    return render(request, 'autoai/project.html', context)

def delete_project(request, id):
    queryset = Project_1.objects.filter(id = id)
    queryset.delete()
    messages.error(request, "Domain deleted successfully")
    #return HttpResponse("a")
    return redirect('/project/')

def update_project(request, id):
    queryset = Project_1.objects.get(id = id)
    if request.method == "POST":
        data = request.POST
        project = data.get('project')
        project_Type = data.get('project_Type')
        url = data.get('url')
        active = data.get('active')
        email_Flag = data.get('email_Flag') 
        email_IDs = data.get('email_IDs')
        disable_extensions = data.get('disable_extensions')
        start_maximized = data.get('start_maximized')
        ignore_certificate_errors = data.get('ignore_certificate_errors')
        disable_popup_blocking = data.get('disable_popup_blocking')
        incognito = data.get('incognito')
        headless = data.get('headless')
        print('###########-',start_maximized)
        if active == None:
            active = 0
        else:
            active = 1
            
        if email_Flag == None:
            email_Flag = 0
        else:
            email_Flag = 1
            
        if disable_extensions == 'on': disable_extensions = True
        if disable_extensions == None: disable_extensions = False
        if start_maximized == 'on': start_maximized = True
        if start_maximized == None: start_maximized = False
        if ignore_certificate_errors == 'on': ignore_certificate_errors = True
        if ignore_certificate_errors == None: ignore_certificate_errors = False
        if disable_popup_blocking == 'on': disable_popup_blocking = True
        if disable_popup_blocking == None: disable_popup_blocking = False
        if incognito == 'on': incognito = True
        if incognito == None: incognito = False
        if headless == 'on': headless = True
        if headless == None: headless = False
              
        queryset.project = project
        queryset.project_Type = project_Type
        queryset.url = url
        queryset.active = active
        queryset.email_Flag = email_Flag 
        queryset.email_IDs = email_IDs
        queryset.start_maximized = start_maximized
        queryset.disable_extensions = disable_extensions          
        queryset.ignore_certificate_errors = ignore_certificate_errors
        queryset.disable_popup_blocking = disable_popup_blocking
        queryset.incognito = incognito
        queryset.headless = headless
        queryset.user_id = request.session['user_id']
        
        queryset.save()
        messages.success(request, "Domain : "+ project +" updated successfully")
        return redirect('/project/')
    context = {'project':queryset}
    return render(request, 'autoai/project.html', context )

def test_creation(request):

    return render(request, 'testcreation.html')

def suite(request):
    if request.method == "POST":
        data = request.POST
        
        suite_value =  data.getlist('suite_value')
        if suite_value != []:
            print('suite_value---', suite_value)
            pid = request.session['project_id']
            customfunction(request, pid, suite_value)
        else:
            suite_name = data.get('suite_name')
            main_BatchName_id = data.get('main_BatchName_id')
            module = data.get('module')
            test_cycle = data.get('test_cycle')
            build = data.get('build')
            priority = data.get('priority')
            impact = data.get('impact')
            # Prevent duplicate suite name for the same project
            if Suite_1.objects.filter(suite_name=suite_name, project_id=request.session['project_id']).exists():
                messages.error(request, "Suite name already exists for this project.")
            else:
                Suite_1.objects.create(
                    suite_name = suite_name,
                    main_BatchName_id = main_BatchName_id,
                    module = module,
                    test_cycle = test_cycle,
                    build = build,
                    priority = priority,
                    impact = impact,
                    project_id = request.session['project_id']
                )
                messages.success(request, "suite added successfully")
        return redirect('/suite/')
    
    queryset = Suite_1.objects.filter(project_id=request.session['project_id'])
    #queryset1 = MainBatch_1.objects.filter(project_id=request.session['project_id'])
    queryset1 = MainBatch_1.objects.filter(project_id=request.session['project_id'])
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)

    context = {'suite':queryset, 'batch':queryset1}
    #context = {'batch':queryset1}
    print(context)
    return render(request, 'autoai/suite.html', context)


def delete_suite(request, id):
    queryset = Suite_1.objects.get(id = id)
    queryset.delete()
    messages.error(request, "suite deleted successfully")
    #return HttpResponse("a")
    return redirect('/suite/')

def update_suite(request, id):
    queryset = Suite_1.objects.get(id = id)
    
    #print('$$$$$$', queryset.count())
    if request.method == "POST":
        data = request.POST
        suite_name = data.get('suite_name')
        main_BatchName_id = data.get('main_BatchName_id')
        module = data.get('module')
        test_cycle = data.get('test_cycle')
        build = data.get('build')
        priority = data.get('priority')
        impact = data.get('impact')
        
        queryset.suite_name = suite_name
        queryset.main_BatchName_id = main_BatchName_id
        queryset.module = module
        queryset.test_cycle = test_cycle
        queryset.build = build
        queryset.priority = priority
        queryset.impact = impact
        queryset.project_id = request.session['project_id']
        queryset.save()
        messages.success(request, "suite updated successfully")
        return redirect('/suite/')
    #if queryset.action.count
    context = {'suite':queryset}
    return render(request, 'autoai/updatesuite.html', context )


def execution(request):
    request.session['fav_color'] = 'blue'
    fav_color = request.session['fav_color']
    
    print('XXXXXXX_1', fav_color)
    # from django.test import LiveServerTestCase
    # from selenium import webdriver
    # from selenium.webdriver.common.keys import Keys
    # import time
    # import selenium
    # print("sample test case started")  
    # driver = webdriver.Chrome()  
    # driver.maximize_window()  
    # #navigate to the url  
    # driver.get("http://127.0.0.1:8000/")  
   
    # #elm = driver.find_element("name", "q")
    # time.sleep(2)
    # elm = driver.find_element("xpath", "//*[@id='exampleInputEmail1']")
    # highlight(elm)
    # elm.send_keys("munna")
    # time.sleep(2)
    # elm1 = driver.find_element("xpath", "//*[@id='exampleInputPassword1']")
    # highlight(elm1)
    # elm1.send_keys("Maryam@7712")
    # time.sleep(2)
    # elm2 = driver.find_element("xpath", "/html/body/div/form/button")
    # highlight(elm2)
    # time.sleep(2)
    # elm2.click()
    # elm.send_keys(Keys.TAB)
    # elm.send_keys(Keys.ENTER)
    # elm.click()
    # time.sleep(2)
    # elm3 = driver.find_element("xpath", "//*[@id='navbarSupportedContent']/form/a[2]")
    # highlight(elm3)
    # time.sleep(2)
    # elm3.click()
    
    #submit.send_keys(Keys.RETURN)
   
    return render(request, 'execution.html') 
    
def highlight(element):
    import time
    """Highlights (blinks) a Selenium Webdriver element"""
    driver = element._parent
    def apply_style(s):
        driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", element, s)
    original_style = element.get_attribute('style')
    apply_style("border: 2px solid red;")
    time.sleep(.3)
    apply_style(original_style)
    
def kwd(request):
    if request.method == "POST":
        component_Name = request.POST.get('ComponentName')
        Component_Desc = request.POST.get('ComponentDesc')
        
        component = KeyWord_1.objects.filter(keyword_Name = component_Name)
        if component.exists():
            messages.error(request, component_Name + ": Component already exist")
            return redirect('/kwd/') 
        else:
             KeyWord_1.objects.create(
                p_id = request.session['project_id'],
                u_id = request.session['user_id'],
                keyword_Name = component_Name,
                keyword_Desc = Component_Desc
             )
             messages.success(request, "component : " + component_Name + " added successfully")
        return redirect('/kwd/')
        
    queryset = KeyWord_1.objects.filter(p_id = request.session['project_id'],u_id = request.session['user_id'])
    #queryset = KeyWord_1.objects.all()
    print(queryset.query)
    
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    context = {'kwd': queryset}
    return render(request, 'autoai/kwd.html', context)

def updatekwd(request, id):
    queryset = KeyWord_1.objects.get(id = id)
    if request.method == "POST":
        data = request.POST
        queryset.keyword_Name = data.get('ComponentName')
        queryset.keyword_Desc = request.POST.get('ComponentDesc')
        queryset.save()
        messages.success(request, "component : " + data.get('ComponentName') + " updated successfully")
        return redirect('/kwd/')
    context = {'kwd':queryset}
    return render(request, 'autoai/updatekwd.html', context )

def deletekwd(request, id):
    queryset = KeyWord_1.objects.get(id = id)
    queryset.delete()
    print('-Deleted')
    messages.error(request, "component : " + queryset.keyword_Name + " deleted successfully")
    return redirect('/kwd/')

def customfunction(request, pid, suite_value):
    from django.test import LiveServerTestCase
    from selenium import webdriver
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.chrome.options import Options
    
    
    oProject = Project_1.objects.get(id=pid)
    s_url = oProject.url
    s_start_maximized = oProject.start_maximized
    s_disable_extensions = oProject.disable_extensions
    s_disable_popup_blocking = oProject.disable_popup_blocking
    s_ignore_certificate_errors = oProject.ignore_certificate_errors
    s_incognito = oProject.incognito
    s_headless = oProject.headless
        
    chrome_options = Options()
    if s_start_maximized:
        chrome_options.add_argument("--start-maximized")
    if s_disable_extensions:   
        chrome_options.add_argument("--disable-extensions")
    if s_disable_popup_blocking:
        chrome_options.add_argument("--disable-popup-blocking")
    if s_ignore_certificate_errors:
        chrome_options.add_argument("--ignore-certificate-errors")
    if s_incognito:
        chrome_options.add_argument("--incognito")
    if s_headless:
        chrome_options.add_argument("--headless")
    
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        driver.get(str(s_url))
    except:
        print("An exception occurred")
    #Suite_1.objects.bulk_create()
    
   
    
    # lSuite = suite_value.replace("'", "")
    # lSuite = lSuite.strip('[]').replace('"', '').replace(' ', '').split(',')
    # print('lSuite-', lSuite)
    # for i in lSuite:
    #     print('XXXXXX-',i)
    for oSuite in suite_value:
        print('########oSuite-->', oSuite)
        obj_Suite = Suite_1.objects.get(id=oSuite, project_id=request.session['project_id'])
        obj_MainBatch = MainBatch_1.objects.get(id=obj_Suite.main_BatchName_id, project_id=request.session['project_id'])
       # print('---> obj_MainBatch', obj_MainBatch.main_BatchName)
        obj_Keyword = KeyWord_1.objects.filter(p_id = request.session['project_id'])
        #obj_Steps = Steps_1.objects.filter(k_id=id)
        oMainBatch_Id = obj_Suite.main_BatchName_id
        oSuiteName = obj_Suite.suite_name
        oKeywordId = obj_MainBatch.keyword_Data
        
        rep_1 = Report_1.objects.create(
            project_id=request.session['project_id'],
            tcs_Name = oSuiteName,
            status = True,
            test_Env = '',
            time = now,
            user_id = request.session['user_id'],
            run_by = request.user   
            )
            
        # Update traceability matrix with test execution results
        from requirement.views import update_traceability_from_report
        update_traceability_from_report(rep_1)
        
        L1 = oKeywordId.replace("'", "")
        oKeywordList = L1.strip('[]').replace('"', '').replace(' ', '').split(',')
        #print('L1 ******- ', L1)
        #L2 = []
        try:
            for oList in oKeywordList:
                #print('$$$$$$----', oList)
                oSteps = Steps_1.objects.filter(k_id=int(oList))
                for oStep in oSteps:
                    # print('#######----', oStep.action)
                    fun_PageSync(driver, oStep)
                    if(oStep.action == "SetText"):
                        oStatus = fun_Settext(request, driver, oStep, rep_1.pk)
                        print('oStatus-', oStatus)
                        if not oStatus:
                            raise StopIteration
                    elif(oStep.action == "ButtonClick" or oStep.action.lower() == "click"):
                        oStatus = fun_Buttonclick(request, driver, oStep, rep_1.pk)
                        if not oStatus:
                            obj = Report_1.objects.get(id=rep_1.pk)
                            obj.status = False
                            obj.save()
                            #raise StopIteration
                    elif(oStep.action=="VerifyNonEditableText"):
                        oStatus = fun_VerifyNonEditableText(request, driver, oStep, rep_1.pk)
                        if not oStatus:
                            obj = Report_1.objects.get(id=rep_1.pk)
                            obj.status = False
                            obj.save()
                            #raise StopIteration
                    elif(oStep.action == "SelectListItem"):
                        oStatus = fun_SelectListItem(request, driver, oStep, rep_1.pk)
                        # if not oStatus:
                        #     raise StopIteration
                    
        except StopIteration:
            pass
                            
                
    
    # for oSuite in obj_Suite:
    #     print('*** Suite Id/Name - - ', oSuite.main_BatchName_id +'/'+oSuite.suite_name)
    #     for oMain in obj_MainBatch:
    #         print('*** Main name/Data - - ', oMain.main_BatchName +'/'+oMain.keyword_Data)
            

    
    
    # oMainBatch = obj_MainBatch.filter(id=obj_Suite.main_BatchName_id)
    # oKeyword = obj_Keyword.filter(id=oMainBatch.keyword_Data)
    # for oKey in oKeyword:
    #     print(oKey)
        
    
   
    # queryset = Project_1.objects.filter(id=pid)
    # s_url = queryset[0].url
    # print('EXEC-:'+s_url)
    # driver = webdriver.Chrome()  
    # driver.maximize_window()  
    
    # chrome_options = Options()
    # chrome_options.add_argument("--disable-extensions")
    # chrome_options.add_argument("--start-maximized")
    # chrome_options.add_argument("--ignore-certificate-errors")
    # chrome_options.add_argument("--disable-popup-blocking")
    # chrome_options.add_argument("--incognito")
    
    # driver = webdriver.Chrome(options=chrome_options)
    # try:
    #     driver.get(str(s_url))
    # except:
    #     print("An exception occurred")
    # #navigate to the url  
    # # driver.get('http://google.com')
    # Steps_1.objects.filter()
    # time.sleep(5)
    # elm = driver.find_element("name", "q")
    # time.sleep(2)
    # highlight(elm)
    # elm.send_keys("Munna Sarfraz")
    # time.sleep(2)
    # elm.send_keys(Keys.RETURN)
    
    return redirect('/suite/')
def fun_PageSync(driver, oStep):
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import TimeoutException
    from selenium.webdriver.common.by import By
    delay = 10 # seconds
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, oStep.object_Name)))
        #print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
        

def fun_Object_Identify(driver, oStep):
    try:
        return driver.find_element("name", oStep.object_Name)
    except (NoSuchElementException, InvalidSelectorException, InvalidArgumentException, WebDriverException) as e:
        print(f"Name locator failed: {e}")

    try:
        return driver.find_element("id", oStep.object_Name)
    except (NoSuchElementException, InvalidSelectorException, InvalidArgumentException, WebDriverException) as e:
        print(f"ID locator failed: {e}")

    try:
        return driver.find_element("xpath", oStep.object_Name)
    except (NoSuchElementException, InvalidSelectorException, InvalidArgumentException, WebDriverException) as e:
        print(f"XPath locator failed: {e}")

    print(f"Element not found using name, id, or xpath: {oStep.object_Name}")
    return None


def is_enclosed_by_angle_brackets(s):
    return s.startswith('<') and s.endswith('>')

def remove_angle_brackets(tmp_input_value):
    if tmp_input_value.startswith('<') and tmp_input_value.endswith('>'):
        return tmp_input_value[1:-1]
    return tmp_input_value

def fun_Navigate(request, driver, oStep, rid):
    oStatus = False
    input_value = ""
    oElement = fun_Object_Identify(driver, oStep)
    print('********** KID', oStep.k_id)
    print('********** request.session[is_AI]', request.session['is_AI'])
    if request.session['is_AI'] =="1":
        input_value = prompt_engineering_services(request, oStep)
    else:
        input_value = oStep.input_Value
        
        
    try:
        time.sleep(2)
        highlight(oElement)
        oElement.send_keys(input_value.strip())
        oStatus = True
    except NoSuchElementException:
            #print("No element found. Breaking...")
            oStatus = False
    # except:
    #     oStatus = False
    except Exception as e: print(e)
    
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], actual_Value=input_value, expected_Value=oStep.expected_Value, step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    return oStatus   



def fun_Settext(request, driver, oStep, rid):
    oStatus = False
    input_value = ""
    oElement = fun_Object_Identify(driver, oStep)
    print('********** KID', oStep.k_id)
    print('********** request.session[is_AI]', request.session['is_AI'])
    if request.session['is_AI'] =="1":
        input_value = prompt_engineering_services(request, oStep)
    else:
        input_value = oStep.input_Value
        
        
    try:
        time.sleep(2)
        highlight(oElement)
        oElement.send_keys(input_value.strip())
        oStatus = True
    except NoSuchElementException:
            #print("No element found. Breaking...")
            oStatus = False
    # except:
    #     oStatus = False
    except Exception as e: print(e)
    
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], actual_Value=input_value, expected_Value=oStep.expected_Value, step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    return oStatus   

def prompt_engineering_services(request, oStep):
    return_Value = ""
    print('########## TEXT ', oStep.input_Value)
    print('########## is Text', is_enclosed_by_angle_brackets(oStep.input_Value))
    if is_enclosed_by_angle_brackets(oStep.input_Value):
        oDataParam = Data_Param_1.objects.get(k_id = oStep.k_id, var_Name = oStep.input_Value)
        if request.session['is_AI'] =="1":
            print('########## Project Id', int(request.session['project_id']))
            oConfig = get_Config(request, int(request.session['project_id']))
            print('########## API Key', oConfig[5])
            #print('########## LLM', oConfig[4])
            print(oStep.k_id)
            print(oStep.input_Value)
            
            print('########## LLM', oConfig[4])
            print('########## PROMPT', oDataParam.ai_Prompt)
            try:
                # genai.configure(api_key=oConfig[5])
                # model = genai.GenerativeModel(oConfig[4])
                # response = model.generate_content(oDataParam.ai_Prompt)
                # print('############# AI Response',response.text)  
                pass 
            except Exception as e: print(e)
            return_Value = response.text
        if request.session['is_AI'] =="0":
            return_Value = oDataParam.var_Value
            
    else:
        return_Value = oStep.input_Value   
    
    return return_Value


def fun_SelectListItem(request, driver, oStep, rid):
    oStatus = False
    oElement = fun_Object_Identify(driver, oStep)
    try:
        time.sleep(1)
        highlight(oElement)
        select = Select(oElement)
        select.select_by_visible_text(oStep.input_Value)
        oStatus = True
    except NoSuchElementException:
            #print("No element found. Breaking...")
            oStatus = False
    except:
        oStatus = False
        
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], actual_Value=oStep.input_Value, expected_Value=oStep.expected_Value, step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    return oStatus    
        
def fun_VerifyNonEditableText(request, driver, oStep, rid):
    oStatus = False
    oElement = fun_Object_Identify(driver, oStep)
    oActualValue = ""
    time.sleep(5)
    try:
        time.sleep(2)
        highlight(oElement)
        oActualValue = oElement.text
        print('ACTUALVALUE:',oActualValue)
        print('EXPECTEDVALUE:',oStep.expected_Value)
        if oStep.expected_Value == oActualValue: 
            print('TRUEEEEE')
            oStatus = True
        else:
            oStatus = False
            print('FALSEEEEE')
    except NoSuchElementException:
            #print("No element found. Breaking...")
            #print('NO ELM EXCEPTIONNNNNNNN')
            oStatus = False
    except:
        oStatus = False
        #print('EXCEPTIONNNNNNNN')
        
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], actual_Value=oStep.input_Value, expected_Value=oStep.expected_Value, step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    return oStatus    


def fun_Buttonclick(request, driver, oStep, rid):
    oStatus = False
    oElement = fun_Object_Identify(driver, oStep)
    if oElement:
        print('oElement - ', oElement)
    else:
        print('oElement - ', 'Not found')
    
    
    try:
        highlight(oElement)
        time.sleep(2)
        oElement.click()
        #time.sleep(7)
    
        oStatus = True
    except NoSuchElementException:
            print("No element found. Breaking...")
            oStatus = False
            pass
    except Exception as e: print(e)
    # except:
    #     oStatus = False
    #     pass
    #     print('XXXXXXXXXX-Fail')
    
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    print('RETURN STATUS - ', oStatus)
    return oStatus  



def intermediate(request ):
    #context = {'sarfraz': "sarfraz"}
    return render(request, 'intermediate.html')
        
    
  
def report(request):
    # if request.method == "POST":
    #     data = request.POST
        
    #     suite_value =  data.getlist('suite_value')
    #     if suite_value != []:
    #         pid = request.session['project_id']
    #         customfunction(request, pid, suite_value)
    #     else:      
    #         suite_name = data.get('suite_name')
    #         main_BatchName_id = data.get('main_BatchName_id')
    #         module = data.get('module')
    #         test_cycle = data.get('test_cycle')
    #         build = data.get('build')
    #         priority = data.get('priority')
    #         impact = data.get('impact')
    #         Suite_1.objects.create(
    #             suite_name = suite_name,
    #             main_BatchName_id = main_BatchName_id,
    #             module = module,
    #             test_cycle = test_cycle,
    #             build = build,
    #             priority = priority,
    #             impact = impact,
    #             project_id = request.session['project_id']
    #             # user_id = request.session['project_id']
    #         )
    #         messages.success(request, "suite added successfully")
    #     return redirect('/suite/')
    
    queryset = Report_1.objects.filter(project_id=request.session['project_id']).order_by('-time')
    
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 14)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)

    context = {'report':queryset}
    return render(request, 'autoai/report.html', context)

def report_steps(request, id):
    # queryset = Report_1.objects.get(id=id, project_id=request.session['project_id'])
    queryset = Report_1.objects.get(id=id)
    queryset1 = Report_Steps_1.objects.filter(r_id=id, project_id=request.session['project_id']).order_by('id')
    page = request.GET.get('page',1)
    paginator = Paginator(queryset1, 100)
    try:
        queryset1 = paginator.page(page)
    except PageNotAnInteger:
        queryset1 = paginator.page(1)
    except EmptyPage:
        queryset1 = paginator.page(paginator.num_pages)
    
    context = {'report':queryset, 'report_steps':queryset1}
    return render(request, 'autoai/report_steps.html', context)


def add_job(request):
    queryset = Suite_1.objects.filter(project_id=request.session['project_id'])    
    
    if request.method == "POST":
        data = request.POST
        print("DEBUG: POST data received:")
        print(f"  jobname: {data.get('jobname')}")
        print(f"  jobid: {data.get('jobid')}")
        print(f"  datetime: {data.get('datetime')}")
        print(f"  priority: {data.get('priority')}")
        print(f"  impact: {data.get('impact')}")
        print(f"  suites: {data.get('suites')}")
        
        sValue = data.get('suites')
        if sValue:
            # Format: SuiteName#SuiteID::::SuiteName#SuiteID
            # Convert to: SuiteName#SuiteID,SuiteName#SuiteID
            sValue = sValue.replace('::::', ',')
            print(f"DEBUG: Processed suites: {sValue}")
        else:
            print("DEBUG: No suites data received")
            sValue = ""
            
        job_name = data.get('jobname')
        job_id = data.get('jobid')
        datetime = data.get('datetime')
        priority = data.get('priority')
        impact = data.get('impact')
        
        # Validate required fields
        if not job_name:
            messages.error(request, "Job name is required")
            return redirect('/job/')
        if not job_id:
            messages.error(request, "Job ID is required")
            return redirect('/job/')
        if not datetime:
            messages.error(request, "Scheduled date/time is required")
            return redirect('/job/')
        if not priority:
            messages.error(request, "Priority is required")
            return redirect('/job/')
        if not impact:
            messages.error(request, "Impact is required")
            return redirect('/job/')
        
        job = Lab_1.objects.filter(job_name = job_name)
        print('ooooooo-', job)
        if job.exists():
            messages.error(request, "Job "+job_name+" allready exists")
            return redirect('/job/') 
        
        print("DEBUG: Creating job with data:")
        print(f"  job_name: {job_name}")
        print(f"  job_id: {job_id}")
        print(f"  datetime: {datetime}")
        print(f"  priority: {priority}")
        print(f"  impact: {impact}")
        print(f"  suits: {sValue}")
        print(f"  project_id: {request.session['project_id']}")
        print(f"  user_id: {request.session['user_id']}")
        
        Lab_1.objects.create(
            job_name = job_name,
            job_id = job_id,
            datetime = datetime,
            priority = priority,
            impact = impact,
            suits = sValue,
            project_id = request.session['project_id'],
			user_id = request.session['user_id']
        )
        messages.success(request, "Job  : " + job_name + " created successfully")
        # queryset.keyword_Name = data.get('suites')
        # queryset.keyword_Desc = request.POST.get('ComponentDesc')
        # queryset.save()
         
        # return redirect('/kwd/')
    context = {'Suite':queryset}
    return render(request, 'autoai/lab.html', context)

def get_Config(request, id):
    print('********** id', id)  
    oConf = conf_1.objects.filter(project_id=id).last()
    s_browser_type = oConf.browser_type
    s_Speed = oConf.speed
    s_Waittime = oConf.waittime
    s_Retry = oConf.retry
    s_llm = oConf.llm
    s_api_key = oConf.g_api_key
    
    tmpList = (s_browser_type , s_Speed, s_Waittime, s_Retry, s_llm, s_api_key)
    print('********** Tupple', tuple(tmpList))
    print('********** Browser', tuple(tmpList)[0])
    return tuple(tmpList)

def redirect_page(request):
    response = redirect('show_jobs')
    return response

def show_jobs(request):
    print('########## Sarfraz  - inside show jobs')
        # Handle both POST (search form) and GET (pagination with search params)
    if request.method == "POST" or (request.method == "GET" and any(param in request.GET for param in ['jobname', 'jobid', 'datetime', 'priority', 'impact', 'status'])):
        # Use POST data for form submissions, GET data for pagination
        data = request.POST if request.method == "POST" else request.GET

        # Distinguish job execution POST from search POST
        if request.method == "POST" and 'job_execute' in data:
            # Handle job execution
            suite_value =  data.getlist('suite_value')
            print('********** suite_value', suite_value)
            is_AI =  data.get('isAI')
            print('CCCCCCCCCCCCCC', is_AI)

            request.session['is_AI'] = is_AI

            pid = request.session['project_id']
            print('********** pid', pid)

            try:
                if suite_value != []:
                    runjob(request, pid, suite_value)
                    print('Thread Started')
                    return redirect('show_jobs')
            except:
                pass
                print('Print Exception')
        else:
            # Handle search functionality
            try:
                queryset = Lab_1.objects.filter(project_id=request.session['project_id'])

                # Apply search filters
                jobname = data.get('jobname', '').strip()
                if jobname:
                    queryset = queryset.filter(job_name__icontains=jobname)

                jobid = data.get('jobid', '').strip()
                if jobid:
                    queryset = queryset.filter(job_id__icontains=jobid)

                datetime_search = data.get('datetime', '').strip()
                if datetime_search:
                    queryset = queryset.filter(datetime__icontains=datetime_search)

                priority = data.get('priority', '').strip()
                if priority:
                    queryset = queryset.filter(priority__icontains=priority)

                impact = data.get('impact', '').strip()
                if impact:
                    queryset = queryset.filter(impact__icontains=impact)

                status = data.get('status', '').strip()
                if status:
                    # Map user-friendly status names to database values
                    status_mapping = {
                        'Not Executed': ['1', ''],
                        'In-Progress': ['In-Progress'],
                        'Completed': ['Completed']
                    }

                    if status in status_mapping:
                        queryset = queryset.filter(execution__in=status_mapping[status])
                    else:
                        # If exact match not found, try partial match
                        queryset = queryset.filter(execution__icontains=status)

                queryset = queryset.order_by('-datetime')

            except Exception as e:
                print(f"Search error: {e}")
                # Fallback to showing all jobs if search fails
                queryset = Lab_1.objects.filter(project_id=request.session['project_id']).order_by('-datetime')

            # Pagination for search results
            page = request.GET.get('page',1)
            paginator = Paginator(queryset, 12)
            try:
                queryset = paginator.page(page)
            except PageNotAnInteger:
                queryset = paginator.page(1)
            except EmptyPage:
                queryset = paginator.page(paginator.num_pages)

            # Pass search parameters back to template to maintain form values
            search_params = {
                'jobname': jobname,
                'jobid': jobid,
                'datetime': datetime_search,
                'priority': priority,
                'impact': impact,
                'status': status
            }
            context = {'job': queryset, 'search_params': search_params}
            return render(request, 'autoai/jobs.html', context)
    
    # Default view - show all jobs
    queryset = Lab_1.objects.filter(project_id=request.session['project_id']).order_by('-datetime')
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 12)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
        
    context = {'job':queryset}
    return render(request, 'autoai/jobs.html', context)

import shutil
import subprocess
def error_404(request, exception):
    return render(request, 'home/error_404.html', status=404)
 
def error_500(request):
    return render(request, 'home/error_505.html', status=500)

def is_chrome_installed():
    return shutil.which("google-chrome") is not None

def install_chrome():
    print("🔧 Installing Google Chrome...")
    try:
        subprocess.run([
            "wget", "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb"
        ], check=True)
        subprocess.run([
            "sudo", "apt", "install", "./google-chrome-stable_current_amd64.deb", "-y"
        ], check=True)
        print("✅ Chrome installed successfully.")
    except subprocess.CalledProcessError as e:
        print("❌ Failed to install Chrome:", e)
        exit(1)

def find_chrome_binary():
    candidates = [
        "google-chrome",
        "chromium-browser",
        "chromium",
        "/snap/bin/chromium",
        "/usr/bin/google-chrome",
        "/usr/bin/chromium-browser",
        "/usr/bin/chromium",
    ]
    for candidate in candidates:
        path = shutil.which(candidate)
        if path:
            return path
    return None
def invoke_Browser(request, pid):
    try:
        import uuid
        print('********** Invoke Browser PID:', pid)
        
        # Load project-specific browser config
        oProject = Project_1.objects.get(id=pid)
        s_url = oProject.url
        s_start_maximized = oProject.start_maximized
        s_disable_extensions = oProject.disable_extensions
        s_disable_popup_blocking = oProject.disable_popup_blocking
        s_ignore_certificate_errors = oProject.ignore_certificate_errors
        s_incognito = oProject.incognito
        s_headless = oProject.headless

        browser_type = get_Config(request, pid)
        browser_name = browser_type[0] if browser_type else "Chrome"

        driver = None
        user_data_dir = None  # Track temp dir for cleanup (optional)

        if browser_name == "Chrome":
            # Check Chrome installation
            # if not is_chrome_installed():
            #     install_chrome()
            
            options = Options()
           
            # Apply all selected options
            if s_start_maximized:
                options.add_argument("--start-maximized")
            if s_disable_extensions:
                options.add_argument("--disable-extensions")
            if s_disable_popup_blocking:
                options.add_argument("--disable-popup-blocking")
            if s_ignore_certificate_errors:
                options.add_argument("--ignore-certificate-errors")
            if s_incognito:
                options.add_argument("--incognito")
            if s_headless:
                options.add_argument("--headless")
            
            if os_type == "Linux":
                options.add_argument('--no-sandbox')
                options.add_argument('--disable-dev-shm-usage')
                driver = webdriver.Chrome(options=options)
            else:
                driver = webdriver.Chrome()

        elif browser_name == "Edge":
            print('********** Launching Edge')

            edge_options = Options()

            if s_start_maximized:
                edge_options.add_argument("--start-maximized")
            if s_disable_extensions:
                edge_options.add_argument("--disable-extensions")
            if s_disable_popup_blocking:
                edge_options.add_argument("--disable-popup-blocking")
            if s_ignore_certificate_errors:
                edge_options.add_argument("--ignore-certificate-errors")
            if s_incognito:
                edge_options.add_argument("--incognito")
            if s_headless:
                edge_options.add_argument("--headless")

            driver = webdriver.Edge(options=edge_options)

        # ✅ Navigate to URL with page load check
        if driver:
            try:
                driver.get(str(s_url))
                WebDriverWait(driver, 100).until(lambda d: d.execute_script('return document.readyState') == 'complete')
                driver.implicitly_wait(1)
            except Exception as e:
                print("⚠️ Page load exception in invoke_Browser:", e)

        return driver

    except Exception as e:
        print("❌ Error occurred in invoke_Browser:", e)
        return None
# def invoke_Browser(request, pid):
#     try:
#         print('********** Inkoke Browser',pid)
#         oProject = Project_1.objects.get(id=pid)
#         s_url = oProject.url
#         s_start_maximized = oProject.start_maximized
#         s_disable_extensions = oProject.disable_extensions
#         s_disable_popup_blocking = oProject.disable_popup_blocking
#         s_ignore_certificate_errors = oProject.ignore_certificate_errors
#         s_incognito = oProject.incognito
#         s_headless = oProject.headless
#         print('********** Headless',s_headless)
#         print('********** pid',pid)
#         pid
        
#         browser_type = get_Config(request, pid)
#         print('**********Final tupple', browser_type)
#         print('**********Browser_Name', browser_type[0])
                
#         if browser_type[0] == "Chrome":
#             print('********** Chrome')
#             if not is_chrome_installed():
#                 install_chrome()

#             chrome_options = Options()
#             if s_start_maximized:
#                 print('XXXXXXXXXXXXXXX- MAX')
#                 chrome_options.add_argument("--start-maximized")
#             if s_disable_extensions:   
#                 chrome_options.add_argument("--disable-extensions")
#             if s_disable_popup_blocking:
#                 chrome_options.add_argument("--disable-popup-blocking")
#             if s_ignore_certificate_errors:
#                 chrome_options.add_argument("--ignore-certificate-errors")
#             if s_incognito:
#                 chrome_options.add_argument("--incognito")
#             if s_headless:
#                 chrome_options.add_argument("--headless")
#         elif browser_type[0] == "Edge":
#             print('********** Edge')
#             edge_options = Options()
#             if s_start_maximized:
#                 edge_options.add_argument("--start-maximized")
#             if s_disable_extensions:   
#                 edge_options.add_argument("--disable-extensions")
#             if s_disable_popup_blocking:
#                 edge_options.add_argument("--disable-popup-blocking")
#             if s_ignore_certificate_errors:
#                 edge_options.add_argument("--ignore-certificate-errors")
#             if s_incognito:
#                 edge_options.add_argument("--incognito")
#             if s_headless:
#                 edge_options.add_argument("--headless")
            
#         try:          
#             driver = ""
#             if browser_type[0] == "Chrome":
#                 binary_path = find_chrome_binary()
#                 chrome_options.binary_location = binary_path
#                 import tempfile
#                 user_data_dir = tempfile.mkdtemp()
#                 chrome_options.add_argument(f"--user-data-dir={user_data_dir}")

#                 driver = webdriver.Chrome(
#                     service=Service(ChromeDriverManager().install()),
#                     options=chrome_options
#                 )
#             elif browser_type[0] == "Edge":
#                 driver = webdriver.Edge(options=edge_options)
#         except Exception as e: print(e)
        
#         try:
#             driver.get(str(s_url))
#             WebDriverWait(driver, 100).until(lambda driver: driver.execute_script('return document.readyState') == 'complete')
#             driver.implicitly_wait(1)
#         except:
#             print("An exception occurred in invoke browser")
#         #print('********** Driver Set', driver)    
#         return driver
#     except Exception as e:
#         print("Error occurred:", e)

def close_Browser(request, driver):
    driver.close()
    return True

def runjob(request, pid, jobs_value):
    try:
        print('********** jobs_value_A', jobs_value)
        for oJobid in jobs_value:
            job_suite = Lab_1.objects.get(id=oJobid, project_id=request.session['project_id'])
            job_suite.execution = "In-Progress"
            job_suite.save()
            
            # Create unique execution ID
            execution_id = f"exec_{uuid.uuid4().hex[:8]}_{int(timezone.now().timestamp())}"
            
            # Create JobExecution record
            job_execution = JobExecution.objects.create(
                job=job_suite,
                execution_id=execution_id,
                user=request.user,
                status='running',
                environment='Production',  # You can make this configurable
                browser_type='Chrome'  # You can get this from config
            )
            
            # Log job start
            JobAuditLog.objects.create(
                job=job_suite,
                user=request.user,
                event_type='start',
                message=f'Job execution started with ID: {execution_id}',
                execution_id=execution_id,
                status='running'
            )
            
            suite_name = job_suite.suits.strip()
            print('**********Suite Name ', suite_name)
                       
            print('**********oSuite-->', job_suite.suits.strip())
            
            xx = job_suite.suits.split()
            yx = ""
            for ix in xx:
                jx = ix.split('#')
                print('JX', jx)
                yx = yx + jx[1] + ","
                
            suite_ids = yx[:-1]
            print('********** suite id ', suite_ids)
            lst_suite_ids = suite_ids.split(',')
            
            total_steps = 0
            passed_steps = 0
            failed_steps = 0
            skipped_steps = 0
            
            for oSuiteId in lst_suite_ids:
                print('**********Suite ids loop - Suite id', oSuiteId)
                obj_Suite = Suite_1.objects.get(id=oSuiteId, project_id=request.session['project_id'])
                
                obj_MainBatch = MainBatch_1.objects.get(id=obj_Suite.main_BatchName_id, project_id=request.session['project_id'])
                
                oSuiteName = obj_Suite.suite_name
                print('######## oSuiteName', oSuiteName)
                
                x = obj_MainBatch.keyword_Data.split('\r\n')
                y = ""
                for i in x:
                    j = i.split('#')
                    y = y + j[1] + ","

                oKeywordId = y[:-1]
                print('********** oKeywordId', oKeywordId)
                
                # Set tcs_Name to job_suite.job_name for correct job history association
                rep_1 = Report_1.objects.create(
                    project_id=request.session['project_id'],
                    tcs_Name = job_suite.job_name,
                    status = True,
                    test_Env = '',
                    time = now,
                    user_id = request.session['user_id'],
                    run_by = request.user   
                )
                
                # Update traceability matrix with test execution results
                from requirement.views import update_traceability_from_report
                update_traceability_from_report(rep_1)
                
                L1 = oKeywordId.replace("'", "")
                print('********** L1', L1)
                oKeywordList = L1.strip('[]').replace('"', '').replace(' ', '').split(',')
                print('********** oKeywordList', oKeywordList)
                
                print('********** Pid', pid)
                
                step_order = 1
                for oList in oKeywordList:
                    driver = invoke_Browser(request, pid)

                    print('********** olist', oList)
                    oSteps = Steps_1.objects.filter(k_id=int(oList))
                    for oStep in oSteps:
                        print('********** Action', oStep.action)
                        
                        # Create step execution record
                        step_execution = JobExecutionStep.objects.create(
                            execution=job_execution,
                            step_name=oStep.step_Descriptions or oStep.action,
                            step_description=f"Executing {oStep.action} on {oStep.object_Name}",
                            step_order=step_order,
                            status='running',
                            input_data=oStep.input_Value,
                            expected_result=oStep.expected_Value
                        )
                        
                        step_start_time = timezone.now()
                        step_status = False
                        step_error = None
                        
                        try:
                            if(oStep.action == "SetText"):
                                oStatus = fun_Settext(request, driver, oStep, rep_1.pk)
                                print('********** Settext Status-', oStatus)
                                step_status = oStatus
                                if not oStatus:
                                    step_error = "Failed to set text"
                                    raise StopIteration
                            elif(oStep.action == "ButtonClick" or oStep.action.lower() == "click"):
                                oStatus = fun_Buttonclick(request, driver, oStep, rep_1.pk)
                                obj = Report_1.objects.get(id=rep_1.pk)
                                obj.actual_Value = oStep.input_Value
                                step_status = oStatus
                                if not oStatus:
                                    obj.status = False
                                    obj.save()
                                    step_error = "Failed to click button"
                                    raise StopIteration
                                
                            elif(oStep.action=="VerifyNonEditableText"):
                                oStatus = fun_VerifyNonEditableText(request, driver, oStep, rep_1.pk)
                                step_status = oStatus
                                if not oStatus:
                                    obj = Report_1.objects.get(id=rep_1.pk)
                                    obj.status = False
                                    obj.save()
                                    step_error = "Text verification failed"
                                    raise StopIteration
                            elif(oStep.action == "SelectListItem"):
                                oStatus = fun_SelectListItem(request, driver, oStep, rep_1.pk)
                                step_status = oStatus
                                if not oStatus:
                                    obj = Report_1.objects.get(id=rep_1.pk)
                                    obj.status = False
                                    obj.save()
                                    step_error = "List item selection failed"
                                    raise StopIteration
                            elif(oStep.action == "ElementClick"):
                                oStatus = fun_Buttonclick(request, driver, oStep, rep_1.pk)
                                obj = Report_1.objects.get(id=rep_1.pk)
                                obj.actual_Value = oStep.input_Value
                                step_status = oStatus
                                if not oStatus:
                                    obj.status = False
                                    obj.save()
                                    step_error = "Element click failed"
                                    raise StopIteration
                            elif(oStep.action == "Sync"):
                                try:
                                    print('##########SYNC')
                                    element = WebDriverWait(driver, 10).until(
                                        EC.visibility_of_element_located((By.XPATH, oStep.object_Name))
                                    )
                                    step_status = True
                                except:
                                    step_status = False
                                    step_error = "Sync timeout"
                                    pass
                        except StopIteration:
                            pass
                        except Exception as e:
                            step_error = str(e)
                            step_status = False
                        
                        # Update step execution record
                        step_execution.end_time = timezone.now()
                        step_execution.status = 'passed' if step_status else 'failed'
                        step_execution.actual_result = f"Step {'completed successfully' if step_status else 'failed'}"
                        if step_error:
                            step_execution.error_message = step_error
                        step_execution.duration = step_execution.end_time - step_start_time
                        step_execution.save()
                        
                        # Update counters
                        total_steps += 1
                        if step_status:
                            passed_steps += 1
                        else:
                            failed_steps += 1
                        
                        step_order += 1
                        
                    close_Browser(request, driver)    
                            
            # Update job execution record
            job_execution.end_time = timezone.now()
            job_execution.status = 'completed' if failed_steps == 0 else 'failed'
            job_execution.total_steps = total_steps
            job_execution.passed_steps = passed_steps
            job_execution.failed_steps = failed_steps
            job_execution.skipped_steps = skipped_steps
            job_execution.execution_duration = job_execution.end_time - job_execution.start_time
            if failed_steps > 0:
                job_execution.error_message = f"Job completed with {failed_steps} failed steps"
            job_execution.save()
            
            # Log job completion
            JobAuditLog.objects.create(
                job=job_suite,
                user=request.user,
                event_type='end',
                message=f'Job completed with {passed_steps} passes, {failed_steps} fails, {skipped_steps} skipped',
                execution_id=execution_id,
                status='success' if failed_steps == 0 else 'fail',
                test_cases_total=total_steps,
                test_cases_passed=passed_steps,
                test_cases_failed=failed_steps,
                test_cases_incomplete=skipped_steps,
                duration=job_execution.execution_duration
            )
            
            # Log job statistics
            pass_count = Report_Steps_1.objects.filter(r_id__tcs_Name__icontains=job_suite.job_name, status=True).count()
            fail_count = Report_Steps_1.objects.filter(r_id__tcs_Name__icontains=job_suite.job_name, status=False).count()
            incomplete_count = Report_Steps_1.objects.filter(r_id__tcs_Name__icontains=job_suite.job_name, status=None).count()

            JobAuditLog.objects.create(
                job=job_suite,
                user=request.user,
                event_type='statistics',
                message=f'Job ended with {pass_count} passes, {fail_count} fails, {incomplete_count} incomplete',
                status='success' if fail_count == 0 else 'fail'
            )
            
            job_suite.execution = "Completed"
            job_suite.save()     
            
        return redirect('show_jobs')
    except Exception as e:
        print("Error:", e)
        traceback.print_exc()
        
        # Log error in job execution if we have a job_execution object
        if 'job_execution' in locals():
            job_execution.status = 'failed'
            job_execution.error_message = str(e)
            job_execution.stack_trace = traceback.format_exc()
            job_execution.end_time = timezone.now()
            job_execution.save()
            
            # Log error in audit log
            JobAuditLog.objects.create(
                job=job_suite,
                user=request.user,
                event_type='error',
                message=f'Job execution failed: {str(e)}',
                execution_id=execution_id if 'execution_id' in locals() else None,
                status='fail',
                error_details=traceback.format_exc()
            )
        
        return redirect('show_jobs')

def get_suite_components(request, job_id):
    """Get components associated with a job's suites"""
    print("=" * 50)
    print("DEBUG: get_suite_components function called!")
    print(f"DEBUG: Request method: {request.method}")
    print(f"DEBUG: Job ID from URL: {job_id}")
    print(f"DEBUG: Session project_id: {request.session.get('project_id')}")
    print("=" * 50)
    
    try:
        print(f"DEBUG: Looking for job ID: {job_id}")
        print(f"DEBUG: Project ID from session: {request.session.get('project_id')}")
        
        job = Lab_1.objects.get(id=job_id, project_id=request.session['project_id'])
        print(f"DEBUG: Found job: {job.job_name}")
        print(f"DEBUG: Job suits field: '{job.suits}'")
        print(f"DEBUG: Job suits type: {type(job.suits)}")
        print(f"DEBUG: Job suits length: {len(job.suits) if job.suits else 0}")
        
        suite_data = []
        
        if job.suits and job.suits.strip():
            # Parse suite IDs from the suits field (format: "Linkedin_login#33")
            suite_ids = []
            print(f"DEBUG: Splitting suits field: '{job.suits}'")
            
            # Split by space to get individual suite entries
            items = job.suits.split()
            print(f"DEBUG: Split items: {items}")
            
            for item in items:
                print(f"DEBUG: Processing item: '{item}'")
                # Format: "Linkedin_login#33" - extract the ID after the last #
                if '#' in item:
                    parts = item.split('#')
                    if len(parts) >= 2:
                        suite_id = parts[-1].strip()  # Get the last part as suite ID
                        suite_name = '#'.join(parts[:-1]).strip()  # Get everything before last # as name
                        suite_ids.append(suite_id)
                        print(f"DEBUG: Added suite ID: {suite_id} (name: {suite_name})")
                elif item.isdigit():
                    # Handle case where it's just a number
                    suite_ids.append(item)
                    print(f"DEBUG: Added suite ID (no #): {item}")
            
            print(f"DEBUG: Final parsed suite IDs: {suite_ids}")
            
            if suite_ids:
                for suite_id in suite_ids:
                    print(f"DEBUG: Processing suite ID: {suite_id}")
                    try:
                        # Get the suite
                        suite = Suite_1.objects.get(id=suite_id, project_id=request.session['project_id'])
                        print(f"DEBUG: Found suite: {suite.suite_name} (ID: {suite_id})")
                        print(f"DEBUG: Suite main_BatchName_id: {suite.main_BatchName_id}")
                        
                        # Get the main batch
                        main_batch = MainBatch_1.objects.get(id=suite.main_BatchName_id, project_id=request.session['project_id'])
                        print(f"DEBUG: Found main batch: {main_batch.main_BatchName} (ID: {suite.main_BatchName_id})")
                        print(f"DEBUG: Main batch keyword_Data: '{main_batch.keyword_Data}'")
                        
                        # Parse components from keyword_Data
                        components = []
                        if main_batch.keyword_Data:
                            # Split by newlines or commas to get individual component entries
                            lines = []
                            if '\r\n' in main_batch.keyword_Data:
                                lines = main_batch.keyword_Data.split('\r\n')
                            elif '\n' in main_batch.keyword_Data:
                                lines = main_batch.keyword_Data.split('\n')
                            else:
                                lines = main_batch.keyword_Data.split(',')
                            
                            print(f"DEBUG: Split keyword_Data into {len(lines)} lines: {lines}")
                            
                            for line in lines:
                                line = line.strip()
                                if line:
                                    print(f"DEBUG: Processing line: '{line}'")
                                    
                                    # Parse format: ComponentName#KeywordID
                                    if '#' in line:
                                        parts = line.split('#')
                                        if len(parts) >= 2:
                                            component_name = parts[0].strip()
                                            keyword_id = parts[1].strip()
                                            
                                            try:
                                                # Get the keyword by ID
                                                keyword = KeyWord_1.objects.get(id=int(keyword_id))
                                                
                                                # Get steps count for this keyword
                                                steps_count = Steps_1.objects.filter(k=keyword).count()
                                                
                                                components.append({
                                                    'id': keyword.id,
                                                    'name': keyword.keyword_Name,
                                                    'description': keyword.keyword_Desc,
                                                    'steps_count': steps_count,
                                                    'component_name': component_name  # The name from keyword_Data
                                                })
                                                print(f"DEBUG: Found component: {component_name} -> {keyword.keyword_Name} (ID: {keyword_id}, Steps: {steps_count})")
                                                
                                            except (ValueError, KeyWord_1.DoesNotExist) as e:
                                                print(f"DEBUG: Error getting keyword {keyword_id}: {e}")
                                                
                                                # Create the missing keyword with the expected ID
                                                print(f"DEBUG: Creating missing keyword with ID {keyword_id} for component: {component_name}")
                                                try:
                                                    # Get project and user objects
                                                    from autoai.models import Project_1
                                                    project = Project_1.objects.get(id=request.session['project_id'])
                                                    user = request.user
                                                    
                                                    # Create the keyword with the specific ID
                                                    keyword = KeyWord_1.objects.create(
                                                        id=int(keyword_id),  # Use the specific ID from main batch
                                                        keyword_Name=component_name,
                                                        keyword_Desc=f"Component: {component_name}",
                                                        p=project,
                                                        u=user
                                                    )
                                                    
                                                    # Get steps count (will be 0 for new keyword)
                                                    steps_count = Steps_1.objects.filter(k=keyword).count()
                                                    
                                                    components.append({
                                                        'id': keyword.id,
                                                        'name': keyword.keyword_Name,
                                                        'description': keyword.keyword_Desc,
                                                        'steps_count': steps_count,
                                                        'component_name': component_name
                                                    })
                                                    print(f"DEBUG: Created keyword: {component_name} (ID: {keyword_id}, Steps: {steps_count})")
                                                    
                                                except Exception as create_error:
                                                    print(f"DEBUG: Error creating keyword {keyword_id}: {create_error}")
                                                    continue
                                    else:
                                        # Try to find keyword by name if no ID provided
                                        try:
                                            keyword = KeyWord_1.objects.get(
                                                keyword_Name__icontains=line,
                                                p_id=request.session['project_id']
                                            )
                                            steps_count = Steps_1.objects.filter(k=keyword).count()
                                            
                                            components.append({
                                                'id': keyword.id,
                                                'name': keyword.keyword_Name,
                                                'description': keyword.keyword_Desc,
                                                'steps_count': steps_count,
                                                'component_name': line
                                            })
                                            print(f"DEBUG: Found component by name: {line} -> {keyword.keyword_Name} (Steps: {steps_count})")
                                            
                                        except KeyWord_1.DoesNotExist:
                                            print(f"DEBUG: No keyword found for: {line}")
                                            continue
                        
                        # If no components found from keyword_Data, show all available keywords for this project
                        if not components:
                            print("DEBUG: No components found from keyword_Data, showing all available keywords for this project")
                            all_keywords = KeyWord_1.objects.filter(
                                p_id=request.session['project_id'],
                                u_id=request.session['user_id']
                            )
                            
                            for keyword in all_keywords:
                                steps_count = Steps_1.objects.filter(k=keyword).count()
                                components.append({
                                    'id': keyword.id,
                                    'name': keyword.keyword_Name,
                                    'description': keyword.keyword_Desc,
                                    'steps_count': steps_count,
                                    'component_name': keyword.keyword_Name,
                                    'note': 'Available keyword (not in main batch)'
                                })
                                print(f"DEBUG: Added available keyword: {keyword.keyword_Name} (ID: {keyword.id}, Steps: {steps_count})")
                        
                        print(f"DEBUG: Total components found for suite {suite.suite_name}: {len(components)}")
                        
                        suite_data.append({
                            'suite_id': suite.id,
                            'suite_name': suite.suite_name,
                            'suite_description': suite.suite_description,
                            'main_batch_name': main_batch.main_BatchName,
                            'main_batch_id': main_batch.id,
                            'components': components
                        })
                        
                    except (Suite_1.DoesNotExist, MainBatch_1.DoesNotExist) as e:
                        print(f"DEBUG: Error getting suite/batch for ID {suite_id}: {e}")
                        continue
            else:
                print("DEBUG: No suite IDs found after parsing")
        else:
            print("DEBUG: Job has no suits or empty suits field")
        
        print(f"DEBUG: Final suite data: {suite_data}")
        
        return JsonResponse({
            'success': True,
            'job_name': job.job_name,
            'suites': suite_data
        })
    except Lab_1.DoesNotExist:
        print(f"DEBUG: Job with ID {job_id} not found")
        return JsonResponse({'success': False, 'error': 'Job not found'})
    except Exception as e:
        print(f"DEBUG: Exception in get_suite_components: {e}")
        import traceback
        traceback.print_exc()
        return JsonResponse({'success': False, 'error': str(e)})

def data_param(request, id):
    print("request.method :", request.method)
    if request.method == "POST":
        data = request.POST
        var_Name = data.get('var_Name')
        var_Value = data.get('var_Value')
        var_AI = data.get('AI')
        ai_Prompt = data.get('ai_Prompt') 
        llm_Model = data.get('llm_Model')
        
        print('XXXXXXXXXXXXX', data.get('ai_Prompt') )
        
        hidIndex = data.get('hidIndex')
        print('hidIndex-->', hidIndex)
        Data_Param_1.objects.create(
            var_Name = var_Name,
            var_Value = var_Value,
            var_AI = var_AI,
            ai_Prompt = ai_Prompt,
            llm_Model = llm_Model,
            k_id = id
        )
        
        #get_API_completion(ai_Prompt)
        
        messages.success(request, "Row added successfullt")
        return redirect('/data-param/'+id+'/')
    #context = {"page":'Add Recepi'}
    # print(request.session['component_name'])
    queryset = Data_Param_1.objects.filter(k_id=id)
    queryset1 = KeyWord_1.objects.get(id = id)
    #print(queryset1.query)
    # if request.session['component_name']!=None:
    #     queryset = KeyWord_1.objects.filter(name=request.session['component_name'])
    #     #print(queryset.query)
    # else:
    #     queryset = KeyWord_1.objects.all()
        
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    
    
    # if request.GET.get("Search"):
    #     print(request.GET.get("Search"))
    #     queryset = queryset.filter(receipe_name__icontains = request.GET.get("Search")) 


    context = {'dataparam':queryset, 'component':queryset1}
    return render(request, 'autoai/DataParam.html', context)


def delete_dataparam(request, id, kid):
    queryset = Data_Param_1.objects.get(id=id)
    queryset.delete()
    #return HttpResponse("a")
    messages.error(request, "Param rows deleted successfullt")
    return redirect('/data-param/'+kid+'/')

def update_dataparam(request, id, kid):
    queryset = Data_Param_1.objects.get(id=id)
    queryset1 = KeyWord_1.objects.get(id = kid)
    
    if request.method == "POST":
        data = request.POST
        
        var_Name = data.get('var_Name')
        var_Value = data.get('var_Value')
        var_AI = data.get('AI')
        ai_Prompt = data.get('ai_Prompt') 
        llm_Model = data.get('llm_Model')
        hidIndex = data.get('hidIndex')
                
        queryset.var_Name = var_Name
        queryset.var_Value = var_Value
        queryset.var_AI = var_AI
        queryset.ai_Prompt = ai_Prompt
        queryset.llm_Model = llm_Model
               
        queryset.save()
        messages.success(request, "Data Param rows updated successfully")
        return redirect('/data-param/'+kid+'/')
    #if queryset.action.count
    print('///////////////////', queryset.var_Value)
    context = {'dataparam':queryset, 'component':queryset1}
    return render(request, 'autoai/update_dataParam.html', context)   

def get_API_completion(prompt): 
    print(prompt) 
    import os
    from openai import OpenAI

    client = OpenAI(
        api_key = os.getenv("OPENAI_API_KEY"),
    )

    completion = client.completions.create(
    model = "gpt-3.5-turbo-instruct",
    prompt = "Say this is a test",
    max_tokens = 7,
    temperature = 0
    )

    print(completion.choices[0].text.strip())

def job_history(request):
    """Show job execution history and statistics with detailed execution tracking"""
    from django.db.models import Count, Q
    from django.utils import timezone
    from datetime import timedelta
    
    user_id = request.session.get('user_id')
    project_id = request.session.get('project_id')
    
    if not user_id or not project_id:
        messages.error(request, "Please login and select a project first")
        return redirect('/login/')
    
    # Get all jobs for the current project
    jobs = Lab_1.objects.filter(project_id=project_id).order_by('-datetime')
    
    # Calculate execution statistics for each job
    job_stats = []
    for job in jobs:
        # Get detailed execution data from new models
        job_executions = JobExecution.objects.filter(job=job).order_by('-start_time')
        
        # Count total executions for this job
        total_executions = job_executions.count()
        
        # Get execution details
        successful_executions = job_executions.filter(status='completed').count()
        failed_executions = job_executions.filter(status='failed').count()
        running_executions = job_executions.filter(status='running').count()
        
        # Calculate success rate
        success_rate = 0
        if total_executions > 0:
            success_rate = round((successful_executions / total_executions) * 100, 2)
        
        # Get last execution time
        last_execution = job_executions.first()
        
        # Get execution frequency (last 30 days)
        thirty_days_ago = timezone.now() - timedelta(days=30)
        recent_executions = job_executions.filter(start_time__gte=thirty_days_ago).count()
        
        # Determine job status based on execution data
        if total_executions == 0:
            job_status = "Never Executed"
            status_class = "secondary"
        elif job.execution == "Completed":
            job_status = "Completed"
            status_class = "success"
        elif job.execution == "In-Progress":
            job_status = "In Progress"
            status_class = "warning"
        else:
            job_status = "Ready"
            status_class = "info"
        
        # Get detailed step statistics from JobExecutionStep
        total_steps = 0
        passed_steps = 0
        failed_steps = 0
        incomplete_steps = 0
        
        for execution in job_executions:
            total_steps += execution.total_steps
            passed_steps += execution.passed_steps
            failed_steps += execution.failed_steps
            incomplete_steps += execution.skipped_steps
        
        # Get recent execution details for expandable rows
        recent_execution_details = []
        for execution in job_executions[:5]:  # Last 5 executions
            execution_detail = {
                'execution_id': execution.execution_id,
                'start_time': execution.start_time,
                'end_time': execution.end_time,
                'status': execution.status,
                'duration': execution.get_duration(),
                'total_steps': execution.total_steps,
                'passed_steps': execution.passed_steps,
                'failed_steps': execution.failed_steps,
                'skipped_steps': execution.skipped_steps,
                'success_rate': execution.get_success_rate(),
                'environment': execution.environment,
                'browser_type': execution.browser_type,
                'error_message': execution.error_message,
                'steps': []
            }
            
            # Get step details for this execution
            steps = JobExecutionStep.objects.filter(execution=execution).order_by('step_order')
            for step in steps:
                step_detail = {
                    'step_name': step.step_name,
                    'step_description': step.step_description,
                    'status': step.status,
                    'duration': step.get_duration(),
                    'input_data': step.input_data,
                    'expected_result': step.expected_result,
                    'actual_result': step.actual_result,
                    'error_message': step.error_message
                }
                execution_detail['steps'].append(step_detail)
            
            recent_execution_details.append(execution_detail)
        
        job_stats.append({
            'job': job,
            'total_executions': total_executions,
            'successful_executions': successful_executions,
            'failed_executions': failed_executions,
            'running_executions': running_executions,
            'success_rate': success_rate,
            'last_execution': last_execution.start_time if last_execution else None,
            'recent_executions': recent_executions,
            'job_status': job_status,
            'status_class': status_class,
            'pass_count': passed_steps,
            'fail_count': failed_steps,
            'incomplete_count': incomplete_steps,
            'total_steps': total_steps,
            'recent_execution_details': recent_execution_details,
            'job_executions': job_executions
        })
    
    # Sort by total executions (most executed first)
    job_stats.sort(key=lambda x: x['total_executions'], reverse=True)
    
    # Pagination
    page = request.GET.get('page', 1)
    paginator = Paginator(job_stats, 15)
    try:
        job_stats_page = paginator.page(page)
    except PageNotAnInteger:
        job_stats_page = paginator.page(1)
    except EmptyPage:
        job_stats_page = paginator.page(paginator.num_pages)
    
    # Overall statistics
    total_jobs = len(jobs)
    total_executions_all = sum(stat['total_executions'] for stat in job_stats)
    total_successful_all = sum(stat['successful_executions'] for stat in job_stats)
    total_failed_all = sum(stat['failed_executions'] for stat in job_stats)
    overall_success_rate = 0
    if total_executions_all > 0:
        overall_success_rate = round((total_successful_all / total_executions_all) * 100, 2)
    
    # Most active jobs (top 5)
    most_active_jobs = sorted(job_stats, key=lambda x: x['recent_executions'], reverse=True)[:5]
    
    # Retrieve additional job execution details from JobAuditLog
    job_audit_logs = JobAuditLog.objects.filter(job__in=jobs).values('job_id', 'event_type', 'status', 'message')
    
    # Retrieve step details from Report_Steps_1
    report_steps = Report_Steps_1.objects.filter(r_id__in=jobs.values_list('id', flat=True)).values('r_id', 'step_Description', 'status')
    
    # Add additional details to context
    context = {
        'job_stats': job_stats_page,
        'total_jobs': total_jobs,
        'total_executions_all': total_executions_all,
        'total_successful_all': total_successful_all,
        'total_failed_all': total_failed_all,
        'overall_success_rate': overall_success_rate,
        'most_active_jobs': most_active_jobs,
        'job_audit_logs': job_audit_logs,
        'report_steps': report_steps
    }
    
    return render(request, 'autoai/job_history.html', context)

@login_required
def traceability_coverage(request):
    """
    Traceability Matrix - Coverage Results View
    Shows execution results and coverage after test execution
    """
    from tocop.models import TestCase, Automation, Requirement
    from django.db.models import Count, Q, Case, When, IntegerField
    
    # Get user's requirements and related data
    requirements = Requirement.objects.filter(user=request.user).order_by('id')
    
    # Calculate coverage statistics
    total_requirements = requirements.count()
    total_test_cases = TestCase.objects.filter(requirement__user=request.user).count()
    total_automations = Automation.objects.filter(test_case__requirement__user=request.user).count()
    
    # Calculate coverage percentages
    requirements_with_tests = requirements.filter(test_cases__isnull=False).distinct().count()
    test_cases_with_automation = TestCase.objects.filter(
        requirement__user=request.user,
        automations__isnull=False
    ).distinct().count()
    
    requirement_coverage = (requirements_with_tests / total_requirements * 100) if total_requirements > 0 else 0
    automation_coverage = (test_cases_with_automation / total_test_cases * 100) if total_test_cases > 0 else 0
    
    # Get execution statistics
    from .models import JobAuditLog
    execution_stats = JobAuditLog.objects.filter(
        user=request.user
    ).aggregate(
        total_executions=Count('id'),
        successful_executions=Count('id', filter=Q(status='Completed')),
        failed_executions=Count('id', filter=Q(status='Failed'))
    )
    
    # Build traceability matrix data with execution results
    traceability_data = []
    for req in requirements:
        test_cases = req.test_cases.all()
        req_data = {
            'requirement': req,
            'test_cases': [],
            'total_tests': test_cases.count(),
            'automated_tests': 0,
            'execution_status': 'Not Executed',
            'last_execution': None,
            'success_rate': 0
        }
        
        for tc in test_cases:
            automation = Automation.objects.filter(test_case=tc).first()
            tc_data = {
                'test_case': tc,
                'automation': automation,
                'is_automated': automation is not None,
                'execution_count': 0,
                'last_execution': None,
                'success_rate': 0
            }
            
            if automation:
                req_data['automated_tests'] += 1
                
                # Get execution data for this automation
                # Note: JobAuditLog doesn't have direct automation relationship
                # We'll use a placeholder for now - this would need to be implemented
                # based on your actual execution tracking system
                executions = JobAuditLog.objects.filter(
                    user=request.user
                ).order_by('-created_at')[:0]  # Empty queryset for now
                
                if executions.exists():
                    tc_data['execution_count'] = executions.count()
                    tc_data['last_execution'] = executions.first().created_at
                    successful = executions.filter(status='Completed').count()
                    tc_data['success_rate'] = (successful / executions.count() * 100) if executions.count() > 0 else 0
            
            req_data['test_cases'].append(tc_data)
        
        # Calculate requirement-level execution status
        if req_data['automated_tests'] > 0:
            # Get execution data for this requirement
            # Note: This would need to be implemented based on your actual execution tracking
            all_executions = JobAuditLog.objects.filter(
                user=request.user
            ).order_by('-created_at')[:0]  # Empty queryset for now
            
            if all_executions.exists():
                req_data['last_execution'] = all_executions.first().created_at
                successful = all_executions.filter(status='Completed').count()
                req_data['success_rate'] = (successful / all_executions.count() * 100) if all_executions.count() > 0 else 0
                
                if req_data['success_rate'] >= 90:
                    req_data['execution_status'] = 'Excellent'
                elif req_data['success_rate'] >= 70:
                    req_data['execution_status'] = 'Good'
                elif req_data['success_rate'] >= 50:
                    req_data['execution_status'] = 'Fair'
                else:
                    req_data['execution_status'] = 'Poor'
            else:
                req_data['execution_status'] = 'Not Executed'
        
        traceability_data.append(req_data)
    
    # Calculate overall statistics
    total_executions = execution_stats['total_executions'] or 0
    successful_executions = execution_stats['successful_executions'] or 0
    failed_executions = execution_stats['failed_executions'] or 0
    overall_success_rate = (successful_executions / total_executions * 100) if total_executions > 0 else 0
    
    context = {
        'traceability_data': traceability_data,
        'total_requirements': total_requirements,
        'total_test_cases': total_test_cases,
        'total_automations': total_automations,
        'requirement_coverage': round(requirement_coverage, 1),
        'automation_coverage': round(automation_coverage, 1),
        'total_executions': total_executions,
        'successful_executions': successful_executions,
        'failed_executions': failed_executions,
        'overall_success_rate': round(overall_success_rate, 1),
    }
    
    return render(request, 'autoai/traceability_coverage.html', context)