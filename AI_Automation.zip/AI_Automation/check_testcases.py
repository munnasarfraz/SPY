# Script to check test cases in the database
import os
import django

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

# Import models
from tocop.models import TestCase, Requirement

# Check test cases
test_cases = TestCase.objects.all()
print(f"Total test cases: {test_cases.count()}")

# Print details of each test case
for tc in test_cases:
    print(f"ID: {tc.id}, Test Case ID: {tc.test_case_id}, Name: {tc.scenario_name}, Requirement: {tc.requirement_id}")

# Check requirements
requirements = Requirement.objects.all()
print(f"\nTotal requirements: {requirements.count()}")

# Print details of each requirement
for req in requirements:
    print(f"ID: {req.id}, Title: {req.title}, Test Cases: {req.test_cases.count()}")