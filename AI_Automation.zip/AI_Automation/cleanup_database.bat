@echo off
echo ========================================
echo Database Cleanup Script
echo ========================================
echo.
echo This will delete ALL data from:
echo - KeyWord_1
echo - Steps_1
echo - Automation
echo - Report_1
echo - Report_Steps_1
echo - requirement_requirement
echo - requirement_requirementtraceabilitymatrix
echo - requirement_testcase
echo - autoai_jobauditlog
echo - autoai_jobexecution
echo - autoai_jobexecutionstep
echo - autoai_lab_1
echo - autoai_mainbatch_1
echo - autoai_suite_1
echo - tocop_requirement
echo - tocop_selectedrow
echo - tocop_testcase
echo.
echo WARNING: This action cannot be undone!
echo.
pause
echo.
echo Running cleanup...
python quick_cleanup.py
echo.
echo Cleanup completed!
pause
