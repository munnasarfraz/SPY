#!/usr/bin/env python
"""
Database Cleanup Script
Deletes all rows from specified tables for testing/development purposes.

Usage: python cleanup_database.py

Tables to be cleaned:
- KeyWord_1
- Steps_1
- Automation (from tocop app)
- Report_1
- Report_Steps_1

WARNING: This will permanently delete all data from these tables!
"""

import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

def cleanup_database():
    """Delete all records from specified tables"""
    try:
        # Import models
        from autoai.models import KeyWord_1, Steps_1, Report_1, Report_Steps_1
        from tocop.models import Automation
        
        print("=" * 60)
        print("DATABASE CLEANUP SCRIPT")
        print("=" * 60)
        print("WARNING: This will permanently delete all data from the following tables:")
        print("- KeyWord_1")
        print("- Steps_1") 
        print("- Automation")
        print("- Report_1")
        print("- Report_Steps_1")
        print("=" * 60)
        
        # Get confirmation from user
        confirm = input("Are you sure you want to proceed? Type 'YES' to confirm: ")
        if confirm != 'YES':
            print("Operation cancelled.")
            return
        
        print("\nStarting cleanup process...")
        
        # Count records before deletion
        keyword_count = KeyWord_1.objects.count()
        steps_count = Steps_1.objects.count()
        automation_count = Automation.objects.count()
        report_count = Report_1.objects.count()
        report_steps_count = Report_Steps_1.objects.count()
        
        print(f"\nBefore cleanup:")
        print(f"  KeyWord_1 records: {keyword_count}")
        print(f"  Steps_1 records: {steps_count}")
        print(f"  Automation records: {automation_count}")
        print(f"  Report_1 records: {report_count}")
        print(f"  Report_Steps_1 records: {report_steps_count}")
        
        # Delete records in correct order (respecting foreign key constraints)
        print(f"\nDeleting records...")
        
        # Delete Steps_1 first (has foreign key to KeyWord_1)
        deleted_steps = Steps_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_steps[0]} Steps_1 records")
        
        # Delete Report_Steps_1 (has foreign key to Report_1)
        deleted_report_steps = Report_Steps_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_report_steps[0]} Report_Steps_1 records")
        
        # Delete Automation (has foreign key to TestCase)
        deleted_automations = Automation.objects.all().delete()
        print(f"  ✓ Deleted {deleted_automations[0]} Automation records")
        
        # Delete KeyWord_1
        deleted_keywords = KeyWord_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_keywords[0]} KeyWord_1 records")
        
        # Delete Report_1
        deleted_reports = Report_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_reports[0]} Report_1 records")
        
        # Verify cleanup
        remaining_keywords = KeyWord_1.objects.count()
        remaining_steps = Steps_1.objects.count()
        remaining_automations = Automation.objects.count()
        remaining_reports = Report_1.objects.count()
        remaining_report_steps = Report_Steps_1.objects.count()
        
        print(f"\nAfter cleanup:")
        print(f"  KeyWord_1 records: {remaining_keywords}")
        print(f"  Steps_1 records: {remaining_steps}")
        print(f"  Automation records: {remaining_automations}")
        print(f"  Report_1 records: {remaining_reports}")
        print(f"  Report_Steps_1 records: {remaining_report_steps}")
        
        # Check if cleanup was successful
        total_remaining = (remaining_keywords + remaining_steps + remaining_automations + 
                          remaining_reports + remaining_report_steps)
        
        if total_remaining == 0:
            print(f"\n✅ SUCCESS: All records have been deleted successfully!")
        else:
            print(f"\n⚠️  WARNING: {total_remaining} records still remain in the database.")
        
        print("=" * 60)
        print("Cleanup process completed.")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        print("Cleanup process failed.")
        return False
    
    return True

def show_table_info():
    """Show current table information without deleting"""
    try:
        from autoai.models import KeyWord_1, Steps_1, Report_1, Report_Steps_1
        from tocop.models import Automation
        
        print("=" * 60)
        print("CURRENT DATABASE STATUS")
        print("=" * 60)
        
        keyword_count = KeyWord_1.objects.count()
        steps_count = Steps_1.objects.count()
        automation_count = Automation.objects.count()
        report_count = Report_1.objects.count()
        report_steps_count = Report_Steps_1.objects.count()
        
        print(f"KeyWord_1 records: {keyword_count}")
        print(f"Steps_1 records: {steps_count}")
        print(f"Automation records: {automation_count}")
        print(f"Report_1 records: {report_count}")
        print(f"Report_Steps_1 records: {report_steps_count}")
        
        total_records = keyword_count + steps_count + automation_count + report_count + report_steps_count
        print(f"\nTotal records: {total_records}")
        print("=" * 60)
        
    except Exception as e:
        print(f"Error getting table info: {str(e)}")

if __name__ == "__main__":
    print("Database Cleanup Utility")
    print("1. Show current table status")
    print("2. Clean up all tables (DELETE ALL DATA)")
    print("3. Exit")
    
    while True:
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == '1':
            show_table_info()
        elif choice == '2':
            cleanup_database()
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")
