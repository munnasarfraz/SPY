"""
WSGI config for production deployment on PythonAnywhere
"""
import os
import sys

# Add your project directory to the sys.path
path = '/home/yourusername/yourproject'
if path not in sys.path:
    sys.path.append(path)

# Set the Django settings module for production
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings_production')

# Import Django WSGI application
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
