#!/usr/bin/env python
"""
Test script to demonstrate enhanced job history functionality
This script creates sample job execution data to test the new features
"""

import os
import sys
import django
from datetime import datetime, timedelta

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from autoai.models import *
from django.contrib.auth.models import User
from django.utils import timezone

def create_test_data():
    """Create sample test data for job history demonstration"""
    
    print("Setting up test data for enhanced job history...")
    
    # Get or create a test user
    user, created = User.objects.get_or_create(
        username='testuser',
        defaults={
            'email': 'test@example.com',
            'first_name': 'Test',
            'last_name': 'User'
        }
    )
    
    if created:
        user.set_password('testpass123')
        user.save()
        print("Created test user")
    
    # Get or create a test project
    project, created = Project_1.objects.get_or_create(
        project='Test Project',
        defaults={
            'user': user,
            'project_Type': 'Web Application',
            'url': 'https://example.com',
            'active': True
        }
    )
    
    if created:
        print("Created test project")
    
    # Get or create a test job
    job, created = Lab_1.objects.get_or_create(
        job_name='Sample Test Job',
        defaults={
            'user': user,
            'project_id': project.id,
            'job_id': 'JOB_001',
            'priority': 'High',
            'impact': 'Critical',
            'suits': 'Suite#1',
            'execution': 'Completed'
        }
    )
    
    if created:
        print("Created test job")
    
    # Create sample job executions
    execution_ids = [
        'exec_abc12345_1703123456',
        'exec_def67890_1703123457',
        'exec_ghi11111_1703123458'
    ]
    
    for i, exec_id in enumerate(execution_ids):
        # Create JobExecution record
        execution, created = JobExecution.objects.get_or_create(
            execution_id=exec_id,
            defaults={
                'job': job,
                'user': user,
                'start_time': timezone.now() - timedelta(hours=i+1),
                'end_time': timezone.now() - timedelta(hours=i),
                'status': 'completed' if i < 2 else 'failed',
                'total_steps': 5,
                'passed_steps': 4 if i < 2 else 2,
                'failed_steps': 1 if i < 2 else 3,
                'skipped_steps': 0,
                'environment': 'Production',
                'browser_type': 'Chrome',
                'error_message': 'Step 3 failed due to timeout' if i == 2 else None
            }
        )
        
        if created:
            print(f"Created job execution {exec_id}")
            
            # Create sample step executions
            step_names = [
                'Navigate to Login Page',
                'Enter Username',
                'Enter Password',
                'Click Login Button',
                'Verify Dashboard Loaded'
            ]
            
            for j, step_name in enumerate(step_names):
                step_status = 'passed'
                step_error = None
                
                if i == 2 and j == 2:  # Third execution, third step fails
                    step_status = 'failed'
                    step_error = 'Element not found: password field'
                
                step, created = JobExecutionStep.objects.get_or_create(
                    execution=execution,
                    step_order=j+1,
                    defaults={
                        'step_name': step_name,
                        'step_description': f'Executing step {j+1}: {step_name}',
                        'status': step_status,
                        'start_time': execution.start_time + timedelta(minutes=j),
                        'end_time': execution.start_time + timedelta(minutes=j+1),
                        'input_data': 'testuser' if j == 1 else 'testpass' if j == 2 else None,
                        'expected_result': 'Dashboard page loaded successfully' if j == 4 else None,
                        'actual_result': 'Step completed successfully' if step_status == 'passed' else 'Step failed',
                        'error_message': step_error,
                        'duration': timedelta(minutes=1)
                    }
                )
                
                if created:
                    print(f"  Created step: {step_name}")
    
    # Create JobAuditLog entries
    audit_events = [
        ('start', 'Job execution started', 'running'),
        ('step', 'Step 1 completed successfully', 'success'),
        ('step', 'Step 2 completed successfully', 'success'),
        ('step', 'Step 3 failed', 'fail'),
        ('end', 'Job execution completed with errors', 'fail')
    ]
    
    for event_type, message, status in audit_events:
        audit_log, created = JobAuditLog.objects.get_or_create(
            job=job,
            event_type=event_type,
            message=message,
            status=status,
            defaults={
                'user': user,
                'execution_id': execution_ids[0],
                'created_at': timezone.now() - timedelta(minutes=len(audit_events) - audit_events.index((event_type, message, status)))
            }
        )
        
        if created:
            print(f"Created audit log: {event_type}")
    
    print("\nTest data setup complete!")
    print(f"You can now view the enhanced job history at: /job-hist/")
    print(f"The job '{job.job_name}' now has detailed execution tracking")
    print(f"Check the expandable rows to see pass/fail/incomplete details")

if __name__ == '__main__':
    try:
        create_test_data()
    except Exception as e:
        print(f"Error creating test data: {e}")
        import traceback
        traceback.print_exc()
