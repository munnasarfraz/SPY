#!/usr/bin/env python
"""
Debug script to check KeyWord_1 with ID 140
"""
import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from autoai.models import KeyWord_1, Steps_1

def check_keyword_140():
    """Check if KeyWord_1 with ID 140 exists"""
    print("=== Checking KeyWord_1 with ID 140 ===")
    
    try:
        # Check if KeyWord_1 with ID 140 exists
        keyword = KeyWord_1.objects.filter(id=140).first()
        if keyword:
            print(f"✅ Found KeyWord_1: {keyword}")
            print(f"   ID: {keyword.id}")
            print(f"   Name: {keyword.keyword_Name}")
            print(f"   Description: {keyword.keyword_Desc}")
            print(f"   User: {keyword.u}")
            print(f"   Project: {keyword.p}")
            
            # Check related Steps_1
            steps = Steps_1.objects.filter(k_id=140)
            print(f"   Related Steps: {steps.count()}")
            for step in steps[:5]:  # Show first 5 steps
                print(f"     - {step.step_Descriptions}")
        else:
            print("❌ KeyWord_1 with ID 140 not found")
            
            # Check what IDs exist
            all_keywords = KeyWord_1.objects.all().order_by('-id')[:10]
            print(f"\nLast 10 KeyWord_1 IDs:")
            for k in all_keywords:
                print(f"   ID: {k.id}, Name: {k.keyword_Name}")
                
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    check_keyword_140()
