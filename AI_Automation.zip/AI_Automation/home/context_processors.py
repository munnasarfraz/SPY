from typing import Dict
from django.http import HttpRequest
from autoai.models import MyAppUser


def user_avatar(request: HttpRequest) -> Dict[str, str]:
    """Provide the current user's avatar URL to all templates.

    Falls back to the default static avatar when not authenticated or not set.
    """
    default_url = "/static/img/undraw_profile.svg"
    try:
        user = getattr(request, "user", None)
        if user and user.is_authenticated:
            try:
                app_user = MyAppUser.objects.get(user_id=user.id)
                if app_user.image:
                    return {"user_avatar_url": app_user.image}
            except MyAppUser.DoesNotExist:
                pass
    except Exception:
        # Be resilient; never break template rendering due to avatar lookup
        pass
    return {"user_avatar_url": default_url}


