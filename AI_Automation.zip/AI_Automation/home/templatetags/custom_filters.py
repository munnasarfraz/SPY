# your_app/templatetags/custom_filters.py
import re
from django import template

register = template.Library()

@register.filter(name='split_steps')
def split_steps(value):
    # Regular expression to match each numbered step
    pattern = r'(\d+\.\s*[^0-9]+)'
    # Use re.findall to find all steps in the string
    steps = re.findall(pattern, value)

    # Return the steps as a list
    return steps

@register.filter(name='is_numeric')
def is_numeric(value):
    """Check if a value is numeric (integer or float)"""
    try:
        float(value)
        return True
    except (ValueError, TypeError):
        return False


