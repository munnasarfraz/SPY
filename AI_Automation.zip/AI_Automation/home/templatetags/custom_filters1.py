# your_app/templatetags/custom_filters.py
import re
from django import template

register = template.Library()


# Custom filter to get an item from a dictionary by key or a tuple/list by index
@register.filter(name='get_item')
def get_item(value, key):
    """
    Custom filter to get a value from a dictionary by key or from a tuple/list by index.
    """
    if isinstance(value, dict):  # Check if value is a dictionary
        return value.get(key, None)
    elif isinstance(value, (list, tuple)):  # Check if value is a list or tuple
        try:
            return value[int(key)]
        except (ValueError, IndexError):
            return None
    return None  # Return None if it's not a dictionary or list/tuple

# Custom filter to get the first element from a tuple
@register.filter(name='get_first')
def get_first(value):
    """
    Custom filter to get the first element from a tuple.
    """
    if isinstance(value, tuple) and len(value) > 0:
        return value[0]
    return None

# Custom filter to get the second element from a tuple
@register.filter(name='get_second')
def get_second(value):
    """
    Custom filter to get the second element from a tuple.
    """
    if isinstance(value, tuple) and len(value) > 1:
        return value[1]
    return None



