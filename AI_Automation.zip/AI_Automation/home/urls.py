from django.urls import path
from . import views
from autoai.views import recepies, delete_recepi, update_recepi, login_page, logout_page, register, profile_update

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('recepies/', recepies, name='recepies'),
    path('delete-recepi/<id>/', delete_recepi, name='delete_recepi'),
    path('update-recepi/<id>/', update_recepi, name='update_recepi'),
    
    path('login/', login_page, name='login_page'),
    path('logout/', logout_page, name='logout_page'),
    path('register/', register, name='register'),
    path('profile/<id>/', profile_update, name='profile_update'),
]