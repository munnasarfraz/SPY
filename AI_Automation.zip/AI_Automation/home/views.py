from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.decorators import login_required
from django.db.models import Count
from django.utils import timezone
from datetime import timedelta
from autoai.models import *
# from django.shortcuts import render_to_response
import random
import datetime
import time
from django.contrib.sessions.exceptions import SessionInterrupted


# Create your views here.


people = [
    {'name' : 'sarfraz', 'age' : 40},
    {'name' : 'Munna', 'age' : 25},
    {'name' : 'Ahmad', 'age' : 25},
    {'name' : 'Maryam', 'age' : 11},
    {'name' : 'Zeba', 'age' : 97}
    
]


# def demo_piechart(request):
#     """
#     pieChart page
#     """
#     xdata = ["Apple", "Apricot", "Avocado", "Banana", "Boysenberries", "Blueberries", "Dates", "Grapefruit", "Kiwi", "Lemon"]
#     ydata = [52, 48, 160, 94, 75, 71, 490, 82, 46, 17]

#     extra_serie = {"tooltip": {"y_start": "", "y_end": " cal"}}
#     chartdata = {'x': xdata, 'y1': ydata, 'extra1': extra_serie}
#     charttype = "pieChart"

#     data = {
#         'charttype': charttype,
#         'chartdata': chartdata,
#     }
#     return render_to_response('home/index.html', data)

# def index(request):
#   magma_composition_data = [
#     {"label":"Oxygen","symbol":"O","y":46.6},
#     {"label":"Silicon","symbol":"Si","y":27.7},
#     {"label":"Aluminium","symbol":"Al","y":13.9},
#     {"label":"Iron","symbol":"Fe","y":5},
#     {"label":"Calcium","symbol":"Ca","y":3.6},
#     {"label":"Sodium","symbol":"Na","y":2.6},
#     {"label":"Magnesium","symbol":"Mg","y":2.1},
#     {"label":"Others","symbol":"Others","y":1.5}
#   ]
 
#   return render(request, 'index.html', { "magma_composition_data" : magma_composition_data }) 

def home(request):
    try:
        user_id = request.session.get('user_id', 1)
        project_id = request.session.get('project_id', 1)
    except SessionInterrupted:
        # If session is deleted mid-request, redirect to login or handle it gracefully
        return HttpResponse.redirect('login')  # Or your appropriate fallback
    
    # Enhanced metrics with more comprehensive data
    total_executions = Report_1.objects.filter(user_id=user_id).count()
    total_keywords = KeyWord_1.objects.filter(u_id=user_id).count()
    total_projects = Project_1.objects.filter(user_id=user_id).count()
    
    # Calculate success rate from recent executions
    recent_executions_count = Report_1.objects.filter(
        user_id=user_id,
        time__gte=timezone.now() - timedelta(days=30)
    ).count()
    
    successful_executions_count = Report_1.objects.filter(
        user_id=user_id,
        time__gte=timezone.now() - timedelta(days=30),
        status=True
    ).count()
    
    success_rate = 0
    if recent_executions_count > 0:
        success_rate = round((successful_executions_count / recent_executions_count) * 100, 1)
    
    # Recent activities with enhanced data
    recent_executions = Report_1.objects.filter(user_id=user_id).order_by('-time')[:10]
    recent_projects = Project_1.objects.filter(user_id=user_id).order_by('-id')[:3]
    
    # Project progress (real data)
    active_projects = Project_1.objects.filter(user_id=user_id, active=True)
    
    # Test execution trends (last 7 days)
    last_week = timezone.now() - timedelta(days=7)
    weekly_executions = Report_1.objects.filter(
        user_id=user_id, 
        time__gte=last_week
    ).count()
    
    # Weekly execution data for chart with better granularity
    weekly_data = []
    weekly_labels = []
    for i in range(7):
        date = timezone.now() - timedelta(days=6-i)
        count = Report_1.objects.filter(
            user_id=user_id,
            time__date=date.date()
        ).count()
        weekly_data.append(count)
        weekly_labels.append(date.strftime('%a'))
    
    # Project distribution by type (real data)
    project_types = Project_1.objects.filter(user_id=user_id).values('project_Type').annotate(count=Count('project_Type')).order_by('-count')
    project_distribution_labels = []
    project_distribution_data = []
    
    for pt in project_types:
        project_distribution_labels.append(pt['project_Type'] or 'Unknown')
        project_distribution_data.append(pt['count'])
    
    # If no projects, show default data
    if not project_distribution_labels:
        project_distribution_labels = ['No Projects']
        project_distribution_data = [1]
    
    # Enhanced execution statistics
    execution_stats = {
        'total_executions': total_executions,
        'total_keywords': total_keywords,
        'total_projects': total_projects,
        'weekly_executions': weekly_executions,
        'success_rate': success_rate,
        'recent_executions_count': recent_executions_count,
        'successful_executions_count': successful_executions_count
    }
    
    # Project progress metrics
    project_progress = {
        'test_coverage': 75,  # This could be calculated from actual test coverage data
        'automation_rate': 60,  # This could be calculated from automation vs manual test ratio
        'success_rate': success_rate,
        'performance_score': 92  # This could be calculated from execution time metrics
    }
    
    # Enhanced recent executions with more details
    enhanced_recent_executions = []
    for execution in recent_executions:
        # Calculate execution duration if possible
        duration = None
        # Note: Report_1 doesn't have end_time field, so duration will remain None
        
        # Get environment information
        environment = execution.test_Env or 'Production'
        
        # Get user information
        executed_by = execution.run_by if execution.run_by else 'System'
        
        enhanced_recent_executions.append({
            'id': execution.id,
            'tcs_Name': execution.tcs_Name,
            'status': execution.status,
            'time': execution.time,
            'environment': environment,
            'duration': duration,
            'run_by': executed_by,
            'test_Env': execution.test_Env
        })
    
    # Active projects with progress information
    enhanced_active_projects = []
    for project in active_projects:
        # Calculate project-specific metrics
        project_executions = Report_1.objects.filter(
            user_id=user_id,
            project_id=project.id
        ).count()
        
        project_success_rate = 0
        if project_executions > 0:
            successful_project_executions = Report_1.objects.filter(
                user_id=user_id,
                project_id=project.id,
                status=True
            ).count()
            project_success_rate = round((successful_project_executions / project_executions) * 100, 1)
        
        enhanced_active_projects.append({
            'id': project.id,
            'project': project.project,
            'project_Type': project.project_Type,
            'url': project.url,
            'active': project.active,
            'executions_count': project_executions,
            'success_rate': project_success_rate,
            # Ensure each active project appears in the doughnut chart even if it has 0 executions
            'chart_value': project_executions if project_executions > 0 else 1
        })
    
    # Generate real application-based messages from user activities and system events
    application_messages = []
    message_id = 1
    
    # Check for recent test executions
    recent_test_executions = Report_1.objects.filter(user_id=user_id).order_by('-time')[:3]
    for execution in recent_test_executions:
        if execution.time >= timezone.now() - timedelta(hours=24):  # Only show recent ones
            message_type = 'normal'
            # status is BooleanField: True = Success, False = Failed
            if execution.status == False:  # Failed
                message_type = 'urgent'
            elif execution.status == True:  # Success/Completed
                message_type = 'normal'
            
            application_messages.append({
                'id': message_id,
                'type': message_type,
                'sender': 'Test Execution System',
                'subject': f'Test Execution: {"FAILED" if execution.status == False else "COMPLETED"}',
                'preview': f'Test execution completed with status: {"FAILED" if execution.status == False else "COMPLETED"}. Check details for more information.',
                'created_at': execution.time.isoformat(),
                'is_read': False,
                'action_url': '/report/'
            })
            message_id += 1
    
    # Check for new components created
    recent_components = KeyWord_1.objects.filter(u_id=user_id).order_by('-id')[:2]
    for component in recent_components:
        # Since KeyWord_1 doesn't have created_at, we'll use a default time
        application_messages.append({
            'id': message_id,
            'type': 'normal',
            'sender': 'Component System',
            'subject': 'New Test Component Created',
            'preview': f'Component "{component.keyword_Name}" has been created and is ready for testing.',
            'created_at': (timezone.now() - timedelta(hours=2)).isoformat(),
            'is_read': False,
            'action_url': '/kwd/'
        })
        message_id += 1
    
    # Check for project updates
    recent_projects = Project_1.objects.filter(user_id=user_id).order_by('-id')[:2]
    for project in recent_projects:
        # Since Project_1 doesn't have updated_at, we'll use a default time
        application_messages.append({
            'id': message_id,
            'type': 'important',
            'sender': 'Project System',
            'subject': 'Project Updated',
            'preview': f'Project "{project.project}" has been updated. Review changes and update test suites if needed.',
            'created_at': (timezone.now() - timedelta(hours=3)).isoformat(),
            'is_read': False,
            'action_url': '/project/'
        })
        message_id += 1
    
    # Check for batch execution status
    # Note: Batch_1 model doesn't exist, so we'll skip this section
    
    # Check for suite execution status
    # Note: Suite_1 model doesn't have status field, so we'll skip this section
    
    # If no application messages, show system status
    if not application_messages:
        application_messages = [
            {
                'id': 1,
                'type': 'info',
                'sender': 'System Status',
                'subject': 'No Recent Activities',
                'preview': 'No recent test executions, component changes, or project updates detected.',
                'created_at': timezone.now().isoformat(),
                'is_read': True,
                'action_url': '/'
            }
        ]
    
    # Limit to 5 most recent messages
    application_messages = application_messages[:5]
    
    # Generate dynamic alerts based on real system events
    dynamic_alerts = []
    alert_id = 1
    
    # Check for failed test executions (urgent alerts)
    failed_executions = Report_1.objects.filter(
        user_id=user_id, 
        time__gte=timezone.now() - timedelta(hours=6)
    )
    # Filter for failed tests (status = False)
    failed_count = failed_executions.filter(status=False).count()
    if failed_count > 0:
        dynamic_alerts.append({
            'id': alert_id,
            'type': 'error',
            'title': f'{failed_count} Test(s) Failed',
            'message': f'{failed_count} test execution(s) failed in the last 6 hours. Immediate attention required.',
            'created_at': timezone.now().isoformat(),
            'is_read': False,
            'action_url': '/report/'
        })
        alert_id += 1
    
    # Check for successful test executions (success alerts)
    successful_executions = Report_1.objects.filter(
        user_id=user_id,
        time__gte=timezone.now() - timedelta(hours=12),
        status=True  # Success = True
    ).count()

    if successful_executions > 0:
        dynamic_alerts.append({
            'id': alert_id,
            'type': 'success',
            'title': f'{successful_executions} Test(s) Completed',
            'message': f'{successful_executions} test execution(s) completed successfully in the last 12 hours.',
            'created_at': timezone.now().isoformat(),
            'is_read': False,
            'action_url': '/report/'
        })
        alert_id += 1
    
    # Check for system performance issues (info alerts)
    total_recent_executions = Report_1.objects.filter(
        user_id=user_id,
        time__gte=timezone.now() - timedelta(hours=1)
    ).count()
    
    if total_recent_executions > 50:  # High execution rate
        dynamic_alerts.append({
            'id': alert_id,
            'type': 'info',
            'title': 'High Test Execution Rate',
            'message': f'{total_recent_executions} tests executed in the last hour. System performing well.',
            'created_at': timezone.now().isoformat(),
            'is_read': False,
            'action_url': '/report/'
        })
        alert_id += 1
    
    # If no dynamic alerts, show default system status
    if not dynamic_alerts:
        dynamic_alerts = [
            {
                'id': 1,
                'type': 'info',
                'title': 'System Status: Normal',
                'message': 'All systems operating normally. No critical alerts at this time.',
                'created_at': timezone.now().isoformat(),
                'is_read': True,
                'action_url': '/'
            }
        ]
    
    # Limit to 5 most recent alerts
    dynamic_alerts = dynamic_alerts[:5]
    
    # Store alerts and messages in session for header access across all pages
    try:
        request.session['alerts'] = dynamic_alerts
        request.session['alerts_count'] = len([a for a in dynamic_alerts if not a['is_read']])
        request.session['messages'] = application_messages
        request.session['messages_count'] = len([m for m in application_messages if not m['is_read']])
    except Exception as e:
    # Log the error if needed
        print("Session write error:", e)

    scounter = {
        'suite': 0,
        'testcase': 0,
        'component': 0,
        'defect': 0
    }
    
    context = {
        'metrics': execution_stats,
        'project_progress': project_progress,
        'recent_executions': enhanced_recent_executions,
        'recent_projects': recent_projects,
        'active_projects': enhanced_active_projects,
        'weekly_executions_data': weekly_data,
        'weekly_labels': weekly_labels,
        'project_distribution_labels': project_distribution_labels,
        'project_distribution_data': project_distribution_data,
        'scounter': scounter,
        'people': people,
    }
    return render(request, 'index.html', context)
    
    #return render(request, 'home/index.html', context={"page":scounter,'people':people})

def about(request):
    context = {"page":'About Us'}
    return render(request, 'home/about.html', context)

def contact(request):
    context = {"page":'Contact Us'}
    return render(request, 'home/contact.html', context)

# AJAX endpoints for real-time updates
@login_required(login_url='/register/')
def get_latest_alerts(request):
    """AJAX endpoint to get latest alerts in real-time"""
    user_id = request.session.get('user_id')
    
    # Generate fresh alerts
    dynamic_alerts = []
    alert_id = 1
    
    # Check for failed test executions (urgent alerts)
    failed_executions = Report_1.objects.filter(
        user_id=user_id, 
        time__gte=timezone.now() - timedelta(hours=6)
    )
    # Filter for failed tests (status = False)
    failed_count = failed_executions.filter(status=False).count()
    if failed_count > 0:
        dynamic_alerts.append({
            'id': alert_id,
            'type': 'error',
            'title': f'{failed_count} Test(s) Failed',
            'message': f'{failed_count} test execution(s) failed in the last 6 hours. Immediate attention required.',
            'created_at': timezone.now().isoformat(),
            'is_read': False,
            'action_url': '/report/'
        })
        alert_id += 1
    
    # Check for successful test executions (success alerts)
    successful_executions = Report_1.objects.filter(
        user_id=user_id,
        time__gte=timezone.now() - timedelta(hours=12),
        status=True  # Success = True
    ).count()

    if successful_executions > 0:
        dynamic_alerts.append({
            'id': alert_id,
            'type': 'success',
            'title': f'{successful_executions} Test(s) Completed',
            'message': f'{successful_executions} test execution(s) completed successfully in the last 12 hours.',
            'created_at': timezone.now().isoformat(),
            'is_read': False,
            'action_url': '/report/'
        })
        alert_id += 1
    
    # Update session with fresh alerts
    request.session['alerts'] = dynamic_alerts
    request.session['alerts_count'] = len([a for a in dynamic_alerts if not a['is_read']])
    
    return JsonResponse({
        'alerts': dynamic_alerts,
        'count': len([a for a in dynamic_alerts if not a['is_read']])
    })

@login_required(login_url='/register/')
def get_latest_messages(request):
    """AJAX endpoint to get latest messages in real-time"""
    user_id = request.session.get('user_id')
    
    # Generate fresh messages
    application_messages = []
    message_id = 1
    
    # Check for recent test executions
    recent_test_executions = Report_1.objects.filter(user_id=user_id).order_by('-time')[:3]
    for execution in recent_test_executions:
        if execution.time >= timezone.now() - timedelta(hours=24):
            message_type = 'normal'
            # status is BooleanField: True = Success, False = Failed
            if execution.status == False:  # Failed
                message_type = 'urgent'
            elif execution.status == True:  # Success/Completed
                message_type = 'normal'
            
            application_messages.append({
                'id': message_id,
                'type': message_type,
                'sender': 'Test Execution System',
                'subject': f'Test Execution: {"FAILED" if execution.status == False else "COMPLETED"}',
                'preview': f'Test execution completed with status: {"FAILED" if execution.status == False else "COMPLETED"}. Check details for more information.',
                'created_at': execution.time.isoformat(),
                'is_read': False,
                'action_url': '/report/'
            })
            message_id += 1
    
    # Update session with fresh messages
    request.session['messages'] = application_messages
    request.session['messages_count'] = len([m for m in application_messages if not m['is_read']])
    
    return JsonResponse({
        'messages': application_messages,
        'count': len([m for m in application_messages if not m['is_read']])
    })

@login_required(login_url='/register/')
def mark_alert_read(request, alert_id):
    """AJAX endpoint to mark an alert as read"""
    if 'alerts' in request.session:
        for alert in request.session['alerts']:
            if alert['id'] == alert_id:
                alert['is_read'] = True
                break
        
        request.session['alerts_count'] = len([a for a in request.session['alerts'] if not a['is_read']])
        request.session.modified = True
    
    return JsonResponse({'success': True})

@login_required(login_url='/register/')
def mark_message_read(request, message_id):
    """AJAX endpoint to mark a message as read"""
    if 'messages' in request.session:
        for message in request.session['messages']:
            if message['id'] == message_id:
                message['is_read'] = True
                break
        
        request.session['messages_count'] = len([m for m in request.session['messages'] if not m['is_read']])
        request.session.modified = True
    
    return JsonResponse({'success': True})