#!/usr/bin/env python
"""
Quick Database Cleanup Script
Deletes all rows from specified tables without interactive prompts.

Usage: python quick_cleanup.py

WARNING: This will permanently delete all data from these tables!
"""

import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

def quick_cleanup():
    """Quickly delete all records from specified tables"""
    try:
        # Import models
        from autoai.models import KeyWord_1, Steps_1, Report_1, Report_Steps_1, JobAuditLog, JobExecution, JobExecutionStep, Lab_1, MainBatch_1, Suite_1
        from tocop.models import Automation, Requirement as TocopRequirement, SelectedRow, TestCase as TocopTestCase
        from requirement.models import Requirement, RequirementTraceabilityMatrix, TestCase
        
        print("Quick Database Cleanup - DELETING ALL DATA!")
        print("=" * 50)
        
        # Count records before deletion
        keyword_count = KeyWord_1.objects.count()
        steps_count = Steps_1.objects.count()
        automation_count = Automation.objects.count()
        report_count = Report_1.objects.count()
        report_steps_count = Report_Steps_1.objects.count()
        requirement_count = Requirement.objects.count()
        traceability_count = RequirementTraceabilityMatrix.objects.count()
        testcase_count = TestCase.objects.count()
        jobauditlog_count = JobAuditLog.objects.count()
        jobexecution_count = JobExecution.objects.count()
        jobexecutionstep_count = JobExecutionStep.objects.count()
        lab_count = Lab_1.objects.count()
        mainbatch_count = MainBatch_1.objects.count()
        suite_count = Suite_1.objects.count()
        tocop_requirement_count = TocopRequirement.objects.count()
        tocop_selectedrow_count = SelectedRow.objects.count()
        tocop_testcase_count = TocopTestCase.objects.count()
        
        print(f"Before cleanup:")
        print(f"  KeyWord_1: {keyword_count}")
        print(f"  Steps_1: {steps_count}")
        print(f"  Automation: {automation_count}")
        print(f"  Report_1: {report_count}")
        print(f"  Report_Steps_1: {report_steps_count}")
        print(f"  requirement_requirement: {requirement_count}")
        print(f"  requirement_requirementtraceabilitymatrix: {traceability_count}")
        print(f"  requirement_testcase: {testcase_count}")
        print(f"  autoai_jobauditlog: {jobauditlog_count}")
        print(f"  autoai_jobexecution: {jobexecution_count}")
        print(f"  autoai_jobexecutionstep: {jobexecutionstep_count}")
        print(f"  autoai_lab_1: {lab_count}")
        print(f"  autoai_mainbatch_1: {mainbatch_count}")
        print(f"  autoai_suite_1: {suite_count}")
        print(f"  tocop_requirement: {tocop_requirement_count}")
        print(f"  tocop_selectedrow: {tocop_selectedrow_count}")
        print(f"  tocop_testcase: {tocop_testcase_count}")
        
        # Delete records in correct order (respecting foreign key constraints)
        print(f"\nDeleting records...")
        
        # Delete Steps_1 first (has foreign key to KeyWord_1)
        deleted_steps = Steps_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_steps[0]} Steps_1 records")
        
        # Delete Report_Steps_1 (has foreign key to Report_1)
        deleted_report_steps = Report_Steps_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_report_steps[0]} Report_Steps_1 records")
        
        # Delete JobExecutionStep (has foreign key to JobExecution)
        deleted_jobexecutionsteps = JobExecutionStep.objects.all().delete()
        print(f"  ✓ Deleted {deleted_jobexecutionsteps[0]} JobExecutionStep records")
        
        # Delete JobAuditLog (has foreign key to Lab_1)
        deleted_jobauditlogs = JobAuditLog.objects.all().delete()
        print(f"  ✓ Deleted {deleted_jobauditlogs[0]} JobAuditLog records")
        
        # Delete JobExecution (has foreign key to Lab_1)
        deleted_jobexecutions = JobExecution.objects.all().delete()
        print(f"  ✓ Deleted {deleted_jobexecutions[0]} JobExecution records")
        
        # Delete Automation (has foreign key to TestCase)
        deleted_automations = Automation.objects.all().delete()
        print(f"  ✓ Deleted {deleted_automations[0]} Automation records")
        
        # Delete RequirementTraceabilityMatrix (has foreign keys to Requirement and TestCase)
        deleted_traceability = RequirementTraceabilityMatrix.objects.all().delete()
        print(f"  ✓ Deleted {deleted_traceability[0]} RequirementTraceabilityMatrix records")
        
        # Delete TestCase
        deleted_testcases = TestCase.objects.all().delete()
        print(f"  ✓ Deleted {deleted_testcases[0]} TestCase records")
        
        # Delete TocopTestCase
        deleted_tocop_testcases = TocopTestCase.objects.all().delete()
        print(f"  ✓ Deleted {deleted_tocop_testcases[0]} TocopTestCase records")
        
        # Delete TocopRequirement
        deleted_tocop_requirements = TocopRequirement.objects.all().delete()
        print(f"  ✓ Deleted {deleted_tocop_requirements[0]} TocopRequirement records")
        
        # Delete SelectedRow
        deleted_selectedrows = SelectedRow.objects.all().delete()
        print(f"  ✓ Deleted {deleted_selectedrows[0]} SelectedRow records")
        
        # Delete Requirement
        deleted_requirements = Requirement.objects.all().delete()
        print(f"  ✓ Deleted {deleted_requirements[0]} Requirement records")
        
        # Delete Lab_1 (has foreign key to User)
        deleted_labs = Lab_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_labs[0]} Lab_1 records")
        
        # Delete Suite_1 (has foreign key to MainBatch_1)
        deleted_suites = Suite_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_suites[0]} Suite_1 records")
        
        # Delete MainBatch_1
        deleted_mainbatches = MainBatch_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_mainbatches[0]} MainBatch_1 records")
        
        # Delete KeyWord_1
        deleted_keywords = KeyWord_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_keywords[0]} KeyWord_1 records")
        
        # Delete Report_1
        deleted_reports = Report_1.objects.all().delete()
        print(f"  ✓ Deleted {deleted_reports[0]} Report_1 records")
        
        # Verify cleanup
        remaining_keywords = KeyWord_1.objects.count()
        remaining_steps = Steps_1.objects.count()
        remaining_automations = Automation.objects.count()
        remaining_reports = Report_1.objects.count()
        remaining_report_steps = Report_Steps_1.objects.count()
        remaining_requirements = Requirement.objects.count()
        remaining_traceability = RequirementTraceabilityMatrix.objects.count()
        remaining_testcases = TestCase.objects.count()
        remaining_jobauditlogs = JobAuditLog.objects.count()
        remaining_jobexecutions = JobExecution.objects.count()
        remaining_jobexecutionsteps = JobExecutionStep.objects.count()
        remaining_labs = Lab_1.objects.count()
        remaining_mainbatches = MainBatch_1.objects.count()
        remaining_suites = Suite_1.objects.count()
        remaining_tocop_requirements = TocopRequirement.objects.count()
        remaining_tocop_selectedrows = SelectedRow.objects.count()
        remaining_tocop_testcases = TocopTestCase.objects.count()
        
        print(f"\nAfter cleanup:")
        print(f"  KeyWord_1: {remaining_keywords}")
        print(f"  Steps_1: {remaining_steps}")
        print(f"  Automation: {remaining_automations}")
        print(f"  Report_1: {remaining_reports}")
        print(f"  Report_Steps_1: {remaining_report_steps}")
        print(f"  requirement_requirement: {remaining_requirements}")
        print(f"  requirement_requirementtraceabilitymatrix: {remaining_traceability}")
        print(f"  requirement_testcase: {remaining_testcases}")
        print(f"  autoai_jobauditlog: {remaining_jobauditlogs}")
        print(f"  autoai_jobexecution: {remaining_jobexecutions}")
        print(f"  autoai_jobexecutionstep: {remaining_jobexecutionsteps}")
        print(f"  autoai_lab_1: {remaining_labs}")
        print(f"  autoai_mainbatch_1: {remaining_mainbatches}")
        print(f"  autoai_suite_1: {remaining_suites}")
        print(f"  tocop_requirement: {remaining_tocop_requirements}")
        print(f"  tocop_selectedrow: {remaining_tocop_selectedrows}")
        print(f"  tocop_testcase: {remaining_tocop_testcases}")
        
        # Check if cleanup was successful
        total_remaining = (remaining_keywords + remaining_steps + remaining_automations + 
                          remaining_reports + remaining_report_steps + remaining_requirements +
                          remaining_traceability + remaining_testcases + remaining_jobauditlogs +
                          remaining_jobexecutions + remaining_jobexecutionsteps + remaining_labs +
                          remaining_mainbatches + remaining_suites + remaining_tocop_requirements +
                          remaining_tocop_selectedrows + remaining_tocop_testcases)
        
        if total_remaining == 0:
            print(f"\n✅ SUCCESS: All records deleted!")
        else:
            print(f"\n⚠️  WARNING: {total_remaining} records still remain.")
        
        print("=" * 50)
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        return False
    
    return True

if __name__ == "__main__":
    quick_cleanup()
