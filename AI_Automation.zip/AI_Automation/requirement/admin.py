from django.contrib import admin
from .models import Requirement, TestCase, RequirementTraceabilityMatrix

# Register your models here.
admin.site.register(Requirement)
admin.site.register(TestCase)

@admin.register(RequirementTraceabilityMatrix)
class RequirementTraceabilityMatrixAdmin(admin.ModelAdmin):
    list_display = ('requirement', 'test_case', 'automation_status', 'execution_status', 'last_execution_date')
    list_filter = ('automation_status', 'execution_status')
    search_fields = ('requirement__title', 'test_case__test_case_id', 'test_case__scenario_name')
    date_hierarchy = 'last_execution_date'
