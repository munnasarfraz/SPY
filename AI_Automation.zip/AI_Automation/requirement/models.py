from django.db import models
from django.contrib.auth.models import User
from autoai.models import Report_1

class Requirement(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='requirement_requirements')
    title = models.CharField(max_length=200)
    description = models.TextField()
    url = models.URLField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    project_id = models.IntegerField(blank=True, null=True)
    
    def __str__(self):
        return self.title

class TestCase(models.Model):
    requirement = models.ForeignKey(Requirement, on_delete=models.CASCADE, related_name='test_cases')
    test_case_id = models.CharField(max_length=100)  # field_1
    scenario_name = models.CharField(max_length=200)  # field_2
    description = models.TextField()  # field_3
    preconditions = models.TextField(blank=True, null=True)  # field_4
    test_data = models.TextField(blank=True, null=True)  # field_5
    test_steps = models.TextField(blank=True, null=True)  # field_6
    expected_results = models.TextField(blank=True, null=True)  # field_7
    url = models.URLField(blank=True, null=True)  # field_8
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.test_case_id} - {self.scenario_name}"

class RequirementTraceabilityMatrix(models.Model):
    """Model to track test execution against requirements"""
    requirement = models.ForeignKey(Requirement, on_delete=models.CASCADE, related_name='traceability_entries')
    test_case = models.ForeignKey(TestCase, on_delete=models.CASCADE, related_name='traceability_entries')
    last_execution = models.ForeignKey(Report_1, on_delete=models.SET_NULL, null=True, blank=True, related_name='traceability_entries')
    automation_status = models.CharField(max_length=50, default='Not Automated', 
                                      choices=[
                                          ('Not Automated', 'Not Automated'),
                                          ('Automated', 'Automated'),
                                          ('In Progress', 'In Progress'),
                                          ('Blocked', 'Blocked')
                                      ])
    execution_status = models.CharField(max_length=50, default='Not Executed', 
                                     choices=[
                                         ('Not Executed', 'Not Executed'),
                                         ('Passed', 'Passed'),
                                         ('Failed', 'Failed'),
                                         ('Blocked', 'Blocked'),
                                         ('Skipped', 'Skipped')
                                     ])
    last_execution_date = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ('requirement', 'test_case')
        verbose_name = 'Requirement Traceability Matrix'
        verbose_name_plural = 'Requirement Traceability Matrix'
    
    def __str__(self):
        return f"{self.requirement.title} - {self.test_case.test_case_id}"
    
    def update_from_report(self, report):
        """Update execution status based on test report"""
        if report:
            self.last_execution = report
            self.execution_status = 'Passed' if report.status else 'Failed'
            self.last_execution_date = report.time
            self.save()
