from django.urls import path
from . import views

urlpatterns = [
    # Main requirement views
    path('', views.requirement_home, name='requirement_home'),
    path('list/', views.requirements_list, name='requirements_list'),
    
    # Requirement CRUD operations
    path('edit/<int:requirement_id>/', views.requirement_edit, name='requirement_edit'),
    path('delete/<int:requirement_id>/', views.requirement_delete, name='requirement_delete'),
    
    # Test case views
    path('test-cases/', views.test_case_list, name='test_case_list'),
    path('test-cases/edit/<int:test_case_id>/', views.test_case_edit, name='test_case_edit'),
    
    # Traceability matrix
    path('traceability-matrix/', views.requirements_traceability_matrix, name='requirements_traceability_matrix'),
    path('update-traceability/', views.update_traceability_matrix, name='update_traceability_matrix'),
    # Bulk generate automation for selected test cases
    path('generate-automation-selected/', views.generate_automation_for_selected, name='generate_automation_for_selected'),
    path('review-automation-steps/', views.review_automation_steps, name='review_automation_steps'),
    path('save-automation-steps/', views.save_reviewed_automation_steps, name='save_reviewed_automation_steps'),
    
    # Automation generation
    path('generate-automation/<str:test_case_id>/', views.generate_automation_for_testcase, name='generate_automation_for_testcase'),
    
    # Bulk sync test cases
    path('bulk-sync-test-cases/', views.bulk_sync_test_cases, name='bulk_sync_test_cases'),
]
