from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Count, Q
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db import connection
from django.http import HttpResponse

import re
import json
import time
import sys

from .models import Requirement, TestCase, RequirementTraceabilityMatrix
from autoai.models import Report_1, KeyWord_1, Steps_1, conf_1
import google.generativeai as genai
from django.conf import settings

# Document processing imports
try:
    import PyPDF2
    import docx
    from docx import Document
    DOCUMENT_PROCESSING_AVAILABLE = True
except ImportError:
    DOCUMENT_PROCESSING_AVAILABLE = False


def extract_text_from_doc(file):
    """Extract text from DOC/DOCX files"""
    if not DOCUMENT_PROCESSING_AVAILABLE:
        raise ImportError("Document processing libraries not available. Please install python-docx.")
    
    try:
        # Reset file pointer to beginning
        file.seek(0)
        
        if file.name.endswith('.docx'):
            # Handle DOCX files
            doc = Document(file)
            text_content = []
            for paragraph in doc.paragraphs:
                text_content.append(paragraph.text)
            return '\n'.join(text_content)
        else:
            # Handle older DOC files (requires additional library)
            # For now, return an error message
            return "Error: .doc files are not supported. Please convert to .docx format."
            
    except Exception as e:
        return f"Error reading document: {str(e)}"


def extract_text_from_pdf(file):
    """Extract text from PDF files"""
    if not DOCUMENT_PROCESSING_AVAILABLE:
        raise ImportError("Document processing libraries not available. Please install PyPDF2.")
    
    try:
        # Reset file pointer to beginning
        file.seek(0)
        
        pdf_reader = PyPDF2.PdfReader(file)
        text_content = []
        
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text_content.append(page.extract_text())
        
        return '\n'.join(text_content)
        
    except Exception as e:
        return f"Error reading PDF: {str(e)}"


def extract_urls_from_text(text):
    """Extract URLs from text content"""
    import re
    
    # URL regex pattern
    url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    
    # Find all URLs in the text
    urls = re.findall(url_pattern, text)
    
    # Remove duplicates while preserving order
    unique_urls = []
    seen = set()
    for url in urls:
        if url not in seen:
            unique_urls.append(url)
            seen.add(url)
    
    return unique_urls


def generate_url_distribution_guidance(urls, num_test_cases=3):
    """Generate guidance for URL distribution across test cases"""
    if not urls:
        return "No URLs found in the requirements text."
    
    if len(urls) == 1:
        return f"Found 1 URL: {urls[0]}. Assign this URL to the most relevant test case."
    elif len(urls) == 2:
        return f"Found 2 URLs: {urls[0]} and {urls[1]}. Assign each URL to different test cases."
    elif len(urls) >= num_test_cases:
        return f"Found {len(urls)} URLs. Try to assign a different URL to each test case: {', '.join(urls[:num_test_cases])}"
    else:
        return f"Found {len(urls)} URLs: {', '.join(urls)}. Distribute these URLs across the test cases, reusing as needed."


def redistribute_urls_in_test_cases(test_cases_data, extracted_urls, force_all_urls=True):
    """Post-process AI response to ensure URLs are distributed across test cases
    
    Args:
        test_cases_data: The AI response data containing test cases
        extracted_urls: List of URLs found in the requirements text
        force_all_urls: If True, ensures every test case gets a URL. If False, only fills empty ones.
    """
    if not extracted_urls or not test_cases_data or 'rows' not in test_cases_data:
        return test_cases_data
    
    rows = test_cases_data['rows']
    if not rows:
        return test_cases_data
    
    print(f"DEBUG: Post-processing URL distribution for {len(rows)} test cases with {len(extracted_urls)} URLs")
    print(f"DEBUG: Force all URLs mode: {force_all_urls}")
    
    # Count how many test cases already have URLs
    test_cases_with_urls = sum(1 for row in rows if row.get('field_8', '').strip())
    print(f"DEBUG: {test_cases_with_urls} test cases already have URLs")
    
    # If all test cases already have URLs and we're not forcing, no need to redistribute
    if test_cases_with_urls == len(rows) and not force_all_urls:
        print("DEBUG: All test cases already have URLs, no redistribution needed")
        return test_cases_data
    
    # URL DISTRIBUTION LOGIC
    if force_all_urls:
        print("DEBUG: Applying FORCE ALL URLS distribution - every test case will get a URL")
        
        for i, row in enumerate(rows):
            # Use modulo to cycle through URLs, ensuring every test case gets one
            url_to_assign = extracted_urls[i % len(extracted_urls)]
            row['field_8'] = url_to_assign
            print(f"DEBUG: Assigned URL '{url_to_assign}' to test case {row.get('field_1', f'#{i+1}')}")
    else:
        print("DEBUG: Applying selective URL distribution - only fill empty test cases")
        
        for i, row in enumerate(rows):
            current_url = row.get('field_8', '').strip()
            
            # If this test case doesn't have a URL, assign one
            if not current_url:
                # Use modulo to cycle through URLs
                url_to_assign = extracted_urls[i % len(extracted_urls)]
                row['field_8'] = url_to_assign
                print(f"DEBUG: Assigned URL '{url_to_assign}' to test case {row.get('field_1', f'#{i+1}')}")
            else:
                print(f"DEBUG: Test case {row.get('field_1', f'#{i+1}')} already has URL: '{current_url}'")
    
    print(f"DEBUG: URL redistribution completed")
    return test_cases_data


def requirements_list(request):
    #View to list all requirements
    from .models import Requirement
    import sys
    
    # Debug information
    print("\n==== REQUIREMENTS LIST VIEW EXECUTION ====", file=sys.stderr)
    print(f"Request path: {request.path}", file=sys.stderr)
    
    # Get all requirements
    requirements = Requirement.objects.all().order_by('-created_at')
    
    # Debug information
    print(f"Total requirements: {requirements.count()}", file=sys.stderr)
    
    context = {
        'requirements': requirements,
        'debug_info': {
            'requirement_count': requirements.count()
        }
    }
    
    print("Rendering template: tocop/requirements_list.html", file=sys.stderr)
    print("==== END REQUIREMENTS LIST VIEW ====\n", file=sys.stderr)
    return render(request, 'tocop/requirements_list.html', context)


# New function to sync Automation with KeyWord_1
def sync_automation_with_keyword(request):
    #Synchronize Automation model with KeyWord_1 model
    if request.method == "POST":
        # Get all keywords from autoai
        keywords = KeyWord_1.objects.all()
        sync_count = 0
        debug_info = []
        
        # Get all test cases that don't have automations yet
        test_cases_without_automation = []
        for test_case in TestCase.objects.all():
            if not Automation.objects.filter(test_case=test_case).exists():
                test_cases_without_automation.append(test_case)
                debug_info.append(f"Test case without automation: ID={test_case.id}, Name={test_case.scenario_name}")
        
        debug_info.append(f"Found {len(test_cases_without_automation)} test cases without automation")
        debug_info.append(f"Found {keywords.count()} keywords total")
        
        # For each test case without automation, try to find a matching keyword
        # This is the reverse of our previous approach
        for test_case in test_cases_without_automation:
            keyword_match = None
            
            # Try to find a keyword that matches this test case
            for keyword in keywords:
                # Try exact match on scenario_name
                if keyword.keyword_Name.lower() in test_case.scenario_name.lower():
                    keyword_match = keyword
                    debug_info.append(f"Found match by scenario_name: Keyword={keyword.keyword_Name}, Test Case={test_case.scenario_name}")
                    break
                
                # Try partial match in description if it exists
                elif test_case.description and keyword.keyword_Name.lower() in test_case.description.lower():
                    keyword_match = keyword
                    debug_info.append(f"Found match by description: Keyword={keyword.keyword_Name}, Test Case={test_case.scenario_name}")
                    break
                
                # Try simple keyword 'test' as fallback for any test case
                elif keyword.keyword_Name.lower() == 'test':
                    keyword_match = keyword
                    debug_info.append(f"Using 'test' keyword as fallback for: Test Case={test_case.scenario_name}")
                    break
            
            # If we found a matching keyword, create an automation
            if keyword_match:
                # Create new automation entry
                automation = Automation.objects.create(
                    test_case=test_case,
                    automation_id=f"AUTO-{test_case.test_case_id}",
                    name=f"{keyword_match.keyword_Name} - {test_case.scenario_name}",
                    language="Python",
                    framework="Selenium",
                    status="Not Started"
                )
                sync_count += 1
                debug_info.append(f"Created automation: {automation.name}")

        # Add debug info to messages
        for info in debug_info:
            messages.info(request, info)
            
        messages.success(request, f"Successfully synced {sync_count} automations with keywords.")
        return redirect('automation_list')
    
    # If GET request, show the sync page
    return render(request, 'tocop/sync_automation.html')


# New function to bulk sync test cases with keywords
def bulk_sync_test_cases(request):
    #Bulk synchronize test cases with KeyWord_1 model and convert to automation test cases
    from .models import TestCase, Automation
    from autoai.models import KeyWord_1, Steps_1
    import sys
    
    # Debug information
    print("\n==== BULK SYNC TEST CASES VIEW EXECUTION ====", file=sys.stderr)
    
    # Get all test cases and keywords
    test_cases = TestCase.objects.all()
    keywords = KeyWord_1.objects.all()
    
    # Initialize counters for debug info
    matched_count = 0
    automation_count = 0
    steps_count = 0
    keyword_update_count = 0
    
    if request.method == "POST":
        convert_to_automation = request.POST.get('convert_to_automation') == 'on'
        debug_info = []
        
        # For each test case, try to find a matching keyword
        for test_case in test_cases:
            # Skip test cases that already have automations
            if Automation.objects.filter(test_case=test_case).exists():
                debug_info.append(f"Test case {test_case.id} already has automation, skipping")
                continue
                
            keyword_match = None
            
            # Try to find a keyword that matches this test case
            for keyword in keywords:
                # Try exact match on scenario_name
                if keyword.keyword_Name.lower() in test_case.scenario_name.lower():
                    keyword_match = keyword
                    debug_info.append(f"Found match by scenario_name: Keyword={keyword.keyword_Name}, Test Case={test_case.scenario_name}")
                    break
                
                # Try partial match in description if it exists
                elif test_case.description and keyword.keyword_Name.lower() in test_case.description.lower():
                    keyword_match = keyword
                    debug_info.append(f"Found match by description: Keyword={keyword.keyword_Name}, Test Case={test_case.scenario_name}")
                    break
                
                # Try simple keyword 'test' as fallback for any test case
                elif keyword.keyword_Name.lower() == 'test':
                    keyword_match = keyword
                    debug_info.append(f"Using 'test' keyword as fallback for: Test Case={test_case.scenario_name}")
                    break
            
            # If we found a matching keyword, create an automation
            if keyword_match:
                matched_count += 1
                
                # Create new automation entry
                automation = Automation.objects.create(
                    test_case=test_case,
                    automation_id=f"AUTO-{test_case.test_case_id}",
                    name=f"{keyword_match.keyword_Name} - {test_case.scenario_name}",
                    language="Python",
                    framework="Selenium",
                    status="Not Started"
                )
                automation_count += 1
                debug_info.append(f"Created automation: {automation.name}")
                
                # Add test case entry to keyword_1 table by updating keyword description
                # This creates a relationship between the test case and keyword
                if not keyword_match.keyword_Desc or keyword_match.keyword_Desc.strip() == "":
                    keyword_match.keyword_Desc = f"Test Case: {test_case.test_case_id} - {test_case.scenario_name}"
                else:
                    keyword_match.keyword_Desc += f"\n\nTest Case: {test_case.test_case_id} - {test_case.scenario_name}"
                
                # Add test steps if available
                if test_case.test_steps:
                    keyword_match.keyword_Desc += f"\n\nTest Steps:\n{test_case.test_steps}"
                
                # Save the updated keyword
                keyword_match.save()
                keyword_update_count += 1
                debug_info.append(f"Updated keyword {keyword_match.keyword_Name} with test case information")
                
                # If convert_to_automation is checked, generate steps using AI model
                if convert_to_automation:
                    try:
                        # Generate steps using AI model
                        steps = generate_automation_steps(test_case, keyword_match)
                        
                        # Create Steps_1 entries for the keyword
                        for i, step in enumerate(steps, 1):
                            Steps_1.objects.create(
                                k=keyword_match,
                                object_Name=step.get('object_name', ''),
                                input_Value=step.get('input_value', ''),
                                expected_Value=step.get('expected_value', ''),
                                action=step.get('action', ''),
                                window_Type=step.get('window_type', 'main'),
                                step_Descriptions=f"Step {i}: {step.get('description', '')}"
                            )
                            steps_count += 1
                        
                        debug_info.append(f"Generated {len(steps)} steps for automation {automation.name}")
                    except Exception as e:
                        debug_info.append(f"Error generating steps for {automation.name}: {str(e)}")
        
        # Add debug info to messages
        for info in debug_info:
            messages.info(request, info)
            
        messages.success(request, f"Successfully synced {matched_count} test cases with keywords, created {automation_count} automations, added {keyword_update_count} test cases to keywords, and created {steps_count} steps.")
        return redirect('test_case_list')
    
    # If GET request, show the sync page
    context = {
        'debug_info': {
            'test_case_count': test_cases.count(),
            'keyword_count': keywords.count(),
            'matched_count': 0,
            'keyword_update_count': 0
        }
    }
    return render(request, 'tocop/bulk_sync_test_cases.html', context)


@login_required
def urls_view(request):
    """
    View function for displaying URLs page next to requirements traceability matrix
    """
    # Get all requirements
    requirements = Requirement.objects.all()
    
    context = {
        'requirements': requirements,
    }
    
    return render(request, 'tocop/urls.html', context)


def automation_create(request):
    #View to create a new automation script"""
    from .models import Automation, TestCase
    from django.shortcuts import redirect
    import sys
    
    # Debug information
    print("\n==== AUTOMATION CREATE VIEW EXECUTION ====", file=sys.stderr)
    
    # Get all test cases for the dropdown
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    if request.method == 'POST':
        # Create new automation with form data
        automation = Automation(
            test_case_id=request.POST.get('test_case'),
            automation_id=request.POST.get('automation_id'),
            name=request.POST.get('name'),
            script_path=request.POST.get('script_path'),
            language=request.POST.get('language'),
            framework=request.POST.get('framework'),
            status=request.POST.get('status'),
            last_result=request.POST.get('last_result')
        )
        
        automation.save()
        messages.success(request, "Automation script created successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': {},  # Empty dict for new automation
        'test_cases': test_cases
    }
    
    return render(request, 'tocop/automation_edit.html', context)


def automation_edit(request, automation_id):
    #View to edit a specific automation script"""
    from .models import Automation, TestCase
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    automation = get_object_or_404(Automation, id=automation_id)
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    # Debug information 
    print("\n==== AUTOMATION EDIT VIEW EXECUTION ====", file=sys.stderr)
    print(f"Editing automation ID: {automation_id}", file=sys.stderr)
    
    if request.method == 'POST': 
        # Update automation with form data
        automation.automation_id = request.POST.get('automation_id')
        automation.name = request.POST.get('name')
        automation.script_path = request.POST.get('script_path')
        automation.language = request.POST.get('language')
        automation.framework = request.POST.get('framework')
        automation.status = request.POST.get('status')
        automation.last_result = request.POST.get('last_result')
        
        # Update test case if changed
        test_case_id = request.POST.get('test_case')
        if test_case_id and int(test_case_id) != automation.test_case_id:
            automation.test_case_id = test_case_id
        
        automation.save()
        messages.success(request, "Automation script updated successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': automation,
        'test_cases': test_cases
    }
    
    return render(request, 'tocop/automation_edit.html', context)


def automation_delete(request, automation_id):
    #View to delete a specific automation script"""
    from .models import Automation
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    automation = get_object_or_404(Automation, id=automation_id)
    
    # Debug information
    print("\n==== AUTOMATION DELETE VIEW EXECUTION ====", file=sys.stderr)
    print(f"Deleting automation ID: {automation_id}", file=sys.stderr)
    
    if request.method == 'POST':
        # Delete the automation
        automation.delete()
        messages.success(request, f"Automation script '{automation.name}' deleted successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': automation
    }
    
    return render(request, 'tocop/automation_delete.html', context)


def automation_list(request):
    #"""View to list all automation scripts with optional filtering by test case"""
    from .models import Automation, TestCase
    import sys
    
    # Debug information
    print("\n==== AUTOMATION LIST VIEW EXECUTION ====", file=sys.stderr)
    
    # Get filter parameters
    test_case_id = request.GET.get('test_case_id', '')
    status = request.GET.get('status', '')
    
    # Base queryset
    automations_query = Automation.objects.all()
    
    # Apply filters if provided
    if test_case_id:
        automations_query = automations_query.filter(test_case_id=test_case_id)
        print(f"Filtering by test_case_id: {test_case_id}", file=sys.stderr)
    
    if status:
        automations_query = automations_query.filter(status=status)
        print(f"Filtering by status: {status}", file=sys.stderr)
    
    # Get all automations
    automations = automations_query.order_by('-created_at')
    
    # Get all test cases for the filter dropdown
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    # Debug information
    print(f"Total automations: {automations.count()}", file=sys.stderr)
    print(f"Total test cases: {test_cases.count()}", file=sys.stderr)
    
    context = {
        'automations': automations,
        'test_cases': test_cases,
        'selected_test_case': test_case_id,
        'selected_status': status,
        'debug_info': {
            'automation_count': automations.count(),
            'test_case_count': test_cases.count()
        }
    }
    
    print("Rendering template: tocop/automation_list.html", file=sys.stderr)
    return render(request, 'tocop/automation_list.html', context)


def execute_test_from_json(json_data, data_with_url):
    # Load the JSON data (Step-wise actions)
    steps = json.loads(json_data)

    # Initialize WebDriver (make sure the correct driver is available)
     # You can replace with Firefox or any other browser
    if os_type == "Linux":
        options = Options()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        driver = webdriver.Chrome(options=options)
    else:
        driver = webdriver.Chrome()

    driver.implicitly_wait(10)
    driver.maximize_window()
    # This will hold the execution report
    execution_report = {}

    def execute_step(step_number, step_data):
        # Initialize the step report dictionary with required fields
        step_report = {
            "Number": step_number,
            "Step_Descriptions": "",
            "InputValue": "",
            "Actual_Value": "",
            "Expected_Value": "",
            "Status": "Pass",
            "ErrorMessage": ""
        }

        try:
            for action in step_data:
                object_name = action['ObjectName']
                action_type = action['Action']
                input_value = action['InputValue']
                expected_value = action['ExpectedValue']
                description = action['StepDescription']

                # Update the Step Descriptions field
                step_report["Step_Descriptions"] = description
                step_report["Expected_Value"] = expected_value  # Expected value for verification

                # Perform the action based on Action type
                if action_type == "ButtonClick":
                    element = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.XPATH, object_name))
                    )
                    element.click()
                    step_report["Actual_Value"] = "Button clicked"

                elif action_type == "SetText":
                    element = WebDriverWait(driver, 10).until(
                        EC.visibility_of_element_located((By.XPATH, object_name))
                    )
                    element.clear()
                    element.send_keys(input_value)
                    step_report["InputValue"] = f"Text set to '{input_value}'"
                    step_report["Actual_Value"] = f"Text set to '{input_value}'"

                elif action_type == "VerifyElementPresent":
                    WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.XPATH, object_name))
                    )
                    step_report["Actual_Value"] = "Element is present"

                elif action_type == "VerifyTextPresent":
                    element = WebDriverWait(driver, 10).until(
                        EC.visibility_of_element_located((By.XPATH, object_name))
                    )
                    if expected_value not in element.text:
                        raise Exception(f"Text '{expected_value}' not found on the page.")
                    step_report["Actual_Value"] = f"Text '{expected_value}' found"

        except Exception as e:
            step_report["Status"] = "Fail"
            step_report["ErrorMessage"] = str(e)
            step_report["Actual_Value"] = f"Error: {str(e)}"
            print(f"Step {step_number}: {description} - Failed. Error: {str(e)}")

        # Add the completed step report to the overall execution report
        execution_report[step_number] = step_report

    # Open the initial URL (from Step 1)
    #initial_url = "https://practicetestautomation.com/practice-test-login/"
    initial_url = data_with_url
    print('UUUUUUUUUUUUUUUUUUUUUURL', initial_url)
    driver.get(initial_url)

    # Execute all steps from JSON
    for step_number, step_data in steps.items():
        execute_step(step_number, step_data)

    # Close the browser
    driver.quit()

    # Print execution report
    # print(json.dumps(execution_report, indent=4))

    # Return the execution report (for saving or further processing)
    return execution_report


def view_function(request):
    import json
    if request.method == 'GET':
        # Capture all GET parameters (query parameters in URL)
        all_row_data = request.GET.dict()
        data_without_url = {key: value for key, value in all_row_data.items() if key != 'url'}
        data_with_url = all_row_data.get('url', None)
        step_wise_data = group_by_step(data_without_url)
        json_data = json.dumps(step_wise_data, indent=4)
        execution_report = execute_test_from_json(json_data, data_with_url)
        # Pass the data to the template
        return render(request, 'tocop/display_data.html', {'json_data': execution_report})

# Add this function after the existing functions


from django.http import JsonResponse
from django.shortcuts import render
import json
from django.views.decorators.csrf import csrf_protect
from collections import defaultdict
from django.views.decorators.http import require_POST

def group_by_step(data):
    steps = defaultdict(list)
    for key, value in data.items():
        # Split the key to extract the row number and the attribute name
        parts = key.split('_')
        # Extract the step number (1, 2, 3...) dynamically from the key
        step_number = parts[1]  # For example: "1", "2", "3" etc.
        attribute = parts[2]     # ObjectName, InputValue, Action, etc.
        # Build the step-wise structure dynamically
        step_key = f"Step{step_number}"
        
        # If it's the first time we're seeing the step, initialize an empty list
        if len(steps[step_key]) == 0:
            steps[step_key].append({
                "ObjectName": "",
                "InputValue": "",
                "Action": "",
                "ExpectedValue": "",
                "WindowType": "",
                "StepDescription": ""
            })
        
        # Populate the relevant attribute in the corresponding step
        if attribute == "ObjectName":
            steps[step_key][-1]["ObjectName"] = value
        elif attribute == "InputValue":
            steps[step_key][-1]["InputValue"] = value
        elif attribute == "Action":
            steps[step_key][-1]["Action"] = value
        elif attribute == "ExpectedValue":
            steps[step_key][-1]["ExpectedValue"] = value
        elif attribute == "WindowType":
            steps[step_key][-1]["WindowType"] = value
        elif attribute == "StepDescription":
            steps[step_key][-1]["StepDescription"] = value

    return steps

@csrf_exempt
def save_test_steps(request):
    if request.method == "POST":
        processed_row_keys = set()
        for key, value in request.POST.items():
            if key.endswith("_ObjectName"):  # We look for fields ending with ObjectName
                row_key = key.split("_")[0]  # Extract the row_key from the input field name
                counter_key = key.split("_")[1]
                
                object_name = request.POST.get(f"{row_key}_{counter_key}_ObjectName", "")
                input_value = request.POST.get(f"{row_key}_{counter_key}_InputValue", "")
                action = request.POST.get(f"{row_key}_{counter_key}_Action", "")
                expected_value = request.POST.get(f"{row_key}_{counter_key}_ExpectedValue", "")
                window_type = request.POST.get(f"{row_key}_{counter_key}_WindowType", "")
                step_description = request.POST.get(f"{row_key}_{counter_key}_StepDescription", "")

                if row_key not in processed_row_keys:
                    tcs_name = request.POST.get(f"tcs_name_{row_key}", "") 
                    tcs_desc = request.POST.get(f"tcs_desc_{row_key}", "") 
                    # Create the keyword once for this row_key
                    # Get project and user objects
                    from autoai.models import Project_1
                    from django.contrib.auth.models import User
                    
                    project = None
                    user = None
                    
                    if 'project_id' in request.session:
                        try:
                            project = Project_1.objects.get(id=request.session['project_id'])
                        except Project_1.DoesNotExist:
                            pass
                    
                    if 'user_id' in request.session:
                        try:
                            user = User.objects.get(id=request.session['user_id'])
                        except User.DoesNotExist:
                            pass
                    
                    new_keyword = KeyWord_1.objects.create(
                        keyword_Name=tcs_name,
                        keyword_Desc=tcs_desc,
                        p=project,
                        u=user,
                    )
                    new_keyword_id = new_keyword.id
                    processed_row_keys.add(row_key)
                # Create and save a new test step entry to the database

                Steps_1.objects.create(
                    object_Name=object_name,
                    input_Value=input_value,
                    action=action,
                    expected_Value=expected_value,
                    window_Type=window_type,
                    step_Descriptions=step_description,
                    k_id = new_keyword_id,
                )
        return HttpResponse("Test steps saved successfully!", content_type="text/plain")
    return render(request, 'tocop/display_testcase.html', {'clean_json': {}})

def update_json(request):
    if request.method == 'POST':
        # Get the updated JSON data from the request body
        updated_json = json.loads(request.body)
        # Here, you can save the updated JSON to your database or file
        return JsonResponse({"status": "success", "message": "JSON updated successfully."})
    return JsonResponse({"status": "error", "message": "Invalid request."})


def update_traceability_from_report(report):
    """
    Update the RequirementTraceabilityMatrix when a test report is created
    
    Args:
        report: Report_1 model instance
    """
    # Find test case by name (assuming tcs_Name in Report_1 corresponds to test_case_id in TestCase)
    try:
        test_case = TestCase.objects.get(test_case_id=report.tcs_Name)
        
        # Find or create traceability matrix entry
        matrix_entry, created = RequirementTraceabilityMatrix.objects.get_or_create(
            requirement=test_case.requirement,
            test_case=test_case,
            defaults={
                'execution_status': 'Passed' if report.status else 'Failed',
                'last_execution': report,
                'last_execution_date': report.time
            }
        )
        
        if not created:
            # Update existing entry
            matrix_entry.execution_status = 'Passed' if report.status else 'Failed'
            matrix_entry.last_execution = report
            matrix_entry.last_execution_date = report.time
            matrix_entry.save()
            
        return True
    except TestCase.DoesNotExist:
        # Log that no matching test case was found
        print(f"No test case found with ID {report.tcs_Name}")
        return False
    except Exception as e:
        print(f"Error updating traceability matrix: {str(e)}")
        return False


@login_required
def requirements_traceability_matrix(request):
    """
    View function to display the requirements traceability matrix
    
    Args:
        request: HTTP request object
    
    Returns:
        Rendered template with requirements traceability matrix data
    """
    # Get all requirements
    requirements = Requirement.objects.all()
    
    # Get filter parameters
    automation_status = request.GET.get('automation_status', '')
    execution_status = request.GET.get('execution_status', '')
    requirement_id = request.GET.get('requirement_id', '')
    
    # Prepare context data
    matrix_data = []
    
    for req in requirements:
        # Get test cases for this requirement
        test_cases = req.test_cases.all()
        
        # Get traceability entries for this requirement
        traceability_entries = RequirementTraceabilityMatrix.objects.filter(requirement=req)
        
        # Apply filters if provided
        if automation_status:
            traceability_entries = traceability_entries.filter(automation_status=automation_status)
        if execution_status:
            traceability_entries = traceability_entries.filter(execution_status=execution_status)
        if requirement_id and str(req.id) != requirement_id:
            continue
        
        # Calculate statistics
        total_test_cases = test_cases.count()
        automated_test_cases = traceability_entries.filter(automation_status='Automated').count()
        passed_test_cases = traceability_entries.filter(execution_status='Passed').count()
        failed_test_cases = traceability_entries.filter(execution_status='Failed').count()
        not_executed_test_cases = traceability_entries.filter(execution_status='Not Executed').count()
        
        # Add requirement data to matrix
        matrix_data.append({
            'requirement': req,
            'total_test_cases': total_test_cases,
            'automated_test_cases': automated_test_cases,
            'automation_percentage': (automated_test_cases / total_test_cases * 100) if total_test_cases > 0 else 0,
            'passed_test_cases': passed_test_cases,
            'failed_test_cases': failed_test_cases,
            'not_executed_test_cases': not_executed_test_cases,
            'execution_percentage': ((passed_test_cases + failed_test_cases) / total_test_cases * 100) if total_test_cases > 0 else 0,
            'test_cases': test_cases,
            'traceability_entries': traceability_entries
        })
    
    context = {
        'matrix_data': matrix_data,
        'automation_status_choices': RequirementTraceabilityMatrix._meta.get_field('automation_status').choices,
        'execution_status_choices': RequirementTraceabilityMatrix._meta.get_field('execution_status').choices,
        'requirements': requirements,
        'selected_automation_status': automation_status,
        'selected_execution_status': execution_status,
        'selected_requirement_id': requirement_id
    }
    
    return render(request, 'requirement/requirements_traceability_matrix.html', context)


@login_required
def update_traceability_matrix(request):
    """
    View function to update the requirements traceability matrix
    
    Args:
        request: HTTP request object
    
    Returns:
        JsonResponse with the result of the operation
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            test_case_id = data.get('test_case_id')
            automation_status = data.get('automation_status')
            execution_status = data.get('execution_status')
            
            test_case = TestCase.objects.get(id=test_case_id)
            
            # Update or create traceability entry
            matrix_entry, created = RequirementTraceabilityMatrix.objects.get_or_create(
                requirement=test_case.requirement,
                test_case=test_case,
                defaults={
                    'automation_status': automation_status,
                    'execution_status': execution_status
                }
            )
            
            if not created:
                matrix_entry.automation_status = automation_status
                matrix_entry.execution_status = execution_status
                matrix_entry.updated_at = timezone.now()
                matrix_entry.save()
            
            return JsonResponse({
                'status': 'success',
                'message': f'Successfully updated traceability matrix for {test_case.test_case_id}'
            })
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': f'Error updating traceability matrix: {str(e)}'
            }, status=500)
    else:
        return JsonResponse({
            'status': 'error',
            'message': 'Invalid request method'
        }, status=405)


def requirement_home(request):
    """Main requirement view for uploading and generating test cases"""
    if request.method == "POST":
        if 'upload_requirements' in request.POST:
            # Handle file upload
            if 'file' in request.FILES:
                file = request.FILES['file']
                file_content = ""
                
                # Process based on file extension
                if file.name.endswith('.json'):
                    try:
                        file_content = json.loads(file.read().decode('utf-8'))
                        requirements_text = parse_json_requirements(file_content)
                    except json.JSONDecodeError:
                        messages.error(request, "Invalid JSON file. Please upload a valid JSON file.")
                        return render(request, 'requirement/requirement.html')
                elif file.name.endswith('.txt'):
                    requirements_text = file.read().decode('utf-8')
                elif file.name.endswith(('.doc', '.docx')):
                    if not DOCUMENT_PROCESSING_AVAILABLE:
                        messages.error(request, "Document processing libraries not available. Please install python-docx to process DOC/DOCX files.")
                        return render(request, 'requirement/requirement.html')
                    requirements_text = extract_text_from_doc(file)
                    if requirements_text.startswith("Error:"):
                        messages.error(request, f"Failed to process DOC file: {requirements_text}")
                        return render(request, 'requirement/requirement.html')
                elif file.name.endswith('.pdf'):
                    if not DOCUMENT_PROCESSING_AVAILABLE:
                        messages.error(request, "Document processing libraries not available. Please install PyPDF2 to process PDF files.")
                        return render(request, 'requirement/requirement.html')
                    requirements_text = extract_text_from_pdf(file)
                    if requirements_text.startswith("Error:"):
                        messages.error(request, f"Failed to process PDF file: {requirements_text}")
                        return render(request, 'requirement/requirement.html')
                else:
                    messages.error(request, "Unsupported file format. Please upload a JSON, TXT, DOC, DOCX, or PDF file.")
                    return render(request, 'requirement/requirement.html')
            else:
                # Get requirements from text area
                requirements_text = request.POST.get('requirements_text', '')
                
                if not requirements_text:
                    messages.error(request, "Please provide requirements text or upload a file.")
                    return render(request, 'requirement/requirement.html')
            
            # Create a new requirement in the database
            requirement_title = request.POST.get('requirement_title', 'Requirement ' + time.strftime("%Y%m%d-%H%M%S"))
            project_id = request.POST.get('project_id', None)
            
            # Save the requirement to the database
            new_requirement = Requirement(
                user=request.user if request.user.is_authenticated else None,
                title=requirement_title,
                description=requirements_text,
                project_id=project_id
            )
            new_requirement.save()
            
            # Extract and log URLs from requirements text for debugging
            extracted_urls = extract_urls_from_text(requirements_text)
            if extracted_urls:
                print(f"DEBUG: Found {len(extracted_urls)} URLs in requirements text:")
                for i, url in enumerate(extracted_urls, 1):
                    print(f"  {i}. {url}")
                
                # Show URL distribution guidance
                url_guidance = generate_url_distribution_guidance(extracted_urls)
                print(f"DEBUG: URL Distribution Guidance: {url_guidance}")
            else:
                print("DEBUG: No URLs found in requirements text")
            
            # Generate prompt from requirements
            prompt = generate_prompt_from_requirements(requirements_text)
            
            # Call AI model
            try:
                response = configure_AI(prompt)
                
                # Process the response
                raw_text = response.candidates[0].content.parts[0].text

                # Optional: Remove code block markers if present
                if raw_text.startswith("```json"):
                    json_text = raw_text.strip("```json").strip("```").strip()
                else:
                    json_text = raw_text.strip()
                    
                try:
                    response_text = json.loads(json_text)
                    print(f"DEBUG: Parsed AI response: {json.dumps(response_text, indent=2)}")
                    
                    # Process AI response and prepare test cases for display
                    success, response_text = process_ai_response_for_test_cases(response_text, new_requirement, extracted_urls, request)
                    
                    context = {
                        'json_data': response_text,
                        'requirement_id': new_requirement.id
                    }
                    messages.success(request, "Test cases generated successfully!")
                    return render(request, 'requirement/requirement.html', context)
                except json.JSONDecodeError as e:
                    messages.error(request, f"Error parsing AI response: {str(e)}")
                    return render(request, 'requirement/requirement.html')
            except Exception as e:
                messages.error(request, f"Error processing requirements: {str(e)}")
                return render(request, 'requirement/requirement.html')
        
        # Handle saving selected test cases
        elif 'save_selected_test_cases' in request.POST:
            selected_test_cases = request.POST.getlist('selected_test_cases')
            requirement_id = request.POST.get('requirement_id')
            
            # Debug: Print all POST data
            print(f"DEBUG: All POST data: {dict(request.POST)}")
            print(f"DEBUG: Selected test cases: {selected_test_cases}")
            print(f"DEBUG: Requirement ID: {requirement_id}")
            
            if not selected_test_cases or not requirement_id:
                messages.error(request, "No test cases selected or requirement ID missing.")
                return redirect('requirement_home')
            
            try:
                # Get the requirement
                requirement = Requirement.objects.get(id=requirement_id)
                
                # Debug: Print what was selected
                print(f"DEBUG: Selected test case IDs: {selected_test_cases}")
                
                # Get the generated test cases data from session or context
                # We need to store the generated data somewhere accessible
                # For now, let's get it from the session
                generated_test_cases = request.session.get('generated_test_cases', [])
                
                if not generated_test_cases:
                    messages.error(request, "No generated test cases found. Please regenerate test cases first.")
                    return redirect('requirement_home')
                
                # Only process the selected test cases
                saved_count = 0
                for temp_id in selected_test_cases:
                    # Find the corresponding test case data
                    test_case_data = None
                    for tc_data in generated_test_cases:
                        if tc_data.get('temp_id') == temp_id:
                            test_case_data = tc_data
                            break
                    
                    if test_case_data:
                        # Create and save the test case to database
                        test_case = TestCase(
                            requirement=requirement,
                            test_case_id=test_case_data['test_case_id'],
                            scenario_name=test_case_data['scenario_name'],
                            description=test_case_data['description'],
                            preconditions=test_case_data['preconditions'],
                            test_data=test_case_data['test_data'],
                            test_steps=test_case_data['test_steps'],
                            expected_results=test_case_data['expected_results'],
                            url=test_case_data['url']
                        )
                        test_case.save()
                        saved_count += 1
                        print(f"DEBUG: Saved test case: {test_case_data['test_case_id']}")
                    else:
                        print(f"DEBUG: Test case data not found for temp ID: {temp_id}")
                
                if saved_count > 0:
                    messages.success(request, f"Successfully saved {saved_count} selected test cases!")
                    # Clear the session data after saving
                    if 'generated_test_cases' in request.session:
                        del request.session['generated_test_cases']
                else:
                    messages.warning(request, "No valid test cases were found to save.")
                    
            except Requirement.DoesNotExist:
                messages.error(request, "Requirement not found.")
            except Exception as e:
                messages.error(request, f"Error saving test cases: {str(e)}")
            
            return redirect('requirement_home')
    
    # Get project_id from session and fetch project details
    project_id = request.session.get('project_id', '')
    project_name = ''
    
    if project_id:
        try:
            from autoai.models import Project_1
            project = Project_1.objects.get(id=project_id)
            project_name = project.project
        except Project_1.DoesNotExist:
            project_name = f"Project ID: {project_id} (Not Found)"
    
    context = {
        'project_id': project_id,
        'project_name': project_name
    }
    
    return render(request, 'requirement/requirement.html', context)


def requirements_list(request):
    """View to list all requirements"""
    import sys
    
    # Debug information
    print("\n==== REQUIREMENTS LIST VIEW EXECUTION ====", file=sys.stderr)
    print(f"Request path: {request.path}", file=sys.stderr)
    
    # Get all requirements
    requirements = Requirement.objects.all().order_by('-created_at')
    
    # Debug information
    print(f"Total requirements: {requirements.count()}", file=sys.stderr)
    
    context = {
        'requirements': requirements,
        'debug_info': {
            'requirement_count': requirements.count()
        }
    }
    
    print("Rendering template: requirement/requirements_list.html", file=sys.stderr)
    print("==== END REQUIREMENTS LIST VIEW ====\n", file=sys.stderr)
    return render(request, 'requirement/requirements_list.html', context)


def test_case_list(request):
    """View to list all test cases with filtering by requirement"""
    # TEST BREAKPOINT - This should definitely hit
    print("=== DEBUG: test_case_list called ==  =ccc          c")
    import sys
    
    # Get filter parameters
    requirement_id = request.GET.get('requirement_id')
    
    # Debug information
    print("\n==== TEST CASE LIST VIEW EXECUTION ====", file=sys.stderr)
    print(f"Request path: {request.path}", file=sys.stderr)
    print(f"Requirement ID filter: {requirement_id}", file=sys.stderr)
    
    # Get test cases using Django ORM with traceability matrix data
    test_cases = []
    try:
        # Get test cases with their traceability matrix entries
        if requirement_id:
            test_case_objects = TestCase.objects.filter(requirement_id=requirement_id).select_related('requirement')
        else:
            test_case_objects = TestCase.objects.all().select_related('requirement')
        
        print(f"Found {test_case_objects.count()} test cases", file=sys.stderr)
        
        for test_case in test_case_objects:
            # Get traceability matrix entry for this test case
            try:
                matrix_entry = RequirementTraceabilityMatrix.objects.get(
                    requirement=test_case.requirement,
                    test_case=test_case
                )
                automation_status = matrix_entry.automation_status or 'Not Automated'
                has_automation = automation_status != 'Not Automated'
                automation_id = None  # We don't store automation_id in traceability matrix
            except RequirementTraceabilityMatrix.DoesNotExist:
                automation_status = 'Not Automated'
                has_automation = False
                automation_id = None
            
            test_cases.append({
                'id': test_case.id,
                'test_case_id': test_case.test_case_id,
                'scenario_name': test_case.scenario_name,
                'requirement_id': test_case.requirement_id,
                'created_at': test_case.created_at,
                'automation_status': automation_status,
                'automation_id': automation_id,
                'has_automation': has_automation,
            })
            
        print(f"Processed {len(test_cases)} test cases", file=sys.stderr)
    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
    
    # Get all requirements for the filter dropdown
    requirements = Requirement.objects.all().order_by('title')
    
    # Fetch KeyWord_1 and Steps_1 data for each test case with automation
    from autoai.models import KeyWord_1, Steps_1
    
    for test_case in test_cases:
        if test_case.get('automation_id'):
            # Try to find KeyWord_1 record that matches this test case
            # Look for keyword by scenario name or test case ID
            keyword = None
            try:
                # First try to find by exact scenario name match
                keyword = KeyWord_1.objects.filter(
                    keyword_Name__icontains=test_case['scenario_name'][:50]
                ).first()
                
                # If not found, try to find by test case ID in description
                if not keyword:
                    keyword = KeyWord_1.objects.filter(
                        keyword_Desc__icontains=test_case['test_case_id']
                    ).first()
                
                if keyword:
                    # Get all steps for this keyword
                    steps = Steps_1.objects.filter(k=keyword).order_by('id')
                    test_case['keyword_data'] = {
                        'keyword_name': keyword.keyword_Name,
                        'keyword_desc': keyword.keyword_Desc,
                        'steps': [
                            {
                                'object_name': step.object_Name,
                                'input_value': step.input_Value,
                                'expected_value': step.expected_Value,
                                'action': step.action,
                                'window_type': step.window_Type,
                                'step_descriptions': step.step_Descriptions
                            } for step in steps
                        ]
                    }
                    print(f"Found keyword data for test case {test_case['test_case_id']}: {len(steps)} steps", file=sys.stderr)
                else:
                    print(f"No keyword found for test case {test_case['test_case_id']}", file=sys.stderr)
                    test_case['keyword_data'] = None
            except Exception as e:
                print(f"Error fetching keyword data for test case {test_case['test_case_id']}: {str(e)}", file=sys.stderr)
                test_case['keyword_data'] = None
        else:
            test_case['keyword_data'] = None
    
    # Debug information
    print(f"Total test cases from SQL: {len(test_cases)}", file=sys.stderr)
    print(f"Total requirements: {requirements.count()}", file=sys.stderr)
    print(f"Test cases data: {test_cases}", file=sys.stderr)
    
    
    
    context = {
        'test_cases': test_cases,
        'requirements': requirements,
        'selected_requirement': requirement_id,
        'debug_info': {
            'test_case_count': len(test_cases),
            'requirement_count': requirements.count()
        }
    }
    
    print("Rendering template: requirement/test_case_list.html", file=sys.stderr)
    print("==== END TEST CASE LIST VIEW ====\n", file=sys.stderr)
    return render(request, 'requirement/test_case_list.html', context)



def requirement(request):
    if request.method == "POST":
        if 'upload_requirements' in request.POST:
            # Handle file upload
            if 'file' in request.FILES:
                file = request.FILES['file']
                file_content = ""
                
                # Process based on file extension
                if file.name.endswith('.json'):
                    try:
                        file_content = json.loads(file.read().decode('utf-8'))
                        requirements_text = parse_json_requirements(file_content)
                    except json.JSONDecodeError:
                        messages.error(request, "Invalid JSON file. Please upload a valid JSON file.")
                        return render(request, 'tocop/requirement.html')
                elif file.name.endswith('.txt'):
                    requirements_text = file.read().decode('utf-8')
                elif file.name.endswith(('.doc', '.docx')):
                    if not DOCUMENT_PROCESSING_AVAILABLE:
                        messages.error(request, "Document processing libraries not available. Please install python-docx to process DOC/DOCX files.")
                        return render(request, 'requirement/requirement.html', context)
                    requirements_text = extract_text_from_doc(file)
                    if requirements_text.startswith("Error:"):
                        messages.error(request, f"Failed to process DOC file: {requirements_text}")
                        return render(request, 'requirement/requirement.html', context)
                elif file.name.endswith('.pdf'):
                    if not DOCUMENT_PROCESSING_AVAILABLE:
                        messages.error(request, "Document processing libraries not available. Please install PyPDF2 to process PDF files.")
                        return render(request, 'requirement/requirement.html', context)
                    requirements_text = extract_text_from_pdf(file)
                    if requirements_text.startswith("Error:"):
                        messages.error(request, f"Failed to process PDF file: {requirements_text}")
                        return render(request, 'requirement/requirement.html', context)
                else:
                    messages.error(request, "Unsupported file format. Please upload a JSON, TXT, DOC, DOCX, or PDF file.")
                    return render(request, 'requirement/requirement.html', context)
            else:
                # Get requirements from text area
                requirements_text = request.POST.get('requirements_text', '')
                
                if not requirements_text:
                    messages.error(request, "Please provide requirements text or upload a file.")
                    return render(request, 'tocop/requirement.html')
            
            # Create a new requirement in the database
            requirement_title = request.POST.get('requirement_title', 'Requirement ' + time.strftime("%Y%m%d-%H%M%S"))
            # Use project_id from session (primary) or form input (fallback)
            project_id = request.session.get('project_id') or request.POST.get('project_id', None)
            
            # Validate project_id exists
            if project_id:
                try:
                    from autoai.models import Project_1
                    Project_1.objects.get(id=project_id)
                except Project_1.DoesNotExist:
                    messages.error(request, f"Project with ID {project_id} not found. Please select a valid project.")
                    # Re-fetch context for error display
                    project_name = f"Project ID: {project_id} (Not Found)"
                    context = {
                        'project_id': project_id,
                        'project_name': project_name
                    }
                    return render(request, 'requirement/requirement.html', context)
            
            # Save the requirement to the database
            from .models import Requirement, TestCase
            new_requirement = Requirement(
                user=request.user if request.user.is_authenticated else None,
                title=requirement_title,
                description=requirements_text,
                project_id=project_id
            )
            new_requirement.save()
            
            # Extract and log URLs from requirements text for debugging
            extracted_urls = extract_urls_from_text(requirements_text)
            if extracted_urls:
                print(f"DEBUG: Found {len(extracted_urls)} URLs in requirements text:")
                for i, url in enumerate(extracted_urls, 1):
                    print(f"  {i}. {url}")
                
                # Show URL distribution guidance
                url_guidance = generate_url_distribution_guidance(extracted_urls)
                print(f"DEBUG: URL Distribution Guidance: {url_guidance}")
            else:
                print("DEBUG: No URLs found in requirements text")
            
            # Generate prompt from requirements
            prompt = generate_prompt_from_requirements(requirements_text)
            
            # Call AI model
            try:
                response = configure_AI(prompt)
                
                # Process the response
                raw_text = response.candidates[0].content.parts[0].text

                # Optional: Remove code block markers if present
                if raw_text.startswith("```json"):
                    json_text = raw_text.strip("```json").strip("```").strip()
                else:
                    json_text = raw_text.strip()
                    
                try:
                    response_text = json.loads(json_text)
                    
                    # Process AI response and prepare test cases for display
                    success, response_text = process_ai_response_for_test_cases(response_text, new_requirement, extracted_urls, request)
                    
                    context = {
                        'json_data': response_text,
                        'requirement_id': new_requirement.id
                    }
                    messages.success(request, "Test cases generated and saved successfully!")
                    return render(request, 'tocop/requirement.html', context)
                except json.JSONDecodeError as e:
                    messages.error(request, f"Error parsing AI response: {str(e)}")
                    return render(request, 'tocop/requirement.html')
            except Exception as e:
                messages.error(request, f"Error processing requirements: {str(e)}")
                return render(request, 'tocop/requirement.html')
        
        # Handle saving selected test cases
        elif 'save_selected_test_cases' in request.POST:
            selected_test_cases = request.POST.getlist('selected_test_cases')
            requirement_id = request.POST.get('requirement_id')
            
            if not selected_test_cases or not requirement_id:
                messages.error(request, "No test cases selected or requirement ID missing.")
                return redirect('requirement_home')
            
            # Process selected test cases
            # This would typically involve updating the status or other attributes
            messages.success(request, f"{len(selected_test_cases)} test cases saved successfully!")
            return redirect('requirement_home')
    
    return render(request, 'tocop/requirement.html')


def requirement_edit(request, requirement_id):
    """View to edit a specific requirement"""
    import sys
    
    requirement = get_object_or_404(Requirement, id=requirement_id)
    
    # Debug information
    print("\n==== REQUIREMENT EDIT VIEW EXECUTION ====", file=sys.stderr)
    print(f"Editing requirement ID: {requirement_id}", file=sys.stderr)
    
    if request.method == 'POST':
        # Update requirement with form data
        requirement.title = request.POST.get('title')
        requirement.description = request.POST.get('description')
        requirement.url = request.POST.get('url')
        requirement.project_id = request.POST.get('project_id')
        
        requirement.save()
        messages.success(request, "Requirement updated successfully!")
        return redirect('requirements_list')
    
    context = {
        'requirement': requirement
    }
    
    return render(request, 'requirement/requirement_edit.html', context)


def requirement_delete(request, requirement_id):
    """View to delete a specific requirement"""
    import sys
    
    requirement = get_object_or_404(Requirement, id=requirement_id)
    
    # Debug information
    print("\n==== REQUIREMENT DELETE VIEW EXECUTION ====", file=sys.stderr)
    print(f"Deleting requirement ID: {requirement_id}", file=sys.stderr)
    print(f"Requirement title: {requirement.title}", file=sys.stderr)
    print(f"Associated test cases: {requirement.test_cases.count()}", file=sys.stderr)
    
    if request.method == 'POST':
        # Delete the requirement (this will cascade delete test cases due to the model relationship)
        requirement.delete()
        messages.success(request, f"Requirement '{requirement.title}' and all associated test cases deleted successfully!")
        return redirect('requirements_list')
    
    # If not POST, redirect to requirements list (safety measure)
    return redirect('requirements_list')


def test_case_edit(request, test_case_id):
    """View to edit a specific test case"""
    test_case = get_object_or_404(TestCase, id=test_case_id)
    requirements = Requirement.objects.all().order_by('title')
    
    if request.method == 'POST':
        # Update test case with form data
        test_case.test_case_id = request.POST.get('test_case_id')
        test_case.scenario_name = request.POST.get('scenario_name')
        test_case.description = request.POST.get('description')
        test_case.preconditions = request.POST.get('preconditions')
        test_case.test_data = request.POST.get('test_data')
        test_case.test_steps = request.POST.get('test_steps')
        test_case.expected_results = request.POST.get('expected_results')
        test_case.url = request.POST.get('url')
        
        # Update requirement if changed
        requirement_id = request.POST.get('requirement')
        if requirement_id and int(requirement_id) != test_case.requirement_id:
            test_case.requirement_id = requirement_id
        
        test_case.save()
        messages.success(request, "Test case updated successfully!")
        return redirect('test_case_list')
    
    context = {
        'test_case': test_case,
        'requirements': requirements
    }
    
    return render(request, 'requirement/test_case_edit.html', context)


def generate_automation_for_testcase(request, test_case_id):
    """
    View function to generate automation steps for a specific test case
    
    Args:
        request: HTTP request object
        test_case_id: ID of the test case to generate automation for
    
    Returns:
        JsonResponse with the result of the operation    
    """
    try:
        # Debug: Print the test_case_id parameter
        print(f"generate_automation_for_testcase called with test_case_id: '{test_case_id}'", file=sys.stderr)
        
        # Clean the test_case_id - remove any extra text after the ID
        if ' - ' in test_case_id:
            test_case_id = test_case_id.split(' - ')[0]
            print(f"Cleaned test_case_id to: '{test_case_id}'", file=sys.stderr)
        
        # Get the test case by ID
        test_case = TestCase.objects.get(test_case_id=test_case_id)
        
        # Generate test steps using our new function
        project_id = request.session.get('project_id') if 'project_id' in request.session else None
        keyword, steps_count = generate_test_steps_from_testcase(test_case, project_id)
        
        if keyword and steps_count > 0:
            # Update the traceability matrix entry for this test case
            matrix_entry, created = RequirementTraceabilityMatrix.objects.get_or_create(
                requirement=test_case.requirement,
                test_case=test_case,
                defaults={
                    'automation_status': 'Automated'
                }
            )
            
            if not created:
                matrix_entry.automation_status = 'Automated'
                matrix_entry.save()
            
            return JsonResponse({
                'status': 'success',
                'message': f'Successfully generated {steps_count} test steps for {test_case.scenario_name}',
                'keyword_id': keyword.id,
                'steps_count': steps_count
            })
        else:
            return JsonResponse({
                'status': 'error',
                'message': 'Failed to generate test steps. Check server logs for details.'
            }, status=500)
            
    except TestCase.DoesNotExist:
        return JsonResponse({
            'status': 'error',
            'message': f'Test case with ID {test_case_id} not found'
        }, status=404)
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': f'Error generating test steps: {str(e)}'
        }, status=500)


# New: Bulk generate automation for selected test cases
@login_required
def review_automation_steps(request):
    """ Intermediate page to review and edit AI-generated automation steps before saving"""
    print('############################# cccc    cccc    ')
    if request.method == 'POST':
        # Handle saving the reviewed steps
        return save_reviewed_automation_steps(request)
    
    # GET request - show the review page
    try:
        from tocop.views import generate_prompt4tcs, configure_AI, read_json_file, extract_url, generate_OR
        import json
        
        selected_ids = request.GET.getlist('test_case_ids')
        if not selected_ids:
            messages.error(request, 'No test cases selected.')
            return redirect('test_case_list')

        # Fetch test cases with related requirement
        test_cases = TestCase.objects.filter(id__in=selected_ids).select_related('requirement')
        
        automation_data = []
        
        for test_case in test_cases:
            # Build a row dict compatible with generate_prompt4tcs expectations
            row = {
                'field_1': test_case.test_case_id or '',
                'field_2': test_case.scenario_name or '',
                'field_3': test_case.description or '',
                'field_4': test_case.preconditions or '',
                'field_5': test_case.test_data or '',
                'field_6': test_case.test_steps or '',
                'field_7': test_case.expected_results or '',
                'field_8': getattr(test_case, 'url', '') or ''
            }

            # Ensure OR exists for the URL to allow prompt to resolve xpaths
            page_url = row['field_8'] or extract_url({
                'f1': row['field_1'], 'f2': row['field_2'], 'f3': row['field_3'], 'f4': row['field_4'],
                'f5': row['field_5'], 'f6': row['field_6'], 'f7': row['field_7']
            })
            if page_url:
                try:
                    generate_OR(page_url)
                except Exception:
                    pass

            # Call AI to generate steps using the tocop helper
            prompt = generate_prompt4tcs(row)
            ai_response = configure_AI(prompt)

            print("DEBUG: AI response:", ai_response)

            # Extract JSON from response
            raw_text = getattr(ai_response, 'text', None)
            if not raw_text and hasattr(ai_response, 'candidates'):
                try:
                    raw_text = ai_response.candidates[0].content.parts[0].text
                except Exception:
                    raw_text = ''

            clean_text = (raw_text or '').replace('```', '').replace('json', '').strip()
            print("DEBUG: Clean text:", clean_text)
            
            if clean_text:
                try:
                    steps_list = json.loads(clean_text)
                except json.JSONDecodeError:
                    steps_list = []
            else:
                steps_list = []
            
            automation_data.append({
                'test_case': test_case,
                'steps': steps_list,
                'row_data': row
            })

        context = {
            'automation_data': automation_data,
            'selected_ids': selected_ids
        }
        
        return render(request, 'requirement/review_automation_steps.html', context)
        
    except Exception as e:
        messages.error(request, f'Error generating automation steps for review: {str(e)}')
        return redirect('test_case_list')

@login_required
def save_reviewed_automation_steps(request):
    """Save the reviewed and edited automation steps to database       """
    # TEST BREAKPOINT - This should always hit
    print("=== DEBUG: save_reviewed_automation_steps called === ")
    
    try:
        from autoai.models import KeyWord_1, Steps_1
        import json
        import sys
        
        # Get the automation data from the form
        automation_data_json = request.POST.get('automation_data', '[]')
        print(f"Received automation data: {automation_data_json[:200]}...", file=sys.stderr)
        
        # Check session data
        print(f"Session data: {dict(request.session)}", file=sys.stderr)
        if 'project_id' not in request.session:
            print("❌ No project_id in session - cannot save automation steps", file=sys.stderr)
            messages.error(request, 'No project selected. Please select a project first.')
            return redirect('test_case_list')
        
        try:
            automation_data = json.loads(automation_data_json)
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {e}", file=sys.stderr)
            messages.error(request, f'Error parsing automation data: {str(e)}')
            return redirect('test_case_list')
        
        saved_count = 0
        
        for item in automation_data:
            test_case_id = item.get('test_case_id')
            steps = item.get('steps', [])
            
            print(f"Processing test case ID: '{test_case_id}' (type: {type(test_case_id)}), Steps count: {len(steps)}", file=sys.stderr)
            
            if not test_case_id:
                print(f"Skipping item - missing test_case_id. steps length: {len(steps) if isinstance(steps, list) else 'N/A'}", file=sys.stderr)
                continue
            
            # Clean and convert test_case_id to integer if it's a string
            try:
                # If it's a string that contains extra text, extract just the ID
                if isinstance(test_case_id, str) and ' - ' in test_case_id:
                    test_case_id = test_case_id.split(' - ')[0]
                    print(f"Cleaned test_case_id from string to: '{test_case_id}'", file=sys.stderr)
                
                test_case_id = int(test_case_id)
            except (ValueError, TypeError):
                print(f"Invalid test case ID format: {test_case_id}", file=sys.stderr)
                continue
                
            try:
                test_case = TestCase.objects.get(id=test_case_id)
                print(f"Found test case: {test_case.test_case_id}", file=sys.stderr)
            except TestCase.DoesNotExist:
                print(f"Test case with ID {test_case_id} not found", file=sys.stderr)
                continue
            
            # Create or update KeyWord_1 for this test case
            # Get the project ID from session
            print(f"Session keys: {list(request.session.keys())}", file=sys.stderr)
            print(f"Session project_id: {request.session.get('project_id', 'NOT_FOUND')}", file=sys.stderr)
            
            project = None
            if 'project_id' in request.session:
                try:
                    from autoai.models import Project_1
                    project = Project_1.objects.get(id=request.session['project_id'])
                    print(f"Found project from session: {project.project} (ID: {project.id})", file=sys.stderr)
                except Project_1.DoesNotExist:
                    print(f"Project with ID {request.session['project_id']} not found", file=sys.stderr)
                except Exception as e:
                    print(f"Error getting project: {str(e)}", file=sys.stderr)
            else:
                print("No project_id in session", file=sys.stderr)
            
            try:
                print(f"Creating/updating KeyWord_1 for test case: {test_case.test_case_id}", file=sys.stderr)
                print(f"Project object: {project}", file=sys.stderr)
                print(f"User object: {request.user}", file=sys.stderr)
                
                keyword, created = KeyWord_1.objects.get_or_create(
                    keyword_Name=(test_case.scenario_name or '')[:50],
                    defaults={
                        'keyword_Desc': f"Test Case: {test_case.test_case_id} - {test_case.scenario_name}\n\nDescription: {test_case.description}\n\nTest Steps: {test_case.test_steps}",
                        'u': request.user if getattr(request.user, 'is_authenticated', False) else None,
                        'p': project,
                    }
                )
                print(f"✅ KeyWord_1 {'created' if created else 'found'}: ID={keyword.id}, p={keyword.p}, u={keyword.u}", file=sys.stderr)
                
            except Exception as e:
                print(f"❌ Error creating/updating KeyWord_1: {str(e)}", file=sys.stderr)
                print(f"Error type: {type(e).__name__}", file=sys.stderr)
                import traceback
                traceback.print_exc(file=sys.stderr)
                continue

            # Clear existing steps for this keyword and save new ones (if any)
            Steps_1.objects.filter(k=keyword).delete()
            if isinstance(steps, list) and steps:
                for i, step in enumerate(steps, 1):
                    Steps_1.objects.create(
                        k=keyword,
                        object_Name=step.get('ObjectName', ''),
                        input_Value=step.get('InputValue', ''),
                        action=step.get('Action', ''),
                        expected_Value=step.get('ExpectedValue', ''),
                        window_Type=step.get('WindowType', 'main'),
                        step_Descriptions=f"Step {i}: {step.get('StepDescription', '')}"
                    )

            # Skip Automation table creation for now - focus on Steps_1 and traceability matrix
            # The Automation table creation was causing foreign key constraint issues
            # We'll rely on the traceability matrix to track automation status
            print(f"Skipping Automation table creation for test case: {test_case.test_case_id}", file=sys.stderr)

            # Update traceability matrix to mark as Automated
            matrix_entry, created = RequirementTraceabilityMatrix.objects.get_or_create(
                requirement=test_case.requirement,
                test_case=test_case,
                defaults={'automation_status': 'Automated'}
            )
            if not created:
                matrix_entry.automation_status = 'Automated'
                matrix_entry.save()

            saved_count += 1

        messages.success(request, f'Successfully saved automation steps for {saved_count} test case(s).')
        return redirect('test_case_list')
        
    except Exception as e:
        messages.error(request, f'Error saving automation steps: {str(e)}')
        return redirect('test_case_list')

@login_required
@require_POST
def generate_automation_for_selected(request):
    """Redirect to review page for AI-generated automation steps"""
    selected_ids = request.POST.getlist('selected_test_cases')
    if not selected_ids:
        messages.error(request, 'No test cases selected to generate ai automation test cases.')
        return redirect('test_case_list')
    
    # Redirect to review page with selected test case IDs
    return redirect(f"{reverse('review_automation_steps')}?{'&'.join([f'test_case_ids={id}' for id in selected_ids])}")

# Helper functions
def parse_json_requirements(json_data):
    """Extract requirements text from JSON data"""
    # This is a simple implementation - adjust based on your JSON structure
    if isinstance(json_data, dict):
        if 'requirements' in json_data:
            return json_data['requirements']
        elif 'description' in json_data:
            return json_data['description']
        elif 'text' in json_data:
            return json_data['text']
    
    # If we can't find a specific field, convert the entire JSON to text
    return json.dumps(json_data, indent=2)


def process_ai_response_for_test_cases(response_text, new_requirement, extracted_urls=None, request=None):
    """Process AI response and prepare test cases for display (don't save to database yet)"""
    test_cases_data = None
    if isinstance(response_text, list) and len(response_text) > 0:
        # New format: [{"table": {"rows": [...]}}]
        test_cases_data = response_text[0].get('table', {}).get('rows', [])
    elif 'table' in response_text:
        # Alternative format: {"table": {"rows": [...]}}
        test_cases_data = response_text['table'].get('rows', [])
    elif 'rows' in response_text:
        # Old format: {"rows": [...]}
        test_cases_data = response_text['rows']
    
    if test_cases_data:
        print(f"DEBUG: Found {len(test_cases_data)} test cases in AI response")
        # Convert to old format for template compatibility
        converted_rows = []
        
        for index, row in enumerate(test_cases_data):
            # Handle both old field_X format and new named format
            test_case_id = row.get('Test Case ID') or row.get('field_1', '')
            scenario_name = row.get('Test Scenario Name') or row.get('field_2', '')
            description = row.get('Test Case Description') or row.get('field_3', '')
            preconditions = row.get('Preconditions') or row.get('field_4', '')
            test_data = row.get('Test Data') or row.get('field_5', '')
            test_steps = row.get('Test Steps') or row.get('field_6', '')
            expected_results = row.get('Test Step Expected Results') or row.get('field_7', '')
            url_value = row.get('field_8', '')
            
            print(f"DEBUG: Preparing test case {test_case_id} for display (not saving yet)")
            
            # Convert to old format for template (don't save to database yet)
            converted_rows.append({
                'field_1': test_case_id,
                'field_2': scenario_name,
                'field_3': description,
                'field_4': preconditions,
                'field_5': test_data,
                'field_6': test_steps,
                'field_7': expected_results,
                'field_8': url_value,
                'test_case_id': f"temp_{index}",  # Use temporary ID for display
                'temp_data': {  # Store the actual data for saving later
                    'test_case_id': test_case_id,
                    'scenario_name': scenario_name,
                    'description': description,
                    'preconditions': preconditions,
                    'test_data': test_data,
                    'test_steps': test_steps,
                    'expected_results': expected_results,
                    'url': url_value
                }
            })
        
        # Store the test case data in session for later saving
        if request:
            session_data = []
            for row in converted_rows:
                session_data.append({
                    'temp_id': row['test_case_id'],
                    'test_case_id': row['temp_data']['test_case_id'],
                    'scenario_name': row['temp_data']['scenario_name'],
                    'description': row['temp_data']['description'],
                    'preconditions': row['temp_data']['preconditions'],
                    'test_data': row['temp_data']['test_data'],
                    'test_steps': row['temp_data']['test_steps'],
                    'expected_results': row['temp_data']['expected_results'],
                    'url': row['temp_data']['url']
                })
            request.session['generated_test_cases'] = session_data
            print(f"DEBUG: Stored {len(session_data)} test cases in session")
        
        # Update response_text to old format for template
        response_text = {'rows': converted_rows}
        return True, response_text
    return False, response_text


def generate_prompt_from_requirements(requirements_text, domain="", subdomain="", role="", functionality=""):
    """Generate a prompt for the AI model based on requirements text"""
    from tocop.views import generate_OR, read_json_file
    
    # Extract URLs from the requirements text
    extracted_urls = extract_urls_from_text(requirements_text)
    url = extracted_urls[0] if extracted_urls else ""
    
    # Generate OR and get xjson if URL is available
    xjson = None
    if url:
        screen_name = generate_OR(url)
        print('####################################')
        print('screen_name ->', screen_name)
        print('####################################')
        xjson = read_json_file(screen_name)
    
    # Generate prompt following tocop method pattern
    prompt = f"""
                You are an expert in generating manual test cases.
                Use the following information to generate the requested test cases:
                Application: practicetestautomation.com  
                Section: practice-test-login  
                Domain: {domain}  
                Subdomain: {subdomain}  
                Role: {role}  
                Functionality: {functionality}  

                Requirements Document:
                {requirements_text}

                Context:
                Use only the keys from the object_xpat JSON UI object when writing test steps. When the test step involves clicking the primary button to complete the signup process, use the key that corresponds to that button's action (e.g., 'agree_&_join').
                in the test <Test Steps> should take from the key of object_xpat

                object_xpat = {json.dumps(xjson, ensure_ascii=False, indent=4) if xjson else "{}"}

                Instructions:
                - Generate AT all possible test cases covering positive, negative, edge, and exception scenarios.
                - Where the application name is required, use {url if url else "practicetestautomation.com"}
                - Apply relevant business rules in test data.
                - Use explicit static text (e.g., "a_username_with_256_characters") instead of programmatic notations like `.repeat()`.
                - If any required data is unavailable, respond with: "Requested Data not available".
                - **Do not include any introductory or concluding sentences.**
                - **Do not include any explanations or commentary about the test cases.**
                - **Your entire response MUST be a valid JSON array as specified in the Output Format.**
                - Before returning, validate the JSON using a standard JSON parser.
                - If the JSON is invalid, fix and re-validate before outputting.
                - The final output must be valid JSON, parsable by Python's json.loads().
                - **IMPORTANT: Generate multiple test cases (minimum 3) in the rows array.**

                Return only the raw JSON array, with no markdown formatting or additional annotations.
                **Output Format** perfect json only like below format only
                [
                {{
                    "table": {{
                    "headers": [
                        "Test Case ID",
                        "Test Scenario Name",
                        "Test Case Description",
                        "Preconditions",
                        "Test Data",
                        "Test Steps",
                        "Test Step Expected Results"
                    ],
                    "rows": [
                        {{
                        "Test Case ID": "TC-001",
                        "Test Scenario Name": "Positive Login Test",
                        "Test Case Description": "Verify successful login with valid credentials",
                        "Preconditions": "User account exists",
                        "Test Data": "valid_username, valid_password",
                        "Test Steps": "1. Navigate to login page 2. Enter credentials 3. Click login",
                        "Test Step Expected Results": "User successfully logged in"
                        }},
                        {{
                        "Test Case ID": "TC-002",
                        "Test Scenario Name": "Negative Login Test",
                        "Test Case Description": "Verify login failure with invalid credentials",
                        "Preconditions": "User account exists",
                        "Test Data": "invalid_username, invalid_password",
                        "Test Steps": "1. Navigate to login page 2. Enter invalid credentials 3. Click login",
                        "Test Step Expected Results": "Error message displayed"
                        }},
                        {{
                        "Test Case ID": "TC-003",
                        "Test Scenario Name": "Edge Case Login Test",
                        "Test Case Description": "Verify login with empty fields",
                        "Preconditions": "User on login page",
                        "Test Data": "empty_username, empty_password",
                        "Test Steps": "1. Navigate to login page 2. Leave fields empty 3. Click login",
                        "Test Step Expected Results": "Validation error displayed"
                        }}
                    ]
                    }}
                }}
                ]
                """
    
    print('#######################################################')
    print('prompt Parent ->', prompt)
    print('#######################################################')
    
    return prompt


def configure_AI(prompt):
    """Configure and call the AI model"""
    import google.generativeai as genai

    genai.configure(api_key="AIzaSyDX4PWUHgW01LzABl4RSEMT6FQCHXru9L0")

    model = genai.GenerativeModel(
        model_name="gemini-2.0-flash",
        generation_config=genai.types.GenerationConfig(
            temperature=0.7,
            top_p = 0.9,
            top_k = 40,
            max_output_tokens=8192
        )
    )

    response = model.generate_content(prompt)
    return response


def generate_test_steps_from_testcase(test_case, project_id=None):
    """
    Generate test steps for a test case using AI and populate Steps_1 table
    
    Args:
        test_case: TestCase model instance
        project_id: Project ID from session (optional)
    
    Returns:
        tuple: (keyword, steps_count) - The created/updated keyword and number of steps created
    """
    import json
    import google.generativeai as genai
    from django.conf import settings
    from tocop.views import generate_OR, read_json_file
    
    # Get AI configuration
    try:
        ai_config = conf_1.objects.first()
        if ai_config and ai_config.g_api_key:
            api_key = ai_config.g_api_key
        else:
            # Use a default API key or raise an error
            api_key = settings.GEMINI_API_KEY if hasattr(settings, 'GEMINI_API_KEY') else None
            
        if not api_key:
            print("No API key found for Gemini")
            return None, 0
            
        # Configure the Gemini API
        genai.configure(api_key=api_key)
    except Exception as e:
        print(f"Error configuring AI: {str(e)}")
        return None, 0
    
    # Get XPath data from Object Repository
    xjson = None
    if hasattr(test_case, 'url') and test_case.url:
        try:
            screen_name = generate_OR(test_case.url)
            print(f"DEBUG: Generated OR screen_name: {screen_name}")
            xjson = read_json_file(screen_name)
            print(f"DEBUG: Loaded XPath data: {json.dumps(xjson, indent=2) if xjson else 'None'}")
        except Exception as e:
            print(f"DEBUG: Error getting XPath data: {str(e)}")
    
    # Create a prompt for the AI model with XPath data
    prompt = f"""
    You are an automation assistant. Convert the following test case into automation steps that can be used with Selenium WebDriver.
    
    Test Case ID: {test_case.test_case_id}
    Test Scenario Name: {test_case.scenario_name}
    Test Case Description: {test_case.description}
    Preconditions: {test_case.preconditions}
    Test Data: {test_case.test_data}
    Test Steps: {test_case.test_steps}
    Expected Results: {test_case.expected_results}
    URL: {test_case.url if hasattr(test_case, 'url') else ''}

    Context:
    Use only the keys from the object_xpat JSON UI object when writing test steps. When the test step involves clicking the primary button to complete the signup process, use the key that corresponds to that button's action (e.g., 'agree_&_join').
    in the test <Test Steps> should take from the key of object_xpat

    object_xpat = {json.dumps(xjson, ensure_ascii=False, indent=4) if xjson else "{}"}

    Instructions:
    - Generate test cases covering positive, negative, edge, and exception scenarios.
    - Where the application name is required, use {test_case.url if hasattr(test_case, 'url') and test_case.url else "practicetestautomation.com"}
    - Apply relevant business rules in test data.
    - Use explicit static text (e.g., "a_username_with_256_characters") instead of programmatic notations like `.repeat()`.
    - If any required data is unavailable, respond with: "Requested Data not available".
    - **Do not include any introductory or concluding sentences.**
    - **Do not include any explanations or commentary about the test cases.**
    - **Your entire response MUST be a valid JSON array as specified in the Output Format.**
    - Before returning, validate the JSON using a standard JSON parser.
    - If the JSON is invalid, fix and re-validate before outputting.
    - The final output must be valid JSON, parsable by Python's json.loads().

    **IMPORTANT ACTION RULES:**
    - For text input fields (input[type="text"], input[type="email"], input[type="password"], textarea): Use "SetText" action
    - For buttons (button, input[type="submit"], input[type="button"]): Use "ButtonClick" action  
    - For links (a tags): Use "ElementClick" action
    - For dropdowns/select elements: Use "Select" action
    - For checkboxes and radio buttons: Use "ElementClick" action
    - For navigation steps: Use "Navigate" action
    - For verification steps: Use "Verify" action

    Return only the raw JSON array, with no markdown formatting or additional annotations.
    **Output Format** perfect json only like below format only
    [
        {{
            "ObjectName": "Use XPath from object_xpat keys above",
            "InputValue": "Value to input (if applicable)",
            "ExpectedValue": "Expected value or result",
            "Action": "SetText | ButtonClick | ElementClick | Select | Navigate | Verify",
            "WindowType": "main",
            "StepDescription": "Description of the step"
        }}
    ]
    
    Make sure to include all necessary steps to complete the test case, including navigation, form filling, validation, etc.
    Use the XPath selectors from the object_xpat JSON object for the ObjectName field.
    """

    try:
        # Generate content using Gemini
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(prompt)
        
        # Extract JSON from response
        raw_text = response.text
        
        # Clean up the response to extract valid JSON
        if "```json" in raw_text:
            json_text = raw_text.split("```json")[1].split("```")[0].strip()
        elif "```" in raw_text:
            json_text = raw_text.split("```")[1].strip()
        else:
            json_text = raw_text.strip()
            
        # Parse the JSON
        steps = json.loads(json_text)
        
        # Create or get keyword for this test case
        # Get the project from the provided project_id
        project = None
        if project_id:
            try:
                from autoai.models import Project_1
                project = Project_1.objects.get(id=project_id)
                print(f"Found project for keyword: {project.project} (ID: {project.id})", file=sys.stderr)
            except Project_1.DoesNotExist:
                print(f"Project with ID {project_id} not found", file=sys.stderr)
        else:
            print("No project_id provided for keyword creation", file=sys.stderr)
        
        keyword, created = KeyWord_1.objects.get_or_create(
            keyword_Name=test_case.scenario_name[:50],  # Limit to 50 chars
            defaults={
                'keyword_Desc': f"Test Case: {test_case.test_case_id} - {test_case.scenario_name}\n\nDescription: {test_case.description}\n\nTest Steps: {test_case.test_steps}",
                'u': None,  # Set user to None for now
                'p': project,
            }
        )
        
        # Delete existing steps for this keyword
        Steps_1.objects.filter(k=keyword).delete()
        
        # Create Steps_1 entries for the keyword
        steps_count = 0
        for i, step in enumerate(steps, 1):
            Steps_1.objects.create(
                k=keyword,
                object_Name=step.get('ObjectName', step.get('object_name', '')),
                input_Value=step.get('InputValue', step.get('input_value', '')),
                expected_Value=step.get('ExpectedValue', step.get('expected_value', '')),
                action=step.get('Action', step.get('action', '')),
                window_Type=step.get('WindowType', step.get('window_type', 'main')),
                step_Descriptions=f"Step {i}: {step.get('StepDescription', step.get('description', ''))}"
            )
            steps_count += 1
            
        return keyword, steps_count
    except Exception as e:
        print(f"Error generating steps with AI: {str(e)}")
        return None, 0
