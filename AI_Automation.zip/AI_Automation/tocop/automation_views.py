from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Automation, TestCase
import sys

def automation_list(request):
    """View to list all automation scripts with optional filtering by test case"""
    # Debug information
    print("\n==== AUTOMATION LIST VIEW EXECUTION ====", file=sys.stderr)
    
    # Get filter parameters
    test_case_id = request.GET.get('test_case_id', '')
    status = request.GET.get('status', '')
    
    # Base queryset
    automations_query = Automation.objects.all()
    
    # Apply filters if provided
    if test_case_id:
        automations_query = automations_query.filter(test_case_id=test_case_id)
        print(f"Filtering by test_case_id: {test_case_id}", file=sys.stderr)
    
    if status:
        automations_query = automations_query.filter(status=status)
        print(f"Filtering by status: {status}", file=sys.stderr)
    
    # Get all automations
    automations = automations_query.order_by('-created_at')
    
    # Get all test cases for the filter dropdown
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    context = {
        'automations': automations,
        'test_cases': test_cases,
        'selected_test_case': test_case_id,
        'selected_status': status
    }
    
    return render(request, 'tocop/automation_list.html', context)


def automation_create(request):
    """View to create a new automation script"""
    # Get all test cases for the dropdown
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    if request.method == 'POST':
        # Process form submission
        test_case_id = request.POST.get('test_case')
        script_content = request.POST.get('script_content')
        description = request.POST.get('description')
        
        try:
            # Get the test case object
            test_case = TestCase.objects.get(id=test_case_id)
            
            # Create new automation
            automation = Automation.objects.create(
                test_case=test_case,
                script_content=script_content,
                description=description,
                status='draft'
            )
            
            messages.success(request, 'Automation script created successfully!')
            return redirect('automation_list')
        except Exception as e:
            messages.error(request, f'Error creating automation: {str(e)}')
    
    context = {
        'test_cases': test_cases
    }
    
    return render(request, 'tocop/automation_create.html', context)