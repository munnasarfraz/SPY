from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
import google.generativeai as genai
from django.conf import settings
import sys
import json
from .models import TestCase, Automation
from autoai.models import KeyWord_1, Steps_1

# Function to generate automation steps using AI model
def generate_automation_steps(test_case, keyword):
    """Generate automation steps for a test case using AI model"""
    from .views import generate_OR, read_json_file
    
    # Get AI configuration
    try:
        from autoai.models import conf_1
        ai_config = conf_1.objects.first()
        if ai_config and ai_config.g_api_key:
            api_key = ai_config.g_api_key
        else:
            # Use a default API key or raise an error
            api_key = settings.GEMINI_API_KEY if hasattr(settings, 'GEMINI_API_KEY') else None
            
        if not api_key:
            print("No API key found for Gemini", file=sys.stderr)
            return []
            
        # Configure the Gemini API
        genai.configure(api_key=api_key)
    except Exception as e:
        print(f"Error configuring AI: {str(e)}", file=sys.stderr)
        return []
    
    # Get XPath data from Object Repository
    xjson = None
    if hasattr(test_case, 'url') and test_case.url:
        try:
            screen_name = generate_OR(test_case.url)
            print(f"DEBUG: Generated OR screen_name: {screen_name}")
            xjson = read_json_file(screen_name)
            print(f"DEBUG: Loaded XPath data: {json.dumps(xjson, indent=2) if xjson else 'None'}")
        except Exception as e:
            print(f"DEBUG: Error getting XPath data: {str(e)}")
    
    # Create a prompt for the AI model with XPath data
    prompt = f"""
    You are an automation assistant. Convert the following test case into automation steps that can be used with Selenium WebDriver.
    
    Test Case ID: {test_case.test_case_id}
    Test Scenario Name: {test_case.scenario_name}
    Test Case Description: {test_case.description}
    Preconditions: {test_case.preconditions}
    Test Data: {test_case.test_data}
    Test Steps: {test_case.test_steps}
    Expected Results: {test_case.expected_results}
    URL: {test_case.url if hasattr(test_case, 'url') else ''}

    Context:
    Use only the keys from the object_xpat JSON UI object when writing test steps. When the test step involves clicking the primary button to complete the signup process, use the key that corresponds to that button's action (e.g., 'agree_&_join').
    in the test <Test Steps> should take from the key of object_xpat

    object_xpat = {json.dumps(xjson, ensure_ascii=False, indent=4) if xjson else "{}"}

    Instructions:
    - Generate test cases covering positive, negative, edge, and exception scenarios.
    - Where the application name is required, use {test_case.url if hasattr(test_case, 'url') and test_case.url else "practicetestautomation.com"}
    - Apply relevant business rules in test data.
    - Use explicit static text (e.g., "a_username_with_256_characters") instead of programmatic notations like `.repeat()`.
    - If any required data is unavailable, respond with: "Requested Data not available".
    - **Do not include any introductory or concluding sentences.**
    - **Do not include any explanations or commentary about the test cases.**
    - **Your entire response MUST be a valid JSON array as specified in the Output Format.**
    - Before returning, validate the JSON using a standard JSON parser.
    - If the JSON is invalid, fix and re-validate before outputting.
    - The final output must be valid JSON, parsable by Python's json.loads().

    **IMPORTANT ACTION RULES:**
    - For text input fields (input[type="text"], input[type="email"], input[type="password"], textarea): Use "SetText" action
    - For buttons (button, input[type="submit"], input[type="button"]): Use "ButtonClick" action  
    - For links (a tags): Use "ElementClick" action
    - For dropdowns/select elements: Use "Select" action
    - For checkboxes and radio buttons: Use "ElementClick" action
    - For navigation steps: Use "Navigate" action
    - For verification steps: Use "Verify" action

    Return only the raw JSON array, with no markdown formatting or additional annotations.
    **Output Format** perfect json only like below format only
    [
        {{
            "ObjectName": "Use XPath from object_xpat keys above",
            "InputValue": "Value to input (if applicable)",
            "ExpectedValue": "Expected value or result",
            "Action": "SetText | ButtonClick | ElementClick | Select | Navigate | Verify",
            "WindowType": "main",
            "StepDescription": "Description of the step"
        }}
    ]
    
    Make sure to include all necessary steps to complete the test case, including navigation, form filling, validation, etc.
    Use the XPath selectors from the object_xpat JSON object for the ObjectName field.
    """

    try:
        # Generate content using Gemini
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(prompt)
        
        # Extract JSON from response
        raw_text = response.text
        
        # Clean up the response to extract valid JSON
        if "```json" in raw_text:
            json_text = raw_text.split("```json")[1].split("```")[0].strip()
        elif "```" in raw_text:
            json_text = raw_text.split("```")[1].strip()
        else:
            json_text = raw_text.strip()
            
        # Parse the JSON
        steps = json.loads(json_text)
        return steps
    except Exception as e:
        print(f"Error generating steps with AI: {str(e)}", file=sys.stderr)
        # Return a basic step structure as fallback
        return [
            {
                "object_name": "body",
                "input_value": "",
                "expected_value": "Page loaded",
                "action": "verify",
                "window_type": "main",
                "description": f"Verify {test_case.scenario_name} page is loaded"
            }
        ]

# New function to generate automation for a specific test case
def generate_automation(request, test_case_id):
    """Generate automation test case using AI for a specific test case"""
    # Debug information
    print("\n==== GENERATE AUTOMATION VIEW EXECUTION ====", file=sys.stderr)
    print(f"Generating automation for test case ID: {test_case_id}", file=sys.stderr)
    
    # Get the test case
    test_case = get_object_or_404(TestCase, id=test_case_id)
    
    # Check if automation already exists
    existing_automation = Automation.objects.filter(test_case=test_case).first()
    
    # If automation exists, we'll update it instead of creating a new one
    if existing_automation:
        # Get or create a keyword for this test case
        keyword, created = KeyWord_1.objects.get_or_create(
            keyword_Name=test_case.scenario_name[:50],  # Limit to 50 chars
            defaults={
                'keyword_Desc': f"Test Case: {test_case.test_case_id} - {test_case.scenario_name}\n\nDescription: {test_case.description}\n\nTest Steps: {test_case.test_steps}",
                'p': None,  # Project - can be None
                'u': None,  # User - can be None
            }
        )
        
        # Delete existing steps for this keyword
        Steps_1.objects.filter(k=keyword).delete()
        
        # Generate new steps using AI
        steps = generate_automation_steps(test_case, keyword)
        
        # Create Steps_1 entries for the keyword
        steps_count = 0
        for i, step in enumerate(steps, 1):
            Steps_1.objects.create(
                k=keyword,
                object_Name=step.get('ObjectName', step.get('object_name', '')),
                input_Value=step.get('InputValue', step.get('input_value', '')),
                expected_Value=step.get('ExpectedValue', step.get('expected_value', '')),
                action=step.get('Action', step.get('action', '')),
                window_Type=step.get('WindowType', step.get('window_type', 'main')),
                step_Descriptions=f"Step {i}: {step.get('StepDescription', step.get('description', ''))}"
            )
            steps_count += 1
        
        # Update the automation status
        existing_automation.status = "In Progress"
        existing_automation.save()
        
        messages.success(request, f"Updated automation '{existing_automation.name}' with {steps_count} AI-generated steps!")
    else:
        # Create a new keyword for this test case
        keyword = KeyWord_1.objects.create(
            keyword_Name=test_case.scenario_name[:50],  # Limit to 50 chars
            keyword_Desc=f"Test Case: {test_case.test_case_id} - {test_case.scenario_name}\n\nDescription: {test_case.description}\n\nTest Steps: {test_case.test_steps}",
            p=None,  # Project - can be None
            u=None,  # User - can be None
        )
        
        # Create new automation entry
        automation = Automation.objects.create(
            test_case=test_case,
            automation_id=f"AUTO-{test_case.test_case_id}",
            name=f"AI-{test_case.scenario_name}",
            language="Python",
            framework="Selenium",
            status="In Progress"
        )
        
        # Generate steps using AI model
        steps = generate_automation_steps(test_case, keyword)
        
        # Create Steps_1 entries for the keyword
        steps_count = 0
        for i, step in enumerate(steps, 1):
            Steps_1.objects.create(
                k=keyword,
                object_Name=step.get('ObjectName', step.get('object_name', '')),
                input_Value=step.get('InputValue', step.get('input_value', '')),
                expected_Value=step.get('ExpectedValue', step.get('expected_value', '')),
                action=step.get('Action', step.get('action', '')),
                window_Type=step.get('WindowType', step.get('window_type', 'main')),
                step_Descriptions=f"Step {i}: {step.get('StepDescription', step.get('description', ''))}"
            )
            steps_count += 1
        
        messages.success(request, f"Created new automation '{automation.name}' with {steps_count} AI-generated steps!")
    
    # Redirect to the keyword detail page to view the generated steps
    return redirect(f"/keyword/{keyword.id}/")