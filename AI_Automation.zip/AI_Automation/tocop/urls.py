from django.urls import path
from . import views
from .generate_automation import generate_automation
from .automation_views import automation_list, automation_create
from .views import tocop
urlpatterns = [
    path('', views.tocop, name='tocop'),
    path('generate-automation/<int:test_case_id>/', generate_automation, name='generate_automation'),
    path('automation/', views.tocop, name='automation_list'),
    path('automation-create/', automation_create, name='automation_create'),
    path('automation/<int:automation_id>/', views.automation_detail, name='automation_detail'),
]