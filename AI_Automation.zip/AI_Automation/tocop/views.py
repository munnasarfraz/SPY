from django.shortcuts import render, redirect
from django.contrib import messages
#from google import genai
import google.generativeai as genai

from django.http import JsonResponse
from .models import SelectedRow
from django.views.decorators.csrf import csrf_exempt

import re
import json
import time
import urllib.parse

from autoai.models import *
from django.http import HttpResponse


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import requests
from bs4 import BeautifulSoup
from lxml import html
from urllib.parse import urlparse
import re
import json
import os
import platform
from selenium.webdriver.chrome.options import Options
screen_name = ""
os_type = platform.system()

def read_json_file(screen_name, folder_name="OR"):
    print('screen_name - ', screen_name)
    # global screen_name
    file_path = os.path.join(folder_name, f"{screen_name}.json")
    print('file_path - ', file_path)
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
        return data
    # except FileNotFoundError:
    #     return None
    # except json.JSONDecodeError as e:
    #     return None
    except Exception as e:
        return str(e)


# Determine if an element is an interactive/visual object
def is_visual_object(el):
    if el.name in ['button', 'img', 'a', 'textarea']:
        return True
    if el.name == 'input' and el.get('type', 'text') in ['text', 'email', 'password', 'submit', 'button', 'search', 'tel']:
        return True
    if el.get('onclick') or el.get('role') in ['button', 'link']:
        return True
    return False

# Generate relative XPath for element
def get_relative_unique_xpath(element):
    tag = element.name

    if element.get('id'):
        return f'//{tag}[@id="{element["id"]}"]'
    if element.get('class'):
        class_conditions = ' and '.join([f'contains(@class, "{cls}")' for cls in element['class']])
        return f'//{tag}[{class_conditions}]'

    parent = element.parent
    if parent:
        siblings = [sib for sib in parent.find_all(tag, recursive=False)]
        if len(siblings) > 1:
            index = siblings.index(element) + 1
            return f'//{parent.name}/{tag}[{index}]'
        else:
            return f'//{parent.name}/{tag}'
    
    return f'//{tag}'

# Generate a name from the visible caption or attributes
def get_element_caption(el):
    if el.name in ['a', 'button']:
        text = el.get_text(strip=True)
        if text:
            return text.lower().replace(' ', '_')[:30]
    
    for attr in ['aria-label', 'alt', 'title', 'name', 'id']:
        val = el.get(attr)
        if val:
            return val.lower().replace(' ', '_')[:30]
    
    return f"{el.name}_unknown"

# Extract screen name from URL
def extract_screen_name_from_url(url):
    parsed = urlparse(url)
    domain = parsed.netloc.replace('www.', '').split('.')[0]
    path = parsed.path.strip('/').replace('/', '_')
    screen = f"{domain}_{path}" if path else domain
    return re.sub(r'\W+', '_', screen)

# Main function: generates and saves the object repository
def generate_OR(url):
    import os
    import json
    global screen_name
    if not screen_name:
        screen_name = extract_screen_name_from_url(url)
        print('UPDATED SCREEN NAME :', screen_name)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:112.0) Gecko/20100101 Firefox/112.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://www.google.com",
        "Connection": "keep-alive"
    }
    
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    tree = html.fromstring(response.content)

    object_xpaths = {}

    for el in soup.find_all(True):
        if not is_visual_object(el):
            continue

        xpath = get_relative_unique_xpath(el)
        print(' XPATH :', xpath)

        try:
            if len(tree.xpath(xpath)) == 1:
                base_name = get_element_caption(el)
                name = base_name
                counter = 1

                while name in object_xpaths:
                    name = f"{base_name}_{counter}"
                    counter += 1

                object_xpaths[name] = xpath
        except:
            continue

    result = {
        "screen_name": screen_name,
        "objects": object_xpaths
    }

    json_output = json.dumps(result, indent=4)
    print('XPATH OUTPUT :', json_output)
    folder_name = "OR"
    filename = f"{screen_name}.json"
    tmp_filename = os.path.join(folder_name, filename)

    # Make sure the folder exists
    os.makedirs(folder_name, exist_ok=True)

    # Save the result to a file here
    with open(tmp_filename, 'w', encoding='utf-8') as f:
        f.write(json_output)

    print(f"Object repository saved to {filename}")

    return screen_name

# Create your views here.
def configure_AI(prompt):
    # print('------------------------------------')
    # print(prompt)
    # print('------------------------------------')

    # client = genai.Client(api_key="AIzaSyDX4PWUHgW01LzABl4RSEMT6FQCHXru9L0")

    # response = client.models.generate_content(
    #     model="gemini-2.0-flash",
    #     contents=prompt,
    #     temperature=0.0,  # Set to 0 for deterministic output
    #     max_tokens=150,   # Adjust to your desired length
    #     top_p=1.0,        # Use top-p sampling if needed, or set to 1 for no truncation
    #     frequency_penalty=0.0,  # Ensure no penalties on repeated words
    #     presence_penalty=0.0 
    # )

    import google.generativeai as genai

    genai.configure(api_key="AQ.Ab8RN6LVWnuEqwjJqT6-FMEKwJf9TjIJAovqcYCTrR-ghrd0Zw")

    model = genai.GenerativeModel(
        model_name="gemini-2.0-flash",
        generation_config=genai.types.GenerationConfig(
            max_output_tokens=8192,
            temperature=0.0      
        )
    )

    response = model.generate_content(prompt)
    return response
    
def fix_unescaped_backslashes(text):
    # Replace backslashes not followed by valid escape characters (e.g., n, ", etc.)
    return re.sub(r'(?<!\\)\\(?![\\nrtb"\'/u])', r'\\\\', text)

def automation_detail(request, automation_id):
    """View to display detailed automation information"""
    from .models import Automation
    from django.shortcuts import get_object_or_404
    
    automation = get_object_or_404(Automation, id=automation_id)
    
    context = {
        'automation': automation,
        'test_case': automation.test_case,
    }
    
    return render(request, 'tocop/automation_detail.html', context)

def tocop(request):
    if request.method == "POST":
        if 'form_one_submit' in request.POST:
            data = request.POST
            domain = data.get('domain')
            subdomain = data.get('subdomain')
            functionality = data.get('functionality') 
            url = data.get('customer')
            role = data.get('role')
            context = ""
            # print('-----------------------------')
            # print(url)
            screen_name = generate_OR(url)
            print('####################################')
            print('screen_name ->', screen_name)
            print('####################################')
            xjson = read_json_file(screen_name)
            # print(xjson)
            # print('-----------------------------')
            ## Prompt for Generating Manual Test Cases with Gemini
            prompt = f"""
                You are an expert in generating manual test cases.
                Use the following information to generate the requested test cases:
                Application: practicetestautomation.com  
                Section: practice-test-login  
                Domain: {domain}  
                Subdomain: {subdomain}  
                Role: {role}  
                Functionality: {functionality}  

                Context:
                Use only the keys from the object_xpat JSON UI object when writing test steps. When the test step involves clicking the primary button to complete the signup process, use the key that corresponds to that button's action (e.g., 'agree_&_join').
				in the test <Test Steps> should take from the key of object_xpat


                object_xpat = {json.dumps(xjson, ensure_ascii=False, indent=4)}

                Instructions:
                - Generate test cases covering positive, negative, edge, and exception scenarios.
                - Where the application name is required, use {url}
                - Apply relevant business rules in test data.
                - Use explicit static text (e.g., "a_username_with_256_characters") instead of programmatic notations like `.repeat()`.
                - If any required data is unavailable, respond with: "Requested Data not available".
                - **Do not include any introductory or concluding sentences.**
                - **Do not include any explanations or commentary about the test cases.**
                - **Your entire response MUST be a valid JSON array as specified in the Output Format.**
                - Before returning, validate the JSON using a standard JSON parser.
                - If the JSON is invalid, fix and re-validate before outputting.
                - The final output must be valid JSON, parsable by Python’s json.loads().


                Return only the raw JSON array, with no markdown formatting or additional annotations.
                **Output Format** perfect json only like bew format only
                [
                {{
                    "table": {{
                    "headers": [
                        "Test Case ID",
                        "Test Scenario Name",
                        "Test Case Description",
                        "Preconditions",
                        "Test Data",
                        "Test Steps",
                        "Test Step Expected Results"
                    ],
                    "rows": [
                        {{
                        "Test Case ID": "<Test Case ID>",
                        "Test Scenario Name": "<Test Scenario Name>",
                        "Test Case Description": "<Test Case Description>",
                        "Preconditions": "<Preconditions>",
                        "Test Data": "<Test Data>",
                        "Test Steps": "<Test Steps>",
                        "Test Step Expected Results": "<Test Step Expected Results>"
                        }}
                    ]
                    }}
                }}
                ]
                """

            # prompt += prompt1
            print('#######################################################')
            print('prompt Parent ->', prompt)
            print('#######################################################')

            response = configure_AI(prompt)

            print('#######################################################')
            # print('##########response', response)
            print('#######################################################')

            #response_text = response.text
            # response_text = response_text.replace("```html", "")
            # response_text = response_text.replace("```", "")
            # response_text = response_text.replace("json", "")
            # response_text = response_text.replace("'", '"')
            # print('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', response_text)
            
            #response_text = json.loads(fix_unescaped_backslashes(response_text))

            # print('***************************************************')
            # print('##########response_text', response_text)
            # print('***************************************************')


            raw_text = response.candidates[0].content.parts[0].text

            # Optional: Remove code block markers if present
            if raw_text.startswith("```json"):
                json_text = raw_text.strip("```json").strip("```").strip()
            else:
                json_text = raw_text.strip()
            # json_text = json_text.replace("'", '"')
            print('XXXXXXXXXXXX=', json_text)
            #response_text = json.loads(fix_unescaped_backslashes(json_text))
            response_text = json.loads(json_text)

            print('XXXXXXXXXXXX=', response_text)
            context = {'json_data':response_text}
            return render(request, 'tocop/tocop.html', context)
        elif 'form_two_submit' in request.POST:
            return process_selected_rows(request)
        elif 'form_three_submit' in request.POST:
            return process_selected_rows_adv(request)
    else:
        screen_name = ""
        return render(request, 'tocop/tocop.html')

def render_table_page(request):
    return render(request, 'x.html')  # Render your HTML page

def convert_test_steps(test_steps_str):
    steps = re.split(r'\d+\.\s+', test_steps_str.strip())
    steps = [step.strip() for step in steps if step.strip()]
    numbered_steps = [f"{i + 1}. {step}" for i, step in enumerate(steps)]
    return numbered_steps

def clean_text(text):
    return ' '.join(text.split())

@csrf_exempt  # For testing; use CSRF protection in production
def process_selected_rows(request):
    clean_json = None  # Initialize clean_json to avoid reference before assignment
    if request.method == 'POST':
        if 'form_two_submit' in request.POST:
            tmpValue = request.POST.get('jsonData', '')
            input_text = json.loads(tmpValue)  # Convert the string to a Python object
            for row in input_text["rows"]:
                for key, value in row.items():
                    row[key] = clean_text(value)  # Apply your cleaning function to the data
            
            # Now clean_json is a Python dictionary
            clean_json = input_text  # You don't need to use json.dumps if passing it as a Python object
    # Render the template with the clean_json context
    if clean_json and "rows" in clean_json:
        return render(request, 'tocop/display_json.html', {'clean_json': clean_json})
    else:
        return render(request, 'no_data.html')  # Render no data page if no rows are available

def generate_prompt4tcs(row):
    # Create a prompt based on the row's data
    xurl = row['field_8'] if row['field_8'] else row['field_4']
    print(xurl)
    xurl = xurl.strip()
    # xpaths = generate_OR(xurl)
    print('####################')
    print('screen_name = ', screen_name)
    print('####################')
    xpaths = read_json_file(screen_name)
    print('==================================')
    print(xpaths)
    print('==================================')
    

    prompt = f"""
        You are an automation assistant. Convert the following test case into JSON test steps using XPath selectors from the page https://www.linkedin.com/signup.

        Use this test case:

        Test Case ID: {row['field_1']}
        Test Scenario Name: {row['field_2']}
        Test Case Description: {row['field_3']}
        Preconditions: {row['field_4']}
        Test Data: {row['field_5']}
        Test Steps: {row['field_6']}
        Test Step Expected Results: {row['field_7']}
        screen url: {row['field_8']}

        ONLY return the JSON. Do NOT include any explanation or additional text.
        Fil the Appropriate xpath from below xpath_json only 
        With the matching text of 'Test Steps' should takes the xpath from xpath_json json

        xpath_json = {xpaths}

        in case xpath not found in the above json,use below technique to updat the xpath.
        For object:
        - If a object does not have a unique ID or Name, try to extract its XPath using **text()** or other attributes like `class`, `aria-label`, or `type`. 
        - If there are multiple objkects with similar attributes (e.g., two "Submit" object), use **XPath indexing** to select the correct one. For example: `(//object[@type='submit'])[1]`.
        - If you cannot find a object by these methods, use **parent-child relationships** to locate the button, for example: `//div[@class='form-container']//object`.
        - Before returning, validate the JSON using a standard JSON parser.
        - If the JSON is invalid, fix and re-validate before outputting.
        - The final output must be valid JSON, parsable by Python’s json.loads().
        - If an object does not have a unique ID or Name, try to extract its XPath using text() or other attributes like class, aria-label, or type.
        - If there are multiple objects with similar attributes (e.g., two "Submit" objects), use XPath indexing to select the correct one. For example: (//object[@type='submit'])[1].
        - If you cannot find an object by these methods, use parent-child relationships to locate the button, for example: //div[@class='form-container']//object.
        - If a step has ObjectName as null or empty, InputValue as empty, and the StepDescription contains the word "navigate" (case-insensitive), then set "Action": "Navigate" instead of "ElementClick".
        - Before returning, validate the JSON using a standard JSON parser.
        - If the JSON is invalid, fix and re-validate before outputting.

        Ensure that the same field (e.g., username or password) always uses the same XPath across steps. Do not switch between id, name, or CSS arbitrarily. Reuse the exact XPath consistently if it refers to the same element.

        ONLY return the JSON. No extra text.
        Use this exact JSON format:
        [
            {{
                "ObjectName": "<xpath of element>",
                "InputValue": "<value to input or blank>",
                "Action": "<SetText | ButtonClick | ElementClick.>",
                "ExpectedValue": null,
                "WindowType": null,
                "StepDescription": "<short description of the step>"
            }}
        ]
    """

    
    print('-------------------------------------------------------')
    print('generate_prompt4tcs ->', prompt)
    print('-------------------------------------------------------')
    return prompt

def extract_url(data):
    import re
    # Regular expression to find valid URLs (http or https)
    url_pattern = r'https?://[^\s]+'
    # Set to store unique, valid URLs
    urls = set()
    for value in data.values():
        # Find all URLs in the current string
        found_urls = re.findall(url_pattern, value)
        # Validate the URLs and add them to the set (only valid URLs)
        for url in found_urls:
            if re.match(r'https?://[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+', url):  # Simple validation for basic URL structure
                urls.add(url)
    # If any URLs are found, get the first one (as a single string), otherwise return an empty string
    urls_string = next(iter(urls), '')  # Get the first URL from the set, or empty string if no URL
    if urls_string.endswith('.'):
        urls_string = urls_string[:-1]
    return urls_string

def process_selected_rows_adv(request):
    clean_json = None  # Initialize clean_json to avoid reference before assignment
    import json
    if request.method == 'POST':
        if 'form_three_submit' in request.POST:
            tmpValue = request.POST.get('jsonData', '')
            input_text = json.loads(tmpValue)  # Convert the string to a Python object
            
            combined_data = {}
            combined_tcs_name = {}
            combined_urls = {}
            
            for index, row in enumerate(input_text["rows"], start=1):
                
                response = configure_AI(generate_prompt4tcs(row))
                clean_text = response.text.replace('```', '')
                clean_text = clean_text.replace('json', '')
                print('-----------==========================------------------')
                print(clean_text)
                print('-----------==========================------------------')
                             
                combined_data[f'row{index}'] = clean_text
                combined_tcs_name[f'row{index}'] = (row['field_2'], row['field_3'])
            
                if row['field_8'] in [None, '', 'null']:
                    combined_urls[f'row{index}'] = extract_url(row)
                else:
                    combined_urls[f'row{index}'] = row['field_8']
                
            import json
            
            clean_json = combined_data
            rows = {}
            for key in clean_json:
                rows[key] = json.loads(clean_json[key].strip())

            tcs = {}
            for key, value in combined_tcs_name.items():
                tcs[key] = (value[0].strip(), value[1].strip())
            
            urls = {}
            for key, value in combined_urls.items():
                urls[key] = (value)
            
            context = {
                'clean_json': rows,
                'tcs': tcs,
                'urls': urls,
            }

                    
    # Render the template with the clean_json context
    if clean_json:
        return render(request, 'tocop/display_testcase.html', context)
    else:
        return render(request, 'no_data.html')  # Render no data page if no rows are available



# View to handle the saving/updating of JSON data (can be via POST request)
def update_json(request):
    if request.method == 'POST':
        # Get the updated JSON data from the request body
        updated_json = json.loads(request.body)
        # Here, you can save the updated JSON to your database or file
        return JsonResponse({"status": "success", "message": "JSON updated successfully."})
    return JsonResponse({"status": "error", "message": "Invalid request."})

@csrf_exempt
def save_test_steps(request):
    if request.method == "POST":
        processed_row_keys = set()
        for key, value in request.POST.items():
            if key.endswith("_ObjectName"):  # We look for fields ending with ObjectName
                row_key = key.split("_")[0]  # Extract the row_key from the input field name
                counter_key = key.split("_")[1]
                
                object_name = request.POST.get(f"{row_key}_{counter_key}_ObjectName", "")
                input_value = request.POST.get(f"{row_key}_{counter_key}_InputValue", "")
                action = request.POST.get(f"{row_key}_{counter_key}_Action", "")
                expected_value = request.POST.get(f"{row_key}_{counter_key}_ExpectedValue", "")
                window_type = request.POST.get(f"{row_key}_{counter_key}_WindowType", "")
                step_description = request.POST.get(f"{row_key}_{counter_key}_StepDescription", "")

                if row_key not in processed_row_keys:
                    tcs_name = request.POST.get(f"tcs_name_{row_key}", "") 
                    tcs_desc = request.POST.get(f"tcs_desc_{row_key}", "") 
                    # Create the keyword once for this row_key
                    new_keyword = KeyWord_1.objects.create(
                        keyword_Name=tcs_name,
                        keyword_Desc=tcs_desc,
                        p_id=request.session['project_id'],
                        u_id=request.session['user_id'],
                    )
                    new_keyword_id = new_keyword.id
                    processed_row_keys.add(row_key)
                # Create and save a new test step entry to the database

                Steps_1.objects.create(
                    object_Name=object_name,
                    input_Value=input_value,
                    action=action,
                    expected_Value=expected_value,
                    window_Type=window_type,
                    step_Descriptions=step_description,
                    k_id = new_keyword_id,
                )
        return HttpResponse("Test steps saved successfully!", content_type="text/plain")
    return render(request, 'tocop/display_testcase.html', {'clean_json': {}})

from django.http import JsonResponse
from django.shortcuts import render
import json
from django.views.decorators.csrf import csrf_protect
from collections import defaultdict

def group_by_step(data):
    steps = defaultdict(list)
    for key, value in data.items():
        # Split the key to extract the row number and the attribute name
        parts = key.split('_')
        # Extract the step number (1, 2, 3...) dynamically from the key
        step_number = parts[1]  # For example: "1", "2", "3" etc.
        attribute = parts[2]     # ObjectName, InputValue, Action, etc.
        # Build the step-wise structure dynamically
        step_key = f"Step{step_number}"
        
        # If it's the first time we're seeing the step, initialize an empty list
        if len(steps[step_key]) == 0:
            steps[step_key].append({
                "ObjectName": "",
                "InputValue": "",
                "Action": "",
                "ExpectedValue": "",
                "WindowType": "",
                "StepDescription": ""
            })
        
        # Populate the relevant attribute in the corresponding step
        if attribute == "ObjectName":
            steps[step_key][-1]["ObjectName"] = value
        elif attribute == "InputValue":
            steps[step_key][-1]["InputValue"] = value
        elif attribute == "Action":
            steps[step_key][-1]["Action"] = value
        elif attribute == "ExpectedValue":
            steps[step_key][-1]["ExpectedValue"] = value
        elif attribute == "WindowType":
            steps[step_key][-1]["WindowType"] = value
        elif attribute == "StepDescription":
            steps[step_key][-1]["StepDescription"] = value

    return steps

def execute_test_from_json(json_data, data_with_url):
    # Load the JSON data (Step-wise actions)
    steps = json.loads(json_data)

    # Initialize WebDriver (make sure the correct driver is available)
     # You can replace with Firefox or any other browser
    if os_type == "Linux":
        options = Options()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        driver = webdriver.Chrome(options=options)
    else:
        driver = webdriver.Chrome()

    driver.implicitly_wait(10)
    driver.maximize_window()
    # This will hold the execution report
    execution_report = {}

    def execute_step(step_number, step_data):
        # Initialize the step report dictionary with required fields
        step_report = {
            "Number": step_number,
            "Step_Descriptions": "",
            "InputValue": "",
            "Actual_Value": "",
            "Expected_Value": "",
            "Status": "Pass",
            "ErrorMessage": ""
        }

        try:
            for action in step_data:
                object_name = action['ObjectName']
                action_type = action['Action']
                input_value = action['InputValue']
                expected_value = action['ExpectedValue']
                description = action['StepDescription']

                # Update the Step Descriptions field
                step_report["Step_Descriptions"] = description
                step_report["Expected_Value"] = expected_value  # Expected value for verification

                # Perform the action based on Action type
                if action_type == "ButtonClick":
                    element = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.XPATH, object_name))
                    )
                    element.click()
                    step_report["Actual_Value"] = "Button clicked"

                elif action_type == "SetText":
                    element = WebDriverWait(driver, 10).until(
                        EC.visibility_of_element_located((By.XPATH, object_name))
                    )
                    element.clear()
                    element.send_keys(input_value)
                    step_report["InputValue"] = f"Text set to '{input_value}'"
                    step_report["Actual_Value"] = f"Text set to '{input_value}'"

                elif action_type == "VerifyElementPresent":
                    WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.XPATH, object_name))
                    )
                    step_report["Actual_Value"] = "Element is present"

                elif action_type == "VerifyTextPresent":
                    element = WebDriverWait(driver, 10).until(
                        EC.visibility_of_element_located((By.XPATH, object_name))
                    )
                    if expected_value not in element.text:
                        raise Exception(f"Text '{expected_value}' not found on the page.")
                    step_report["Actual_Value"] = f"Text '{expected_value}' found"

        except Exception as e:
            step_report["Status"] = "Fail"
            step_report["ErrorMessage"] = str(e)
            step_report["Actual_Value"] = f"Error: {str(e)}"
            print(f"Step {step_number}: {description} - Failed. Error: {str(e)}")

        # Add the completed step report to the overall execution report
        execution_report[step_number] = step_report

    # Open the initial URL (from Step 1)
    #initial_url = "https://practicetestautomation.com/practice-test-login/"
    initial_url = data_with_url
    print('UUUUUUUUUUUUUUUUUUUUUURL', initial_url)
    driver.get(initial_url)

    # Execute all steps from JSON
    for step_number, step_data in steps.items():
        execute_step(step_number, step_data)

    # Close the browser
    driver.quit()

    # Print execution report
    # print(json.dumps(execution_report, indent=4))

    # Return the execution report (for saving or further processing)
    return execution_report

def view_function(request):
    import json
    if request.method == 'GET':
        # Capture all GET parameters (query parameters in URL)
        all_row_data = request.GET.dict()
        data_without_url = {key: value for key, value in all_row_data.items() if key != 'url'}
        data_with_url = all_row_data.get('url', None)
        step_wise_data = group_by_step(data_without_url)
        json_data = json.dumps(step_wise_data, indent=4)
        execution_report = execute_test_from_json(json_data, data_with_url)
        # Pass the data to the template
        return render(request, 'tocop/display_data.html', {'json_data': execution_report})
