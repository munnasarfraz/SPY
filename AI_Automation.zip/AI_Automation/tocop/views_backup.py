﻿from django.shortcuts import render, redirect
from django.contrib import messages
#from google import genai
import google.generativeai as genai

from django.http import JsonResponse
from .models import SelectedRow, Requirement, TestCase, Automation
from django.views.decorators.csrf import csrf_exempt

import re
import json
import time
import urllib.parse

from autoai.models import *
from django.http import HttpResponse


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import requests
from bs4 import BeautifulSoup
from lxml import html
from urllib.parse import urlparse
import re
import json
import os
import platform
from selenium.webdriver.chrome.options import Options
screen_name = ""
os_type = platform.system()

def read_json_file(screen_name, folder_name="OR"):
    print('screen_name - ', screen_name)
    # global screen_name
    file_path = os.path.join(folder_name, f"{screen_name}.json")
    print('file_path - ', file_path)
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
        return data
    # except FileNotFoundError:
    #     return None
    # except json.JSONDecodeError as e:
    #     return None
    except Exception as e:
        return str(e)


# Determine if an element is an interactive/visual object
def is_visual_object(el):
    if el.name in ['button', 'img', 'a', 'textarea']:
        return True
    if el.name == 'input' and el.get('type', 'text') in ['text', 'email', 'password', 'submit', 'button', 'search', 'tel']:
        return True
    if el.get('onclick') or el.get('role') in ['button', 'link']:
        return True
    return False

# Generate relative XPath for element
def get_relative_unique_xpath(element):
    tag = element.name

    if element.get('id'):
        return f'//{tag}[@id="{element["id"]}"]'
    if element.get('class'):
        class_conditions = ' and '.join([f'contains(@class, "{cls}")' for cls in element['class']])
        return f'//{tag}[{class_conditions}]'

    parent = element.parent
    if parent:
        siblings = [sib for sib in parent.find_all(tag, recursive=False)]
        if len(siblings) > 1:
            index = siblings.index(element) + 1
            return f'//{parent.name}/{tag}[{index}]'
        else:
            return f'//{parent.name}/{tag}'
    
    return f'//{tag}'

# Generate a name from the visible caption or attributes
def get_element_caption(el):
    if el.name in ['a', 'button']:
        text = el.get_text(strip=True)
        if text:
            return text.lower().replace(' ', '_')[:30]
    
    for attr in ['aria-label', 'alt', 'title', 'name', 'id']:
        val = el.get(attr)
        if val:
            return val.lower().replace(' ', '_')[:30]
    
    return f"{el.name}_unknown"

# Extract screen name from URL
def extract_screen_name_from_url(url):
    parsed = urlparse(url)
    domain = parsed.netloc.replace('www.', '').split('.')[0]
    path = parsed.path.strip('/').replace('/', '_')
    screen = f"{domain}_{path}" if path else domain
    return re.sub(r'\W+', '_', screen)

# Main function: generates and saves the object repository
def generate_OR(url):
    import os
    import json
    global screen_name
    if not screen_name:
        screen_name = extract_screen_name_from_url(url)
        print('UPDATED SCREEN NAME :', screen_name)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:112.0) Gecko/20100101 Firefox/112.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://www.google.com",
        "Connection": "keep-alive"
    }
    
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    tree = html.fromstring(response.content)

    object_xpaths = {}

    for el in soup.find_all(True):
        if not is_visual_object(el):
            continue

        xpath = get_relative_unique_xpath(el)
        print(' XPATH :', xpath)

        try:
            if len(tree.xpath(xpath)) == 1:
                base_name = get_element_caption(el)
                name = base_name
                counter = 1

                while name in object_xpaths:
                    name = f"{base_name}_{counter}"
                    counter += 1

                object_xpaths[name] = xpath
        except:
            continue

    result = {
        "screen_name": screen_name,
        "objects": object_xpaths
    }

    json_output = json.dumps(result, indent=4)
    print('XPATH OUTPUT :', json_output)
    folder_name = "OR"
    filename = f"{screen_name}.json"
    tmp_filename = os.path.join(folder_name, filename)

    # Make sure the folder exists
    os.makedirs(folder_name, exist_ok=True)

    # Save the result to a file here
    with open(tmp_filename, 'w', encoding='utf-8') as f:
        f.write(json_output)

    print(f"Object repository saved to {filename}")

    return screen_name

# Create your views here.
def configure_AI(prompt):
    # print('------------------------------------')
    # print(prompt)
    # print('------------------------------------')

    # client = genai.Client(api_key="AIzaSyDX4PWUHgW01LzABl4RSEMT6FQCHXru9L0")

    # response = client.models.generate_content(
    #     model="gemini-2.0-flash",
    #     contents=prompt,
    #     temperature=0.0,  # Set to 0 for deterministic output
    #     max_tokens=150,   # Adjust to your desired length
    #     top_p=1.0,        # Use top-p sampling if needed, or set to 1 for no truncation
    #     frequency_penalty=0.0,  # Ensure no penalties on repeated words
    #     presence_penalty=0.0 
    # )

    import google.generativeai as genai

    genai.configure(api_key="AIzaSyDX4PWUHgW01LzABl4RSEMT6FQCHXru9L0")

    model = genai.GenerativeModel(
        model_name="gemini-2.0-flash",
        generation_config=genai.types.GenerationConfig(
            temperature=0.7,
            top_p = 0.9,
            top_k = 40,
            max_output_tokens=8192
        )
    )

    response = model.generate_content(prompt)
    return response
    
def fix_unescaped_backslashes(text):
    # Replace backslashes not followed by valid escape characters (e.g., n, ", etc.)
    return re.sub(r'(?<!\\)\\(?![\\nrtb"\'/u])', r'\\\\', text)

def tocop(request):
    if request.method == "POST":
        if 'form_one_submit' in request.POST:
            data = request.POST
            domain = data.get('domain')
            subdomain = data.get('subdomain')
            functionality = data.get('functionality') 
            url = data.get('customer')
            role = data.get('role')
            context = ""
            # print('-----------------------------')
            # print(url)
            screen_name = generate_OR(url)
            print('####################################')
            print('screen_name ->', screen_name)
            print('####################################')
            xjson = read_json_file(screen_name)
            # print(xjson)
            # print('-----------------------------')
            ## Prompt for Generating Manual Test Cases with Gemini
            prompt = f"""
                You are an expert in generating manual test cases.
                Use the following information to generate the requested test cases:
                Application: practicetestautomation.com  
                Section: practice-test-login  
                Domain: {domain}  
                Subdomain: {subdomain}  
                Role: {role}  
                Functionality: {functionality}  

                Context:
Â  Â  Â  Â  Â  Â  Â  Â  Â  Use only the keys from the object_xpat JSON UI object when writing test steps. When the test step involves clicking the primary button to complete the signup process, use the key that corresponds to that button's action (e.g., 'agree_&_join').
				in the test <Test Steps> should take from the key of object_xpat


                object_xpat = {json.dumps(xjson, ensure_ascii=False, indent=4)}

                Instructions:
                - Generate test cases covering positive, negative, edge, and exception scenarios.
                - Where the application name is required, use {url}
                - Apply relevant business rules in test data.
                - Use explicit static text (e.g., "a_username_with_256_characters") instead of programmatic notations like `.repeat()`.
                - If any required data is unavailable, respond with: "Requested Data not available".
                - **Do not include any introductory or concluding sentences.**
                - **Do not include any explanations or commentary about the test cases.**
                - **Your entire response MUST be a valid JSON array as specified in the Output Format.**
                - Before returning, validate the JSON using a standard JSON parser.
                - If the JSON is invalid, fix and re-validate before outputting.
                - The final output must be valid JSON, parsable by Pythonâ€™s json.loads().


                Return only the raw JSON array, with no markdown formatting or additional annotations.
                **Output Format** perfect json only like bew format only
                [
                {{
                    "table": {{
                    "headers": [
                        "Test Case ID",
                        "Test Scenario Name",
                        "Test Case Description",
                        "Preconditions",
                        "Test Data",
                        "Test Steps",
                        "Test Step Expected Results"
                    ],
                    "rows": [
                        {{
                        "Test Case ID": "<Test Case ID>",
                        "Test Scenario Name": "<Test Scenario Name>",
                        "Test Case Description": "<Test Case Description>",
                        "Preconditions": "<Preconditions>",
                        "Test Data": "<Test Data>",
                        "Test Steps": "<Test Steps>",
                        "Test Step Expected Results": "<Test Step Expected Results>"
                        }}
                    ]
                    }}
                }}
                ]
                """

            # prompt += prompt1
            print('#######################################################')
            print('prompt Parent ->', prompt)
            print('#######################################################')

            response = configure_AI(prompt)

            print('#######################################################')
            # print('##########response', response)
            print('#######################################################')

            #response_text = response.text
            # response_text = response_text.replace("```html", "")
            # response_text = response_text.replace("```", "")
            # response_text = response_text.replace("json", "")
            # response_text = response_text.replace("'", '"')
            # print('XXXXXXXXXXXXXXXXXXXXXX', response_text)
            
            #response_text = json.loads(fix_unescaped_backslashes(response_text))

            # print('***************************************************')
            # print('##########response_text', response_text)
            # print('***************************************************')


            raw_text = response.candidates[0].content.parts[0].text

            # Optional: Remove code block markers if present
            if raw_text.startswith("```json"):
                json_text = raw_text.strip("```json").strip("```").strip()
            else:
                json_text = raw_text.strip()
            # json_text = json_text.replace("'", '"')
            print('XXXXXXXXXXXX=', json_text)
            #response_text = json.loads(fix_unescaped_backslashes(json_text))
            response_text = json.loads(json_text)

            print('XXXXXXXXXXXX=', response_text)
            context = {'json_data':response_text}
            return render(request, 'tocop/tocop.html', context)
        elif 'form_two_submit' in request.POST:
            return process_selected_rows(request)
        elif 'form_three_submit' in request.POST:
            return process_selected_rows_adv(request)
    else:
        screen_name = ""
        return render(request, 'tocop/tocop.html')

def render_table_page(request):
    return render(request, 'x.html')  # Render your HTML page

def convert_test_steps(test_steps_str):
    steps = re.split(r'\d+\.\s+', test_steps_str.strip())
    steps = [step.strip() for step in steps if step.strip()]
    numbered_steps = [f"{i + 1}. {step}" for i, step in enumerate(steps)]
    return numbered_steps

def clean_text(text):
    return ' '.join(text.split())

@csrf_exempt  # For testing; use CSRF protection in production
def process_selected_rows(request):
    clean_json = None  # Initialize clean_json to avoid reference before assignment
    if request.method == 'POST':
        if 'form_two_submit' in request.POST:
            tmpValue = request.POST.get('jsonData', '')
            input_text = json.loads(tmpValue)  # Convert the string to a Python object
            for row in input_text["rows"]:
                for key, value in row.items():
                    row[key] = clean_text(value)  # Apply your cleaning function to the data
            
            # Now clean_json is a Python dictionary
            clean_json = input_text  # You don't need to use json.dumps if passing it as a Python object
    # Render the template with the clean_json context
    if clean_json and "rows" in clean_json:
        return render(request, 'tocop/display_json.html', {'clean_json': clean_json})
    else:
        return render(request, 'no_data.html')  # Render no data page if no rows are available

def generate_prompt4tcs(row):
    # Create a prompt based on the row's data
    xurl = row['field_8'] if row['field_8'] else row['field_4']
    print(xurl)
    xurl = xurl.strip()
    # xpaths = generate_OR(xurl)
    print('####################')
    print('screen_name = ', screen_name)
    print('####################')
    xpaths = read_json_file(screen_name)
    print('==================================')
    print(xpaths)
    print('==================================')
    

    prompt = f"""
        You are an automation assistant. Convert the following test case into JSON test steps using XPath selectors from the page https://www.linkedin.com/signup.

        Use this test case:

        Test Case ID: {row['field_1']}
        Test Scenario Name: {row['field_2']}
        Test Case Description: {row['field_3']}
        Preconditions: {row['field_4']}
        Test Data: {row['field_5']}
        Test Steps: {row['field_6']}
        Test Step Expected Results: {row['field_7']}
        screen url: {row['field_8']}

        ONLY return the JSON. Do NOT include any explanation or additional text.
        Fil the Appropriate xpath from below xpath_json only 
        With the matching text of 'Test Steps' should takes the xpath from xpath_json json

        xpath_json = {xpaths}

        in case xpath not found in the above json,use below technique to updat the xpath.
        For object:
        - If a object does not have a unique ID or Name, try to extract its XPath using **text()** or other attributes like `class`, `aria-label`, or `type`.Â 
        - If there are multiple objkects with similar attributes (e.g., two "Submit" object), use **XPath indexing** to select the correct one. For example: `(//object[@type='submit'])[1]`.
        - If you cannot find a object by these methods, use **parent-child relationships** to locate the button, for example: `//div[@class='form-container']//object`.
        - Before returning, validate the JSON using a standard JSON parser.
        - If the JSON is invalid, fix and re-validate before outputting.
        - The final output must be valid JSON, parsable by Pythonâ€™s json.loads().
        - If an object does not have a unique ID or Name, try to extract its XPath using text() or other attributes like class, aria-label, or type.
        - If there are multiple objects with similar attributes (e.g., two "Submit" objects), use XPath indexing to select the correct one. For example: (//object[@type='submit'])[1].
        - If you cannot find an object by these methods, use parent-child relationships to locate the button, for example: //div[@class='form-container']//object.
        - If a step has ObjectName as null or empty, InputValue as empty, and the StepDescription contains the word "navigate" (case-insensitive), then set "Action": "Navigate" instead of "ElementClick".
        - Before returning, validate the JSON using a standard JSON parser.
        - If the JSON is invalid, fix and re-validate before outputting.

        Ensure that the same field (e.g., username or password) always uses the same XPath across steps. Do not switch between id, name, or CSS arbitrarily. Reuse the exact XPath consistently if it refers to the same element.

        ONLY return the JSON. No extra text.
        Use this exact JSON format:
        [
        Â  Â  {{
        Â  Â  Â  Â  "ObjectName": "<xpath of element>",
        Â  Â  Â  Â  "InputValue": "<value to input or blank>",
        Â  Â  Â  Â  "Action": "<SetText | ButtonClick | ElementClick.>",
        Â  Â  Â  Â  "ExpectedValue": null,
        Â  Â  Â  Â  "WindowType": null,
        Â  Â  Â  Â  "StepDescription": "<short description of the step>"
        Â  Â  }}
        ]
    """

    
    print('-------------------------------------------------------')
    print('generate_prompt4tcs ->', prompt)
    print('-------------------------------------------------------')
    return prompt

def extract_url(data):
    import re
    # Regular expression to find valid URLs (http or https)
    url_pattern = r'https?://[^\s]+'
    # Set to store unique, valid URLs
    urls = set()
    for value in data.values():
        # Find all URLs in the current string
        found_urls = re.findall(url_pattern, value)
        # Validate the URLs and add them to the set (only valid URLs)
        for url in found_urls:
            if re.match(r'https?://[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+', url):  # Simple validation for basic URL structure
                urls.add(url)
    # If any URLs are found, get the first one (as a single string), otherwise return an empty string
    urls_string = next(iter(urls), '')  # Get the first URL from the set, or empty string if no URL
    if urls_string.endswith('.'):
        urls_string = urls_string[:-1]
    return urls_string

def process_selected_rows_adv(request):
    clean_json = None  # Initialize clean_json to avoid reference before assignment
    import json
    if request.method == 'POST':
        if 'form_three_submit' in request.POST:
            tmpValue = request.POST.get('jsonData', '')
            input_text = json.loads(tmpValue)  # Convert the string to a Python object
            
            combined_data = {}
            combined_tcs_name = {}
            combined_urls = {}
            
            for index, row in enumerate(input_text["rows"], start=1):
                
                response = configure_AI(generate_prompt4tcs(row))
                clean_text = response.text.replace('```', '')
                clean_text = clean_text.replace('json', '')
                print('-----------==========================------------------')
                print(clean_text)
                print('-----------==========================------------------')
                             
                combined_data[f'row{index}'] = clean_text
                combined_tcs_name[f'row{index}'] = (row['field_2'], row['field_3'])
            
                if row['field_8'] in [None, '', 'null']:
                    combined_urls[f'row{index}'] = extract_url(row)
                else:
                    combined_urls[f'row{index}'] = row['field_8']
                
            import json
            
            clean_json = combined_data
            rows = {}
            for key in clean_json:
                rows[key] = json.loads(clean_json[key].strip())

            tcs = {}
            for key, value in combined_tcs_name.items():
                tcs[key] = (value[0].strip(), value[1].strip())
            
            urls = {}
            for key, value in combined_urls.items():
                urls[key] = (value)
            
            context = {
                'clean_json': rows,
                'tcs': tcs,
                'urls': urls,
            }

                    
    # Render the template with the clean_json context
    if clean_json:
        return render(request, 'tocop/display_testcase.html', context)
    else:
        return render(request, 'no_data.html')  # Render no data page if no rows are available



# View to handle the saving/updating of JSON data (can be via POST request)
def update_json(request):
    if request.method == 'POST':
        # Get the updated JSON data from the request body
        updated_json = json.loads(request.body)
        # Here, you can save the updated JSON to your database or file
        return JsonResponse({"status": "success", "message": "JSON updated successfully."})
    return JsonResponse({"status": "error", "message": "Invalid request."})

@csrf_exempt
def save_test_steps(request):
    if request.method == "POST":
        processed_row_keys = set()
        for key, value in request.POST.items():
            if key.endswith("_ObjectName"):  # We look for fields ending with ObjectName
                row_key = key.split("_")[0]  # Extract the row_key from the input field name
                counter_key = key.split("_")[1]
                
                object_name = request.POST.get(f"{row_key}_{counter_key}_ObjectName", "")
                input_value = request.POST.get(f"{row_key}_{counter_key}_InputValue", "")
                action = request.POST.get(f"{row_key}_{counter_key}_Action", "")
                expected_value = request.POST.get(f"{row_key}_{counter_key}_ExpectedValue", "")
                window_type = request.POST.get(f"{row_key}_{counter_key}_WindowType", "")
                step_description = request.POST.get(f"{row_key}_{counter_key}_StepDescription", "")

                if row_key not in processed_row_keys:
                    tcs_name = request.POST.get(f"tcs_name_{row_key}", "") 
                    tcs_desc = request.POST.get(f"tcs_desc_{row_key}", "") 
                    # Create the keyword once for this row_key
                    new_keyword = KeyWord_1.objects.create(
                        keyword_Name=tcs_name,
                        keyword_Desc=tcs_desc,
                        p_id=request.session['project_id'],
                        u_id=request.session['user_id'],
                    )
                    new_keyword_id = new_keyword.id
                    processed_row_keys.add(row_key)
                # Create and save a new test step entry to the database

                Steps_1.objects.create(
                    object_Name=object_name,
                    input_Value=input_value,
                    action=action,
                    expected_Value=expected_value,
                    window_Type=window_type,
                    step_Descriptions=step_description,
                    k_id = new_keyword_id,
                )
        return HttpResponse("Test steps saved successfully!", content_type="text/plain")
    return render(request, 'tocop/display_testcase.html', {'clean_json': {}})

from django.http import JsonResponse
from django.shortcuts import render
import json
from django.views.decorators.csrf import csrf_protect
from collections import defaultdict

def group_by_step(data):
    steps = defaultdict(list)
    for key, value in data.items():
        # Split the key to extract the row number and the attribute name
        parts = key.split('_')
        # Extract the step number (1, 2, 3...) dynamically from the key
        step_number = parts[1]  # For example: "1", "2", "3" etc.
        attribute = parts[2]     # ObjectName, InputValue, Action, etc.
        # Build the step-wise structure dynamically
        step_key = f"Step{step_number}"
        
        # If it's the first time we're seeing the step, initialize an empty list
        if len(steps[step_key]) == 0:
            steps[step_key].append({
                "ObjectName": "",
                "InputValue": "",
                "Action": "",
                "ExpectedValue": "",
                "WindowType": "",
                "StepDescription": ""
            })
        
        # Populate the relevant attribute in the corresponding step
        if attribute == "ObjectName":
            steps[step_key][-1]["ObjectName"] = value
        elif attribute == "InputValue":
            steps[step_key][-1]["InputValue"] = value
        elif attribute == "Action":
            steps[step_key][-1]["Action"] = value
        elif attribute == "ExpectedValue":
            steps[step_key][-1]["ExpectedValue"] = value
        elif attribute == "WindowType":
            steps[step_key][-1]["WindowType"] = value
        elif attribute == "StepDescription":
            steps[step_key][-1]["StepDescription"] = value

    return steps

def execute_test_from_json(json_data, data_with_url):
    # Load the JSON data (Step-wise actions)
    steps = json.loads(json_data)

    # Initialize WebDriver (make sure the correct driver is available)
     # You can replace with Firefox or any other browser
    if os_type == "Linux":
        options = Options()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        driver = webdriver.Chrome(options=options)
    else:
        driver = webdriver.Chrome()

    driver.implicitly_wait(10)
    driver.maximize_window()
    # This will hold the execution report
    execution_report = {}

    def execute_step(step_number, step_data):
        # Initialize the step report dictionary with required fields
        step_report = {
            "Number": step_number,
            "Step_Descriptions": "",
            "InputValue": "",
            "Actual_Value": "",
            "Expected_Value": "",
            "Status": "Pass",
            "ErrorMessage": ""
        }

        try:
            for action in step_data:
                object_name = action['ObjectName']
                action_type = action['Action']
                input_value = action['InputValue']
                expected_value = action['ExpectedValue']
                description = action['StepDescription']

                # Update the Step Descriptions field
                step_report["Step_Descriptions"] = description
                step_report["Expected_Value"] = expected_value  # Expected value for verification

                # Perform the action based on Action type
                if action_type == "ButtonClick":
                    element = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.XPATH, object_name))
                    )
                    element.click()
                    step_report["Actual_Value"] = "Button clicked"

                elif action_type == "SetText":
                    element = WebDriverWait(driver, 10).until(
                        EC.visibility_of_element_located((By.XPATH, object_name))
                    )
                    element.clear()
                    element.send_keys(input_value)
                    step_report["InputValue"] = f"Text set to '{input_value}'"
                    step_report["Actual_Value"] = f"Text set to '{input_value}'"

                elif action_type == "VerifyElementPresent":
                    WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.XPATH, object_name))
                    )
                    step_report["Actual_Value"] = "Element is present"

                elif action_type == "VerifyTextPresent":
                    element = WebDriverWait(driver, 10).until(
                        EC.visibility_of_element_located((By.XPATH, object_name))
                    )
                    if expected_value not in element.text:
                        raise Exception(f"Text '{expected_value}' not found on the page.")
                    step_report["Actual_Value"] = f"Text '{expected_value}' found"

        except Exception as e:
            step_report["Status"] = "Fail"
            step_report["ErrorMessage"] = str(e)
            step_report["Actual_Value"] = f"Error: {str(e)}"
            print(f"Step {step_number}: {description} - Failed. Error: {str(e)}")

        # Add the completed step report to the overall execution report
        execution_report[step_number] = step_report

    # Open the initial URL (from Step 1)
    #initial_url = "https://practicetestautomation.com/practice-test-login/"
    initial_url = data_with_url
    print('UUUUUUUUUUUUUUUUUUUUUURL', initial_url)
    driver.get(initial_url)

    # Execute all steps from JSON
    for step_number, step_data in steps.items():
        execute_step(step_number, step_data)

    # Close the browser
    driver.quit()

    # Print execution report
    # print(json.dumps(execution_report, indent=4))

    # Return the execution report (for saving or further processing)
    return execution_report

def view_function(request):
    import json
    if request.method == 'GET':
        # Capture all GET parameters (query parameters in URL)
        all_row_data = request.GET.dict()
        data_without_url = {key: value for key, value in all_row_data.items() if key != 'url'}
        data_with_url = all_row_data.get('url', None)
        step_wise_data = group_by_step(data_without_url)
        json_data = json.dumps(step_wise_data, indent=4)
        execution_report = execute_test_from_json(json_data, data_with_url)
        # Pass the data to the template
        return render(request, 'tocop/display_data.html', {'json_data': execution_report})

# Add this function after the existing functions

def requirement(request):
    if request.method == "POST":
        if 'upload_requirements' in request.POST:
            # Handle file upload
            if 'file' in request.FILES:
                file = request.FILES['file']
                file_content = ""
                
                # Process based on file extension
                if file.name.endswith('.json'):
                    try:
                        file_content = json.loads(file.read().decode('utf-8'))
                        requirements_text = parse_json_requirements(file_content)
                    except json.JSONDecodeError:
                        messages.error(request, "Invalid JSON file. Please upload a valid JSON file.")
                        return render(request, 'tocop/requirement.html')
                elif file.name.endswith('.txt'):
                    requirements_text = file.read().decode('utf-8')
                else:
                    messages.error(request, "Unsupported file format. Please upload a JSON or TXT file.")
                    return render(request, 'tocop/requirement.html')
            else:
                # Get requirements from text area
                requirements_text = request.POST.get('requirements_text', '')
                
                if not requirements_text:
                    messages.error(request, "Please provide requirements text or upload a file.")
                    return render(request, 'tocop/requirement.html')
            
            # Create a new requirement in the database
            requirement_title = request.POST.get('requirement_title', 'Requirement ' + time.strftime("%Y%m%d-%H%M%S"))
            project_id = request.POST.get('project_id', None)
            
            # Save the requirement to the database
            from .models import Requirement, TestCase
            new_requirement = Requirement(
                user=request.user if request.user.is_authenticated else None,
                title=requirement_title,
                description=requirements_text,
                project_id=project_id
            )
            new_requirement.save()
            
            # Generate prompt from requirements
            prompt = generate_prompt_from_requirements(requirements_text)
            
            # Call AI model
            try:
                response = configure_AI(prompt)
                
                # Process the response
                raw_text = response.candidates[0].content.parts[0].text

                # Optional: Remove code block markers if present
                if raw_text.startswith("```json"):
                    json_text = raw_text.strip("```json").strip("```").strip()
                else:
                    json_text = raw_text.strip()
                    
                try:
                    response_text = json.loads(json_text)
                    
                    # Save test cases to the database
                    if 'rows' in response_text:
                        for row in response_text['rows']:
                            test_case = TestCase(
                                requirement=new_requirement,
                                test_case_id=row.get('field_1', ''),
                                scenario_name=row.get('field_2', ''),
                                description=row.get('field_3', ''),
                                preconditions=row.get('field_4', ''),
                                test_data=row.get('field_5', ''),
                                test_steps=row.get('field_6', ''),
                                expected_results=row.get('field_7', ''),
                                url=row.get('field_8', '')
                            )
                            test_case.save()
                    
                    context = {
                        'json_data': response_text,
                        'requirement_id': new_requirement.id
                    }
                    messages.success(request, "Test cases generated and saved successfully!")
                    return render(request, 'tocop/requirement.html', context)
                except json.JSONDecodeError as e:
                    messages.error(request, f"Error parsing AI response: {str(e)}")
                    return render(request, 'tocop/requirement.html')
            except Exception as e:
                messages.error(request, f"Error processing requirements: {str(e)}")
                return render(request, 'tocop/requirement.html')
        
        # Handle saving selected test cases
        elif 'save_selected_test_cases' in request.POST:
            selected_test_cases = request.POST.getlist('selected_test_cases')
            requirement_id = request.POST.get('requirement_id')
            
            if not selected_test_cases or not requirement_id:
                messages.error(request, "No test cases selected or requirement ID missing.")
                return redirect('requirement')
            
            # Process selected test cases
            # This would typically involve updating the status or other attributes
            messages.success(request, f"{len(selected_test_cases)} test cases saved successfully!")
            return redirect('requirement')
    
    return render(request, 'tocop/requirement.html')

# Helper functions for requirement view
def parse_json_requirements(json_data):
    """Extract requirements text from JSON data"""
    # This is a simple implementation - adjust based on your JSON structure
    if isinstance(json_data, dict):
        if 'requirements' in json_data:
            return json_data['requirements']
        elif 'description' in json_data:
            return json_data['description']
        elif 'text' in json_data:
            return json_data['text']
    
    # If we can't find a specific field, convert the entire JSON to text
    return json.dumps(json_data, indent=2)

def generate_prompt_from_requirements(requirements_text):
    """Generate a prompt for the AI model based on requirements text"""
    prompt = f"""
    You are an automation assistant. Generate test cases in JSON format based on the following requirements:

    Requirements:
    {requirements_text}

    Please generate a JSON object with the following structure:
    {{
        "rows": [
            {{
                "field_1": "Test Case ID",
                "field_2": "Test Scenario Name",
                "field_3": "Test Case Description",
                "field_4": "Preconditions",
                "field_5": "Test Data",
                "field_6": "Test Steps",
                "field_7": "Test Step Expected Results",
                "field_8": "URL (if applicable)"
            }}
        ]
    }}

    Generate at least 3 test cases covering different aspects of the requirements.
    Make sure the output is valid JSON format.
    """
    return prompt


def requirements_list(request):
    """View to list all requirements"""
    from .models import Requirement
    import sys
    
    # Debug information
    print("\n==== REQUIREMENTS LIST VIEW EXECUTION ====", file=sys.stderr)
    print(f"Request path: {request.path}", file=sys.stderr)
    
    # Get all requirements
    requirements = Requirement.objects.all().order_by('-created_at')
    
    # Debug information
    print(f"Total requirements: {requirements.count()}", file=sys.stderr)
    
    context = {
        'requirements': requirements,
        'debug_info': {
            'requirement_count': requirements.count()
        }
    }
    
    print("Rendering template: tocop/requirements_list.html", file=sys.stderr)
    print("==== END REQUIREMENTS LIST VIEW ====\n", file=sys.stderr)
    return render(request, 'tocop/requirements_list.html', context)


def test_case_list(request):
    """View to list all test cases with filtering by requirement"""
    from .models import TestCase, Requirement
    from django.db import connection
    import sys
    
    # Get filter parameters
    requirement_id = request.GET.get('requirement_id')
    # requirement_id = 1
    # Debug information
    print("\n==== TEST CASE LIST VIEW EXECUTION ====", file=sys.stderr)
    print(f"Request path: {request.path}", file=sys.stderr)
    print(f"Requirement ID filter: {requirement_id}", file=sys.stderr)
    
    # Use direct SQL query to fetch test cases
    test_cases = []
    try:
        with connection.cursor() as cursor:
            if requirement_id:
                print(f"Executing SQL with requirement filter: {requirement_id}", file=sys.stderr)
                cursor.execute(
                    "SELECT id, test_case_id, scenario_name, requirement_id, created_at FROM tocop_testcase WHERE requirement_id = %s ORDER BY created_at DESC",
                    [requirement_id]
                )
            else:
                print("Executing SQL without requirement filter", file=sys.stderr)
                cursor.execute(
                    "SELECT id, test_case_id, scenario_name, requirement_id, created_at FROM tocop_testcase ORDER BY created_at DESC"
                )
            
            # Fetch all rows
            rows = cursor.fetchall()
            print(f"SQL query returned {len(rows)} rows", file=sys.stderr)
            
            # Convert to list of dictionaries
            for row in rows:
                test_cases.append({
                    'id': row[0],
                    'test_case_id': row[1],
                    'scenario_name': row[2],
                    'requirement_id': row[3],
                    'created_at': row[4],
                })
    except Exception as e:
        print(f"SQL ERROR: {str(e)}", file=sys.stderr)
    
    # Get all requirements for the filter dropdown
    requirements = Requirement.objects.all().order_by('title')
    
    # Debug information
    print(f"Total test cases from SQL: {len(test_cases)}", file=sys.stderr)
    print(f"Total requirements: {requirements.count()}", file=sys.stderr)
    print(f"Test cases data: {test_cases}", file=sys.stderr)
    
    context = {
        'test_cases': test_cases,
        'requirements': requirements,
        'selected_requirement': requirement_id,
        'debug_info': {
            'test_case_count': len(test_cases),
            'requirement_count': requirements.count()
        }
    }
    
    print("Rendering template: tocop/test_case_list.html", file=sys.stderr)
    print("==== END TEST CASE LIST VIEW ====\n", file=sys.stderr)
    print('###################################', context)
    return render(request, 'tocop/test_case_list.html', context)


def requirement_edit(request, requirement_id):
    """View to edit a specific requirement"""
    from .models import Requirement
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    requirement = get_object_or_404(Requirement, id=requirement_id)
    
    # Debug information
    print("\n==== REQUIREMENT EDIT VIEW EXECUTION ====", file=sys.stderr)
    print(f"Editing requirement ID: {requirement_id}", file=sys.stderr)
    
    if request.method == 'POST':
        # Update requirement with form data
        requirement.title = request.POST.get('title')
        requirement.description = request.POST.get('description')
        requirement.project_id = request.POST.get('project_id')
        
        requirement.save()
        messages.success(request, "Requirement updated successfully!")
        return redirect('requirements_list')
    
    context = {
        'requirement': requirement
    }
    
    return render(request, 'tocop/requirement_edit.html', context)


def requirement_delete(request, requirement_id):
    """View to delete a specific requirement"""
    from .models import Requirement
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    requirement = get_object_or_404(Requirement, id=requirement_id)
    
    # Debug information
    print("\n==== REQUIREMENT DELETE VIEW EXECUTION ====", file=sys.stderr)
    print(f"Deleting requirement ID: {requirement_id}", file=sys.stderr)
    print(f"Requirement title: {requirement.title}", file=sys.stderr)
    print(f"Associated test cases: {requirement.test_cases.count()}", file=sys.stderr)
    
    if request.method == 'POST':
        # Delete the requirement (this will cascade delete test cases due to the model relationship)
        requirement.delete()
        messages.success(request, f"Requirement '{requirement.title}' and all associated test cases deleted successfully!")
        return redirect('requirements_list')
    
    # If not POST, redirect to requirements list (safety measure)
    return redirect('requirements_list')


def test_case_edit(request, test_case_id):
    """View to edit a specific test case"""
    from .models import TestCase, Requirement
    from django.shortcuts import get_object_or_404, redirect
    
    test_case = get_object_or_404(TestCase, id=test_case_id)
    requirements = Requirement.objects.all().order_by('title')
    
    if request.method == 'POST':
        # Update test case with form data
        test_case.test_case_id = request.POST.get('test_case_id')
        test_case.scenario_name = request.POST.get('scenario_name')
        test_case.description = request.POST.get('description')
        test_case.preconditions = request.POST.get('preconditions')
        test_case.test_data = request.POST.get('test_data')
        test_case.test_steps = request.POST.get('test_steps')
        test_case.expected_results = request.POST.get('expected_results')
        test_case.url = request.POST.get('url')
        
        # Update requirement if changed
        requirement_id = request.POST.get('requirement')
        if requirement_id and int(requirement_id) != test_case.requirement_id:
            test_case.requirement_id = requirement_id
        
        test_case.save()
        messages.success(request, "Test case updated successfully!")
        return redirect('test_case_list')
    
    context = {
        'test_case': test_case,
        'requirements': requirements
    }
    
    return render(request, 'tocop/test_case_edit.html', context)


def automation_list(request):
    """View to list all automation scripts with optional filtering by test case"""
    from .models import Automation, TestCase
    import sys
    
    # Debug information
    print("\n==== AUTOMATION LIST VIEW EXECUTION ====", file=sys.stderr)
    
    # Get filter parameters
    test_case_id = request.GET.get('test_case_id', '')
    status = request.GET.get('status', '')
    
    # Base queryset
    automations_query = Automation.objects.all()
    
    # Apply filters if provided
    if test_case_id:
        automations_query = automations_query.filter(test_case_id=test_case_id)
        print(f"Filtering by test_case_id: {test_case_id}", file=sys.stderr)
    
    if status:
        automations_query = automations_query.filter(status=status)
        print(f"Filtering by status: {status}", file=sys.stderr)
    
    # Get all automations
    automations = automations_query.order_by('-created_at')
    
    # Get all test cases for the filter dropdown
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    # Debug information
    print(f"Total automations: {automations.count()}", file=sys.stderr)
    print(f"Total test cases: {test_cases.count()}", file=sys.stderr)
    
    context = {
        'automations': automations,
        'test_cases': test_cases,
        'selected_test_case': test_case_id,
        'selected_status': status,
        'debug_info': {
            'automation_count': automations.count(),
            'test_case_count': test_cases.count()
        }
    }
    
    print("Rendering template: tocop/automation_list.html", file=sys.stderr)
    return render(request, 'tocop/automation_list.html', context)


def automation_create(request):
    """View to create a new automation script"""
    from .models import Automation, TestCase
    from django.shortcuts import redirect
    import sys
    
    # Debug information
    print("\n==== AUTOMATION CREATE VIEW EXECUTION ====", file=sys.stderr)
    
    # Get all test cases for the dropdown
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    if request.method == 'POST':
        # Create new automation with form data
        automation = Automation(
            test_case_id=request.POST.get('test_case'),
            automation_id=request.POST.get('automation_id'),
            name=request.POST.get('name'),
            script_path=request.POST.get('script_path'),
            language=request.POST.get('language'),
            framework=request.POST.get('framework'),
            status=request.POST.get('status'),
            last_result=request.POST.get('last_result')
        )
        
        automation.save()
        messages.success(request, "Automation script created successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': {},  # Empty dict for new automation
        'test_cases': test_cases
    }
    
    return render(request, 'tocop/automation_edit.html', context)


def automation_edit(request, automation_id):
    """View to edit a specific automation script"""
    from .models import Automation, TestCase
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    automation = get_object_or_404(Automation, id=automation_id)
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    # Debug information
    print("\n==== AUTOMATION EDIT VIEW EXECUTION ====", file=sys.stderr)
    print(f"Editing automation ID: {automation_id}", file=sys.stderr)
    
    if request.method == 'POST':
        # Update automation with form data
        automation.automation_id = request.POST.get('automation_id')
        automation.name = request.POST.get('name')
        automation.script_path = request.POST.get('script_path')
        automation.language = request.POST.get('language')
        automation.framework = request.POST.get('framework')
        automation.status = request.POST.get('status')
        automation.last_result = request.POST.get('last_result')
        
        # Update test case if changed
        test_case_id = request.POST.get('test_case')
        if test_case_id and int(test_case_id) != automation.test_case_id:
            automation.test_case_id = test_case_id
        
        automation.save()
        messages.success(request, "Automation script updated successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': automation,
        'test_cases': test_cases
    }
    
    return render(request, 'tocop/automation_edit.html', context)


def automation_delete(request, automation_id):
    """View to delete a specific automation script"""
    from .models import Automation
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    automation = get_object_or_404(Automation, id=automation_id)
    
    # Debug information
    print("\n==== AUTOMATION DELETE VIEW EXECUTION ====", file=sys.stderr)
    print(f"Deleting automation ID: {automation_id}", file=sys.stderr)
    
    if request.method == 'POST':
        # Delete the automation
        automation.delete()
        messages.success(request, f"Automation script '{automation.name}' deleted successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': automation
    }
    
    return render(request, 'tocop/automation_delete.html', context)


# New function to bulk sync test cases with keywords
def bulk_sync_test_cases(request):
    """Bulk synchronize test cases with KeyWord_1 model and convert to automation test cases sss""" 
    from .models import TestCase, Automation
    from autoai.models import KeyWord_1, Steps_1
    import sys
    
    # Debug information
    print("\n==== BULK SYNC TEST CASES VIEW EXECUTION ====", file=sys.stderr)
    
    # Get all test cases and keywords
    test_cases = TestCase.objects.all()
    keywords = KeyWord_1.objects.all()
    
    # Initialize counters for debug info
    matched_count = 0
    automation_count = 0
    steps_count = 0
    keyword_update_count = 0
    
    if request.method == "POST":
        convert_to_automation = request.POST.get('convert_to_automation') == 'on'
        debug_info = []
        
        # For each test case, try to find a matching keyword
        for test_case in test_cases:
            # Skip test cases that already have automations
            if Automation.objects.filter(test_case=test_case).exists():
                debug_info.append(f"Test case {test_case.id} already has automation, skipping")
                continue
                
            keyword_match = None
            
            # Try to find a keyword that matches this test case
            for keyword in keywords:
                # Try exact match on scenario_name
                if keyword.keyword_Name.lower() in test_case.scenario_name.lower():
                    keyword_match = keyword
                    debug_info.append(f"Found match by scenario_name: Keyword={keyword.keyword_Name}, Test Case={test_case.scenario_name}")
                    break
                
                # Try partial match in description if it exists
                elif test_case.description and keyword.keyword_Name.lower() in test_case.description.lower():
                    keyword_match = keyword
                    debug_info.append(f"Found match by description: Keyword={keyword.keyword_Name}, Test Case={test_case.scenario_name}")
                    break
                
                # Try simple keyword 'test' as fallback for any test case
                elif keyword.keyword_Name.lower() == 'test':
                    keyword_match = keyword
                    debug_info.append(f"Using 'test' keyword as fallback for: Test Case={test_case.scenario_name}")
                    break
            
            # If we found a matching keyword, create an automation
            if keyword_match:
                matched_count += 1
                
                # Create new automation entry
                automation = Automation.objects.create(
                    test_case=test_case,
                    automation_id=f"AUTO-{test_case.test_case_id}",
                    name=f"{keyword_match.keyword_Name} - {test_case.scenario_name}",
                    language="Python",
                    framework="Selenium",
                    status="Not Started"
                )
                automation_count += 1
                debug_info.append(f"Created automation: {automation.name}")
                
                # Add test case entry to keyword_1 table by updating keyword description
                # This creates a relationship between the test case and keyword
                if not keyword_match.keyword_Desc or keyword_match.keyword_Desc.strip() == "":
                    keyword_match.keyword_Desc = f"Test Case: {test_case.test_case_id} - {test_case.scenario_name}"
                else:
                    keyword_match.keyword_Desc += f"\n\nTest Case: {test_case.test_case_id} - {test_case.scenario_name}"
                
                # Add test steps if available
                if test_case.test_steps:
                    keyword_match.keyword_Desc += f"\n\nTest Steps:\n{test_case.test_steps}"
                
                # Save the updated keyword
                keyword_match.save()
                keyword_update_count += 1
                debug_info.append(f"Updated keyword {keyword_match.keyword_Name} with test case information")
                
                # If convert_to_automation is checked, generate steps using AI model
                if convert_to_automation:
                    try:
                        # Generate steps using AI model
                        steps = generate_automation_steps(test_case, keyword_match)
                        
                        # Create Steps_1 entries for the keyword
                        for i, step in enumerate(steps, 1):
                            Steps_1.objects.create(
                                k=keyword_match,
                                object_Name=step.get('object_name', ''),
                                input_Value=step.get('input_value', ''),
                                expected_Value=step.get('expected_value', ''),
                                action=step.get('action', ''),
                                window_Type=step.get('window_type', 'main'),
                                step_Descriptions=f"Step {i}: {step.get('description', '')}"
                            )
                            steps_count += 1
                        
                        debug_info.append(f"Generated {len(steps)} steps for automation {automation.name}")
                    except Exception as e:
                        debug_info.append(f"Error generating steps for {automation.name}: {str(e)}")
        
        # Add debug info to messages
        for info in debug_info:
            messages.info(request, info)
            
        messages.success(request, f"Successfully synced {matched_count} test cases with keywords, created {automation_count} automations, added {keyword_update_count} test cases to keywords, and created {steps_count} steps.")
        return redirect('test_case_list')
    
    # If GET request, show the sync page
    context = {
        'debug_info': {
            'test_case_count': test_cases.count(),
            'keyword_count': keywords.count(),
            'matched_count': 0,
            'keyword_update_count': 0
        }
    }
    return render(request, 'tocop/bulk_sync_test_cases.html', context)

# Function to generate automation steps using AI model
def generate_automation_steps(test_case, keyword):
    """Generate automation steps for a test case using AI model"""
    import json
    import google.generativeai as genai
    from django.conf import settings
    import sys
    
    # Get AI configuration
    try:
        from autoai.models import conf_1
        ai_config = conf_1.objects.first()
        if ai_config and ai_config.g_api_key:
            api_key = ai_config.g_api_key
        else:
            # Use a default API key or raise an error
            api_key = settings.GEMINI_API_KEY if hasattr(settings, 'GEMINI_API_KEY') else None
            
        if not api_key:
            print("No API key found for Gemini", file=sys.stderr)
            return []
            
        # Configure the Gemini API
        genai.configure(api_key=api_key)
    except Exception as e:
        print(f"Error configuring AI: {str(e)}", file=sys.stderr)
        return []
    
    # Create a prompt for the AI model
    prompt = f"""
    You are an automation assistant. Convert the following test case into automation steps that can be used with Selenium WebDriver.
    
    Test Case ID: {test_case.test_case_id}
    Test Scenario Name: {test_case.scenario_name}
    Test Case Description: {test_case.description}
    Preconditions: {test_case.preconditions}
    Test Data: {test_case.test_data}
    Test Steps: {test_case.test_steps}
    Expected Results: {test_case.expected_results}
    URL: {test_case.url if hasattr(test_case, 'url') else ''}
    
    Generate a JSON array of steps with the following structure for each step:
    [
        {{
            "object_name": "CSS or XPath selector for the element",
            "input_value": "Value to input (if applicable)",
            "expected_value": "Expected value or result",
            "action": "click, type, select, verify, etc.",
            "window_type": "main",
            "description": "Description of the step"
        }}
    ]
    
    Make sure to include all necessary steps to complete the test case, including navigation, form filling, validation, etc.
    """

    try:
        # Generate content using Gemini
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(prompt)
        
        # Extract JSON from response
        raw_text = response.text
        
        # Clean up the response to extract valid JSON
        if "```json" in raw_text:
            json_text = raw_text.split("```json")[1].split("```")[0].strip()
        elif "```" in raw_text:
            json_text = raw_text.split("```")[1].strip()
        else:
            json_text = raw_text.strip()
            
        # Parse the JSON
        steps = json.loads(json_text)
        return steps
    except Exception as e:
        print(f"Error generating steps with AI: {str(e)}", file=sys.stderr)
        # Return a basic step structure as fallback
        return [
            {
                "object_name": "body",
                "input_value": "",
                "expected_value": "Page loaded",
                "action": "verify",
                "window_type": "main",
                "description": f"Verify {test_case.scenario_name} page is loaded"
            }
        ]

# New function to generate automation for a specific test case
def generate_automation(request, test_case_id):
    """Generate automation test case using AI for a specific test case"""
    from .models import TestCase, Automation
    from autoai.models import KeyWord_1, Steps_1
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    # Debug information
    print("\n==== GENERATE AUTOMATION VIEW EXECUTION ====", file=sys.stderr)
    print(f"Generating automation for test case ID: {test_case_id}", file=sys.stderr)
    
    # Get the test case
    test_case = get_object_or_404(TestCase, id=test_case_id)
    
    # Check if automation already exists
    existing_automation = Automation.objects.filter(test_case=test_case).first()
    
    # If automation exists, we'll update it instead of creating a new one
    if existing_automation:
        # Get or create a keyword for this test case
        keyword, created = KeyWord_1.objects.get_or_create(
            keyword_Name=test_case.scenario_name[:50],  # Limit to 50 chars
            defaults={
                'keyword_Desc': f"Test Case: {test_case.test_case_id} - {test_case.scenario_name}\n\nDescription: {test_case.description}\n\nTest Steps: {test_case.test_steps}",
            }
        )
        
        # Delete existing steps for this keyword
        Steps_1.objects.filter(k=keyword).delete()
        
        # Generate new steps using AI
        steps = generate_automation_steps(test_case, keyword)
        
        # Create Steps_1 entries for the keyword
        steps_count = 0
        for i, step in enumerate(steps, 1):
            Steps_1.objects.create(
                k=keyword,
                object_Name=step.get('object_name', ''),
                input_Value=step.get('input_value', ''),
                expected_Value=step.get('expected_value', ''),
                action=step.get('action', ''),
                window_Type=step.get('window_type', 'main'),
                step_Descriptions=f"Step {i}: {step.get('description', '')}"
            )
            steps_count += 1
        
        # Update the automation status
        existing_automation.status = "In Progress"
        existing_automation.save()
        
        messages.success(request, f"Updated automation '{existing_automation.name}' with {steps_count} AI-generated steps!")
    else:
        # Create a new keyword for this test case
        keyword = KeyWord_1.objects.create(
            keyword_Name=test_case.scenario_name[:50],  # Limit to 50 chars
            keyword_Desc=f"Test Case: {test_case.test_case_id} - {test_case.scenario_name}\n\nDescription: {test_case.description}\n\nTest Steps: {test_case.test_steps}"
        )
        
        # Create new automation entry
        automation = Automation.objects.create(
            test_case=test_case,
            automation_id=f"AUTO-{test_case.test_case_id}",
            name=f"AI-{test_case.scenario_name}",
            language="Python",
            framework="Selenium",
            status="In Progress"
        )
        
        # Generate steps using AI model
        steps = generate_automation_steps(test_case, keyword)
        
        # Create Steps_1 entries for the keyword
        steps_count = 0
        for i, step in enumerate(steps, 1):
            Steps_1.objects.create(
                k=keyword,
                object_Name=step.get('object_name', ''),
                input_Value=step.get('input_value', ''),
                expected_Value=step.get('expected_value', ''),
                action=step.get('action', ''),
                window_Type=step.get('window_type', 'main'),
                step_Descriptions=f"Step {i}: {step.get('description', '')}"
            )
            steps_count += 1
        
        messages.success(request, f"Created new automation '{automation.name}' with {steps_count} AI-generated steps!")
    
    # Redirect to the keyword detail page to view the generated steps
    return redirect(f"/keyword/{keyword.id}/")
    URL: {test_case.url}
    
    Generate a JSON array of steps with the following structure for each step:
    [
        {{
            "object_name": "CSS or XPath selector for the element",
            "input_value": "Value to input (if applicable)",
            "expected_value": "Expected value or result",
            "action": "click, type, select, verify, etc.",
            "window_type": "main",
            "description": "Description of the step"
        }}
    ]
    
    Make sure to include all necessary steps to complete the test case, including navigation, form filling, validation, etc.
    The output should be valid JSON format with no additional text.
    """
    
    try:
        # Generate content using Gemini
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(prompt)
        
        # Extract JSON from response
        raw_text = response.text
        
        # Clean up the response to extract valid JSON
        if "```json" in raw_text:
            json_text = raw_text.split("```json")[1].split("```")[0].strip()
        elif "```" in raw_text:
            json_text = raw_text.split("```")[1].strip()
        else:
            json_text = raw_text.strip()
            
        # Parse the JSON
        steps = json.loads(json_text)
        return steps
    except Exception as e:
        print(f"Error generating steps with AI: {str(e)}", file=sys.stderr)
        # Return a basic step structure as fallback
        return [
            {
                "object_name": "body",
                "input_value": "",
                "expected_value": "Page loaded",
                "action": "verify",
                "window_type": "main",
                "description": f"Verify {test_case.scenario_name} page is loaded"
            }
        ]


# New function to sync Automation with KeyWord_1
def sync_automation_with_keyword(request):
    """Synchronize Automation model with KeyWord_1 model"""
    if request.method == "POST":
        # Get all keywords from autoai
        keywords = KeyWord_1.objects.all()
        sync_count = 0
        debug_info = []
        
        # Get all test cases that don't have automations yet
        test_cases_without_automation = []
        for test_case in TestCase.objects.all():
            if not Automation.objects.filter(test_case=test_case).exists():
                test_cases_without_automation.append(test_case)
                debug_info.append(f"Test case without automation: ID={test_case.id}, Name={test_case.scenario_name}")
        
        debug_info.append(f"Found {len(test_cases_without_automation)} test cases without automation")
        debug_info.append(f"Found {keywords.count()} keywords total")
        
        # For each test case without automation, try to find a matching keyword
        # This is the reverse of our previous approach
        for test_case in test_cases_without_automation:
            keyword_match = None
            
            # Try to find a keyword that matches this test case
            for keyword in keywords:
                # Try exact match on scenario_name
                if keyword.keyword_Name.lower() in test_case.scenario_name.lower():
                    keyword_match = keyword
                    debug_info.append(f"Found match by scenario_name: Keyword={keyword.keyword_Name}, Test Case={test_case.scenario_name}")
                    break
                
                # Try partial match in description if it exists
                elif test_case.description and keyword.keyword_Name.lower() in test_case.description.lower():
                    keyword_match = keyword
                    debug_info.append(f"Found match by description: Keyword={keyword.keyword_Name}, Test Case={test_case.scenario_name}")
                    break
                
                # Try simple keyword 'test' as fallback for any test case
                elif keyword.keyword_Name.lower() == 'test':
                    keyword_match = keyword
                    debug_info.append(f"Using 'test' keyword as fallback for: Test Case={test_case.scenario_name}")
                    break
            
            # If we found a matching keyword, create an automation
            if keyword_match:
                # Create new automation entry
                automation = Automation.objects.create(
                    test_case=test_case,
                    automation_id=f"AUTO-{test_case.test_case_id}",
                    name=f"{keyword_match.keyword_Name} - {test_case.scenario_name}",
                    language="Python",
                    framework="Selenium",
                    status="Not Started"
                )
                sync_count += 1
                debug_info.append(f"Created automation: {automation.name}")

        # Add debug info to messages
        for info in debug_info:
            messages.info(request, info)
            
        messages.success(request, f"Successfully synced {sync_count} automations with keywords.")
        return redirect('automation_list')
    
    # If GET request, show the sync page
    return render(request, 'tocop/sync_automation.html')


def requirements_list(request):
    """View to list all requirements"""
    from .models import Requirement
    import sys
    
    # Debug information
    print("\n==== REQUIREMENTS LIST VIEW EXECUTION ====", file=sys.stderr)
    print(f"Request path: {request.path}", file=sys.stderr)
    
    # Get all requirements
    requirements = Requirement.objects.all().order_by('-created_at')
    
    # Debug information
    print(f"Total requirements: {requirements.count()}", file=sys.stderr)
    
    context = {
        'requirements': requirements,
        'debug_info': {
            'requirement_count': requirements.count()
        }
    }
    
    print("Rendering template: tocop/requirements_list.html", file=sys.stderr)
    print("==== END REQUIREMENTS LIST VIEW ====\n", file=sys.stderr)
    return render(request, 'tocop/requirements_list.html', context)


def test_case_list(request):
    """View to list all test cases with filtering by requirement"""
    from .models import TestCase, Requirement
    from django.db import connection
    import sys
    
    # Get filter parameters
    requirement_id = request.GET.get('requirement_id')
    # requirement_id = 1
    # Debug information
    print("\n==== TEST CASE LIST VIEW EXECUTION ====", file=sys.stderr)
    print(f"Request path: {request.path}", file=sys.stderr)
    print(f"Requirement ID filter: {requirement_id}", file=sys.stderr)
    
    # Use direct SQL query to fetch test cases
    test_cases = []
    try:
        with connection.cursor() as cursor:
            if requirement_id:
                print(f"Executing SQL with requirement filter: {requirement_id}", file=sys.stderr)
                cursor.execute(
                    "SELECT id, test_case_id, scenario_name, requirement_id, created_at FROM tocop_testcase WHERE requirement_id = %s ORDER BY created_at DESC",
                    [requirement_id]
                )
            else:
                print("Executing SQL without requirement filter", file=sys.stderr)
                cursor.execute(
                    "SELECT id, test_case_id, scenario_name, requirement_id, created_at FROM tocop_testcase ORDER BY created_at DESC"
                )
            
            # Fetch all rows
            rows = cursor.fetchall()
            print(f"SQL query returned {len(rows)} rows", file=sys.stderr)
            
            # Convert to list of dictionaries
            for row in rows:
                test_cases.append({
                    'id': row[0],
                    'test_case_id': row[1],
                    'scenario_name': row[2],
                    'requirement_id': row[3],
                    'created_at': row[4],
                })
    except Exception as e:
        print(f"SQL ERROR: {str(e)}", file=sys.stderr)
    
    # Get all requirements for the filter dropdown
    requirements = Requirement.objects.all().order_by('title')
    
    # Debug information
    print(f"Total test cases from SQL: {len(test_cases)}", file=sys.stderr)
    print(f"Total requirements: {requirements.count()}", file=sys.stderr)
    print(f"Test cases data: {test_cases}", file=sys.stderr)
    
    context = {
        'test_cases': test_cases,
        'requirements': requirements,
        'selected_requirement': requirement_id,
        'debug_info': {
            'test_case_count': len(test_cases),
            'requirement_count': requirements.count()
        }
    }
    
    print("Rendering template: tocop/test_case_list.html", file=sys.stderr)
    print("==== END TEST CASE LIST VIEW ====\n", file=sys.stderr)
    print('###################################', context)
    return render(request, 'tocop/test_case_list.html', context)


def requirement_edit(request, requirement_id):
    """View to edit a specific requirement"""
    from .models import Requirement
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    requirement = get_object_or_404(Requirement, id=requirement_id)
    
    # Debug information
    print("\n==== REQUIREMENT EDIT VIEW EXECUTION ====", file=sys.stderr)
    print(f"Editing requirement ID: {requirement_id}", file=sys.stderr)
    
    if request.method == 'POST':
        # Update requirement with form data
        requirement.title = request.POST.get('title')
        requirement.description = request.POST.get('description')
        requirement.project_id = request.POST.get('project_id')
        
        requirement.save()
        messages.success(request, "Requirement updated successfully!")
        return redirect('requirements_list')
    
    context = {
        'requirement': requirement
    }
    
    return render(request, 'tocop/requirement_edit.html', context)


def requirement_delete(request, requirement_id):
    """View to delete a specific requirement"""
    from .models import Requirement
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    requirement = get_object_or_404(Requirement, id=requirement_id)
    
    # Debug information
    print("\n==== REQUIREMENT DELETE VIEW EXECUTION ====", file=sys.stderr)
    print(f"Deleting requirement ID: {requirement_id}", file=sys.stderr)
    print(f"Requirement title: {requirement.title}", file=sys.stderr)
    print(f"Associated test cases: {requirement.test_cases.count()}", file=sys.stderr)
    
    if request.method == 'POST':
        # Delete the requirement (this will cascade delete test cases due to the model relationship)
        requirement.delete()
        messages.success(request, f"Requirement '{requirement.title}' and all associated test cases deleted successfully!")
        return redirect('requirements_list')
    
    # If not POST, redirect to requirements list (safety measure)
    return redirect('requirements_list')


def test_case_edit(request, test_case_id):
    """View to edit a specific test case"""
    from .models import TestCase, Requirement
    from django.shortcuts import get_object_or_404, redirect
    
    test_case = get_object_or_404(TestCase, id=test_case_id)
    requirements = Requirement.objects.all().order_by('title')
    
    if request.method == 'POST':
        # Update test case with form data
        test_case.test_case_id = request.POST.get('test_case_id')
        test_case.scenario_name = request.POST.get('scenario_name')
        test_case.description = request.POST.get('description')
        test_case.preconditions = request.POST.get('preconditions')
        test_case.test_data = request.POST.get('test_data')
        test_case.test_steps = request.POST.get('test_steps')
        test_case.expected_results = request.POST.get('expected_results')
        test_case.url = request.POST.get('url')
        
        # Update requirement if changed
        requirement_id = request.POST.get('requirement')
        if requirement_id and int(requirement_id) != test_case.requirement_id:
            test_case.requirement_id = requirement_id
        
        test_case.save()
        messages.success(request, "Test case updated successfully!")
        return redirect('test_case_list')
    
    context = {
        'test_case': test_case,
        'requirements': requirements
    }
    
    return render(request, 'tocop/test_case_edit.html', context)


def automation_list(request):
    """View to list all automation scripts with optional filtering by test case"""
    from .models import Automation, TestCase
    import sys
    
    # Debug information
    print("\n==== AUTOMATION LIST VIEW EXECUTION ====", file=sys.stderr)
    
    # Get filter parameters
    test_case_id = request.GET.get('test_case_id', '')
    status = request.GET.get('status', '')
    
    # Base queryset
    automations_query = Automation.objects.all()
    
    # Apply filters if provided
    if test_case_id:
        automations_query = automations_query.filter(test_case_id=test_case_id)
        print(f"Filtering by test_case_id: {test_case_id}", file=sys.stderr)
    
    if status:
        automations_query = automations_query.filter(status=status)
        print(f"Filtering by status: {status}", file=sys.stderr)
    
    # Get all automations
    automations = automations_query.order_by('-created_at')
    
    # Get all test cases for the filter dropdown
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    # Debug information
    print(f"Total automations: {automations.count()}", file=sys.stderr)
    print(f"Total test cases: {test_cases.count()}", file=sys.stderr)
    
    context = {
        'automations': automations,
        'test_cases': test_cases,
        'selected_test_case': test_case_id,
        'selected_status': status,
        'debug_info': {
            'automation_count': automations.count(),
            'test_case_count': test_cases.count()
        }
    }
    
    print("Rendering template: tocop/automation_list.html", file=sys.stderr)
    return render(request, 'tocop/automation_list.html', context)


def automation_create(request):
    """View to create a new automation script"""
    from .models import Automation, TestCase
    from django.shortcuts import redirect
    import sys
    
    # Debug information
    print("\n==== AUTOMATION CREATE VIEW EXECUTION ====", file=sys.stderr)
    
    # Get all test cases for the dropdown
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    if request.method == 'POST':
        # Create new automation with form data
        automation = Automation(
            test_case_id=request.POST.get('test_case'),
            automation_id=request.POST.get('automation_id'),
            name=request.POST.get('name'),
            script_path=request.POST.get('script_path'),
            language=request.POST.get('language'),
            framework=request.POST.get('framework'),
            status=request.POST.get('status'),
            last_result=request.POST.get('last_result')
        )
        
        automation.save()
        messages.success(request, "Automation script created successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': {},  # Empty dict for new automation
        'test_cases': test_cases
    }
    
    return render(request, 'tocop/automation_edit.html', context)


def automation_edit(request, automation_id):
    """View to edit a specific automation script"""
    from .models import Automation, TestCase
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    automation = get_object_or_404(Automation, id=automation_id)
    test_cases = TestCase.objects.all().order_by('test_case_id')
    
    # Debug information
    print("\n==== AUTOMATION EDIT VIEW EXECUTION ====", file=sys.stderr)
    print(f"Editing automation ID: {automation_id}", file=sys.stderr)
    
    if request.method == 'POST':
        # Update automation with form data
        automation.automation_id = request.POST.get('automation_id')
        automation.name = request.POST.get('name')
        automation.script_path = request.POST.get('script_path')
        automation.language = request.POST.get('language')
        automation.framework = request.POST.get('framework')
        automation.status = request.POST.get('status')
        automation.last_result = request.POST.get('last_result')
        
        # Update test case if changed
        test_case_id = request.POST.get('test_case')
        if test_case_id and int(test_case_id) != automation.test_case_id:
            automation.test_case_id = test_case_id
        
        automation.save()
        messages.success(request, "Automation script updated successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': automation,
        'test_cases': test_cases
    }
    
    return render(request, 'tocop/automation_edit.html', context)


def automation_delete(request, automation_id):
    """View to delete a specific automation script"""
    from .models import Automation
    from django.shortcuts import get_object_or_404, redirect
    import sys
    
    automation = get_object_or_404(Automation, id=automation_id)
    
    # Debug information
    print("\n==== AUTOMATION DELETE VIEW EXECUTION ====", file=sys.stderr)
    print(f"Deleting automation ID: {automation_id}", file=sys.stderr)
    
    if request.method == 'POST':
        # Delete the automation
        automation.delete()
        messages.success(request, f"Automation script '{automation.name}' deleted successfully!")
        return redirect('automation_list')
    
    context = {
        'automation': automation
    }
    
    return render(request, 'tocop/automation_delete.html', context)
