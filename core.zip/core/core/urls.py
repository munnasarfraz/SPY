"""
URL configuration for core project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from home.views import *
from vege.views import *
from django.conf.urls.static import static
from django.conf import settings
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

 #Custom 404 error view
handler404 = 'vege.views.error_404' 
# Custom 500 error view
handler500 = 'vege.views.error_500'


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name ='home'),
    path("about/", about, name="about"),
    path("contact/", contact, name="contact"),
    path("recepies/", recepies, name="recepies"),
    path("delete-recepi/<id>/", delete_recepi, name='delete_recepi'),
    path("update-recepi/<id>/", update_recepi, name='update_recepi'),
    
    path('login/', login_page, name='login_page'),
    path('logout/', logout_page, name='logout_page'),
    path('register/', register, name='register'),
    path('profile/<id>/', profile_update, name='profile_update'),
    path('conf/<id>/', conf, name='conf'),
    
    path('suite/', suite, name='suite'),
    path("delete-suite/<id>/", delete_suite, name='delete_suite'),
    path("update-suite/<id>/", update_suite, name='update_suite'),
    
    path('execution/', execution, name='execution'),
    
    path('keyword/<id>/', keyword, name='keyword'),
    # path("keyword/<id>/", keyword1, name='keyword1'),
    path("delete-keyword/<id>/<kid>/", delete_keyword, name='delete_keyword'),
    path("update-keyword/<id>/<kid>/", update_keyword, name='update_keyword'),
    path('kwd/', kwd, name='list_keyword'),
    path('updatekwd/<id>/', updatekwd, name='updatekwd'),
    path('deletekwd/<id>/', deletekwd, name='updatekwd'),
    
    
    
    path('batch/', batch, name='batch'),
    path("delete-batch/<id>/", delete_batch, name='delete_batch'),
    path("update-batch/<id>/", update_batch, name='update_batch'),
    
    path('project/', project, name='project'),
    path("delete-project/<id>/", delete_project, name='delete_project'),
    path("update-project/<id>/", update_project, name='update_project'),
    path("intermediate/", intermediate, name='intermediate'),
    path("report/", report, name='report'),
    path("report_steps/<id>/", report_steps, name='report_steps'),
    path("job/", add_job, name='add_job'),
    path("jobs/", show_jobs, name='show_jobs'),
    path("data-param/<id>/", data_param, name='data_param'),
    path("update_dataparam/<id>/<kid>/", update_dataparam, name='update_dataparam'),
    path("delete-dataparam/<id>/<kid>/", delete_dataparam, name='delete_dataparam'),
    
    
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    
urlpatterns += staticfiles_urlpatterns()

