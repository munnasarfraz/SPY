from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from vege.models import *
# from django.shortcuts import render_to_response
import random
import datetime
import time

# Create your views here.


people = [
    {'name' : 'sarfraz', 'age' : 40},
    {'name' : 'Munna', 'age' : 25},
    {'name' : 'Ahmad', 'age' : 25},
    {'name' : 'Maryam', 'age' : 11},
    {'name' : 'Zeba', 'age' : 97}
    
]


# def demo_piechart(request):
#     """
#     pieChart page
#     """
#     xdata = ["Apple", "Apricot", "Avocado", "Banana", "Boysenberries", "Blueberries", "Dates", "Grapefruit", "Kiwi", "Lemon"]
#     ydata = [52, 48, 160, 94, 75, 71, 490, 82, 46, 17]

#     extra_serie = {"tooltip": {"y_start": "", "y_end": " cal"}}
#     chartdata = {'x': xdata, 'y1': ydata, 'extra1': extra_serie}
#     charttype = "pieChart"

#     data = {
#         'charttype': charttype,
#         'chartdata': chartdata,
#     }
#     return render_to_response('home/index.html', data)

# def index(request):
#   magma_composition_data = [
#     {"label":"Oxygen","symbol":"O","y":46.6},
#     {"label":"Silicon","symbol":"Si","y":27.7},
#     {"label":"Aluminium","symbol":"Al","y":13.9},
#     {"label":"Iron","symbol":"Fe","y":5},
#     {"label":"Calcium","symbol":"Ca","y":3.6},
#     {"label":"Sodium","symbol":"Na","y":2.6},
#     {"label":"Magnesium","symbol":"Mg","y":2.1},
#     {"label":"Others","symbol":"Others","y":1.5}
#   ]
 
#   return render(request, 'index.html', { "magma_composition_data" : magma_composition_data }) 

@login_required(login_url='/login/')
def home(request):

    qSet_1 = Report_1.objects.filter(user_id=request.session['user_id'])

    qSet_2 = KeyWord_1.objects.filter(u_id=request.session['user_id'])

    
    scounter = {'c_execution' : qSet_1.count(), 'c_development' : qSet_2.count(), 'defect' : qSet_2.count()}  
    context = {"scounter":scounter}
    
    print('XXXXXXXX', context)
    return render(request, 'home/index.html', context)
    
    #return render(request, 'home/index.html', context={"page":scounter,'people':people})

def about(request):
    context = {"page":'About Us'}
    return render(request, 'home/about.html', context)

def contact(request):
    context = {"page":'Contact Us'}
    return render(request, 'home/contact.html', context)