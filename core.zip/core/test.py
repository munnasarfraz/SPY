import google.generativeai as genai

genai.configure(api_key="AIzaSyBlZiVSB8vRJ-uz_k53aNC4r3Go8BjY0Mg")
model = genai.GenerativeModel("gemini-1.5-flash")
response = model.generate_content("writa a para on cricket")
print(response.text)