from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Receipe_1(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null = True, blank=True)
    receipe_name = models.CharField(max_length=100)
    receipe_desciption = models.TextField()
    receipe_image = models.ImageField(upload_to="receipe")

class conf_1(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null = True, blank=True)
    browser_type = models.CharField(max_length=50, blank=True, null=True)
    speed = models.CharField(max_length=50, blank=True, null=True)
    waittime = models.CharField(max_length=50, blank=True, null=True)
    retry = models.CharField(max_length=50, blank=True, null=True)
    llm = models.CharField(max_length=100, blank=True, null=True)
    g_api_key = models.CharField(max_length=500, blank=True, null=True)
    project_id = models.IntegerField(blank=True, null=True)
    

class Project_1(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    project = models.CharField(max_length=100,blank=True, null=True)
    project_Type = models.CharField(max_length=100,blank=True, null=True)
    url = models.CharField(max_length=100,blank=True, null=True)
    active = models.BooleanField(True, False, default = True)
    email_Flag = models.BooleanField(True, False, default = True)
    email_IDs = models.CharField(max_length=100,blank=True, null=True)
    start_maximized = models.BooleanField(True, False, default=True)
    disable_extensions = models.BooleanField(True, False, default=False)
    ignore_certificate_errors = models.BooleanField(True, False, default=False)
    disable_popup_blocking = models.BooleanField(True, False, default=False)
    incognito = models.BooleanField(True, False, default=False)
    headless  = models.BooleanField(True, False, default=False)
    

class KeyWord_1(models.Model):
    keyword_Name = models.CharField(max_length=100,blank=True, null=True)
    keyword_Desc = models.TextField(blank=True, null=True)
    u = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    p = models.ForeignKey(Project_1, on_delete=models.SET_NULL, null=True, blank=True)

class Steps_1(models.Model):
    k = models.ForeignKey(KeyWord_1, on_delete=models.SET_NULL, null = True, blank=True)
    object_Name = models.CharField(max_length=100,blank=True, null=True)
    input_Value = models.CharField(max_length=100,blank=True, null=True)
    expected_Value = models.CharField(max_length=100,blank=True, null=True)
    action = models.CharField(max_length=100,blank=True, null=True)
    window_Type = models.CharField(max_length=100,blank=True, null=True)
    step_Descriptions = models.CharField(max_length=100,blank=True, null=True)
    
class MainBatch_1(models.Model):
    main_BatchName = models.CharField(max_length=100,blank=True, null=True)
    keyword_Data = models.CharField(max_length=100,blank=True, null=True)
    iteration_CountForSameData = models.CharField(max_length=100,blank=True, null=True)
    iteration_CountForDifferentData = models.CharField(max_length=100,blank=True, null=True)
    project_id = models.CharField(max_length=100,blank=True, null=True)
    isSkip = models.BooleanField(True, False)
    readOnly = models.BooleanField(True, False)
    remarks = models.CharField(max_length=200,blank=True, null=True)
  
class Suite_1(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null = True, blank=True)
    project_id = models.IntegerField(blank=True, null=True)
    suite_name = models.CharField(max_length=50,blank=True, null=True)
    suite_description = models.CharField(max_length=200,blank=True, null=True)
    execute = models.CharField(max_length=200,blank=True, null=True)
    priority = models.CharField(max_length=200,blank=True, null=True)
    language = models.CharField(max_length=200,blank=True, null=True)
    module = models.CharField(max_length=100,blank=True, null=True)
    build = models.CharField(max_length=100,blank=True, null=True)
    test_cycle = models.CharField(max_length=100,blank=True, null=True)
    test_env = models.CharField(max_length=100,blank=True, null=True)
    impact = models.CharField(max_length=100,blank=True, null=True)
    main_BatchName_id = models.CharField(max_length=100,blank=True, null=True)
    schedule_time = models.CharField(max_length=100,blank=True, null=True)
    remarks = models.CharField(max_length=100,blank=True, null=True)
    machine_name = models.CharField(max_length=100,blank=True, null=True)
    
class MyAppUser( models.Model ) :
    def __unicode__( self ) :
       return self.user.username

    user    = models.ForeignKey( User, on_delete=models.CASCADE )
    organization = models.TextField( blank = True )
    location = models.CharField( max_length = 150, blank = True ) 
    phone   = models.CharField( max_length = 135, blank = True )
    birth   = models.CharField( max_length = 50, blank = True )
    role = models.CharField( max_length = 135, blank = True )
    image = models.CharField( max_length = 135, blank = True )
    gender = models.CharField(max_length=50,blank=True, null=True)
    
class Report_1( models.Model ) :
    user    = models.ForeignKey( User, on_delete=models.CASCADE )
    project_id = models.IntegerField(blank=True, null=True)
    tcs_Name = models.CharField( max_length = 50, blank = True ) 
    status = models.BooleanField(True, False, default = True)
    test_Env = models.CharField( max_length = 100, blank = True )  
    time = models.DateTimeField(auto_now_add=True, blank=True)
    run_by = models.CharField( max_length = 100, blank = True )  
        
class Report_Steps_1( models.Model ) :
    r  = models.ForeignKey( Report_1, on_delete=models.CASCADE )
    project_id = models.IntegerField(blank=True, null=True)
    status = models.BooleanField(True, False, default = True)
    step_Description = models.CharField( max_length = 200, blank = True )
    actual_Value = models.CharField( max_length = 100, blank = True )  
    expected_Value = models.CharField( max_length = 100, blank = True )  
    time = models.DateTimeField(auto_now_add=True, blank=True)

class Lab_1( models.Model ) :
    user    = models.ForeignKey( User, on_delete=models.CASCADE )
    project_id = models.IntegerField(blank=True, null=True)
    job_name = models.CharField( max_length = 50, blank = True ) 
    job_id = models.CharField( max_length = 50, blank = True ) 
    datetime = models.DateTimeField(auto_now_add=True, blank=True)
    priority = models.CharField(max_length=200,blank=True, null=True)
    impact = models.CharField(max_length=200,blank=True, null=True)
    suits = models.CharField(max_length=200,blank=True, null=True)
    execution = models.CharField(max_length=200,blank=True, null=True)
    executiondate = models.DateTimeField(auto_now_add=True, blank=True)
    
class Data_Param_1( models.Model ) :
    k = models.ForeignKey(KeyWord_1, on_delete=models.SET_NULL, null = True, blank=True)
    var_Name = models.CharField(max_length=100,blank=True, null=True)
    var_Value = models.CharField(max_length=100,blank=True, null=True)
    var_AI = models.CharField(max_length=100,blank=True, null=True)
    ai_Prompt = models.TextField()
    llm_Model = models.CharField(max_length=100,blank=True, null=True)