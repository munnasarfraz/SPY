from django.shortcuts import render, redirect

from .models import *
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, PageNotAnInteger

import time
from selenium.common.exceptions import NoSuchElementException
from django.utils.timezone import now

from django.test import LiveServerTestCase
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.options import Options
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from django.shortcuts import render 
from django.http import JsonResponse 
import openai 

# import google.generativeai as genai
import os

openai.api_key = 'sk-proj-M6YBwAMxYni0RgRCjYhLT3BlbkFJC7zJl9B0RYRvrN5E9HLh'

from threading import Thread

# Create your views here.
@login_required(login_url='/login/')
def keyword(request, id):
    print("request.method :", request.method)
    if request.method == "POST":
        data = request.POST
        object_Name = data.get('ObjectName')
        input_Value = data.get('InputValue')
        action = data.get('Action') 
        expected_Value = data.get('ExpectedValue')
        window_Type = data.get('WindowType')
        step_Descriptions = data.get('StepDescription')
        
        hidIndex = data.get('hidIndex')
        print('hidIndex-->', hidIndex)
        Steps_1.objects.create(
            object_Name = object_Name,
            input_Value = input_Value,
            action = action,
            expected_Value = expected_Value,
            window_Type = window_Type,
            step_Descriptions = step_Descriptions,
            k_id = id
            # project_id = request.session['project_id'],
            # user_id = request.session['user_id'],
            # name = request.session['component_name']
        )
        messages.success(request, "TCs rows added successfullt")
        return redirect('/keyword/'+id+'/')
    #context = {"page":'Add Recepi'}
    # print(request.session['component_name'])
    queryset = Steps_1.objects.filter(k_id=id)
    queryset1 = KeyWord_1.objects.get(id = id)
    #print(queryset1.query)
    # if request.session['component_name']!=None:
    #     queryset = KeyWord_1.objects.filter(name=request.session['component_name'])
    #     #print(queryset.query)
    # else:
    #     queryset = KeyWord_1.objects.all()
        
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    
    
    # if request.GET.get("Search"):
    #     print(request.GET.get("Search"))
    #     queryset = queryset.filter(receipe_name__icontains = request.GET.get("Search")) 


    context = {'keywords':queryset, 'component':queryset1}
    return render(request, 'keyword.html', context)

def keyword1(request, id):
    print("request.method :", request.method)
    #print(request.session['component_name'])
    queryset = Steps_1.objects.filter(k_id=id)
    
                
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    context = {'keywords':queryset, 'kwd_id':id}
    return render(request, 'keyword.html', context)


def delete_keyword(request, id, kid):
    queryset = Steps_1.objects.get(id=id)
    queryset.delete()
    #return HttpResponse("a")
    messages.error(request, "TCs rows deleted successfullt")
    return redirect('/keyword/'+kid+'/')

def update_keyword(request, id, kid):
    print(id)
    queryset = Steps_1.objects.get(id = id)
    queryset1 = KeyWord_1.objects.get(id = kid)
    #print(queryset.query)
    if request.method == "POST":
        data = request.POST
        
        object_Name = data.get('ObjectName')
        input_Value = data.get('InputValue')
        action = data.get('Action') 
        expected_Value = data.get('ExpectedValue')
        window_Type = data.get('WindowType')
        step_Descriptions = data.get('StepDescription')
        hidIndex = data.get('hidIndex')
                
        queryset.object_Name = object_Name
        queryset.input_Value = input_Value
        queryset.action = action
        queryset.window_Type = window_Type
        queryset.expected_Value = expected_Value
        queryset.step_Descriptions = step_Descriptions
                
        queryset.save()
        messages.success(request, "TCs rows updated successfullt")
        return redirect('/keyword/'+kid+'/')
    #if queryset.action.count
    
    context = {'keywords':queryset, 'component':queryset1}
    return render(request, 'keyword.html', context )

def batch(request):
    if request.method == "POST":
        data = request.POST
        mainBatchName = data.get('MainBatchName')
        batchData = request.POST.get('keywords')
        iterationSameData = data.get('IterationSameData')
        iterationDiffrentData = data.get('IterationDiffrentData') 
        skip = data.get('Skip')
        if skip==None:
            skip = 0
        else:
            skip = 1
        readOnly = data.get('ReadOnly')
        if readOnly==None:
            readOnly = 0
        else:
            readOnly = 1
        
        batchData.strip('[]').split(',')
        
        print('XXXXX=', batchData)
        batchData = batchData.replace('::::', ',')
        batchData = batchData.replace('::', '')
        print('XXXXX=', batchData)
    
        if iterationSameData==None or iterationSameData=='':
            iterationSameData = 0
        if iterationDiffrentData==None or iterationDiffrentData =='':
            iterationDiffrentData = 0
                
        MainBatch_1.objects.create(
            main_BatchName = mainBatchName,
            iteration_CountForSameData = iterationSameData,
            iteration_CountForDifferentData = iterationDiffrentData,
            isSkip = skip,
            readOnly = readOnly,
            keyword_Data = batchData,
            project_id = request.session['project_id']
        )
        messages.success(request, "main batch saved successfully")
        return redirect('/batch/')
    
    queryset = MainBatch_1.objects.filter(project_id=request.session['project_id'])
    #queryset1 = KeyWord_1.objects.filter(project_id=request.session['project_id'])
    queryset1 = KeyWord_1.objects.filter(p_id=request.session['project_id'], u_id=request.session['user_id'])
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    context = {'batch': queryset, 'kwd':queryset1}
    return render(request, 'mainbatch.html', context)


def delete_batch(request, id):
    queryset = MainBatch_1.objects.get(id = id)
    queryset.delete()
    #return HttpResponse("a")
    messages.error(request, "main batch deleted successfully")
    return redirect('/batch/')

def update_batch(request, id):
    queryset = MainBatch_1.objects.get(id = id)
    
    if request.method == "POST":
        data = request.POST
        mainBatchName = data.get('MainBatchName')
        iterationSameData = data.get('IterationSameData')
        iterationDiffrentData = data.get('IterationDiffrentData') 
        skip = data.get('Skip')
        if skip==None:
            skip = False
        else:
            skip = True
        print("SKIP=====", skip)
        readOnly = data.get('ReadOnly')
        if readOnly==None:
            readOnly = False
        else:
            readOnly = True
        print("READ ONLY=====", readOnly)
        batchData = data.get('BatchData')
        
        print("batchData -->", batchData)
        
        if iterationSameData==None or iterationSameData=='':
            iterationSameData = 0
        if iterationDiffrentData==None or iterationDiffrentData =='':
            iterationDiffrentData = 0
          
        queryset.main_BatchName = mainBatchName
        queryset.iteration_CountForSameData = iterationSameData
        queryset.iteration_CountForDifferentData = iterationDiffrentData
        queryset.isSkip = skip
        queryset.readOnly = readOnly
        queryset.keyword_Data = batchData
        queryset.project_id = request.session['project_id']
        #print("Session ===== ", queryset.query)
               
        queryset.save()
        messages.success(request, "main batch updated successfully")
        return redirect('/batch/')
    #if queryset.action.count
    queryset1 = KeyWord_1.objects.filter(p_id=request.session['project_id'], u_id=request.session['user_id'])
    context = {'batch':queryset, 'kwd':queryset1}
    return render(request, 'updatebatch.html', context )


@login_required(login_url='/login/')
def recepies(request):
    if request.method == "POST":
        data = request.POST
        
        receipe_image = request.FILES.get('receipe_image')
        receipe_name = data.get('receipe_name') 
        receipe_desciption = data.get('receipe_desciption')
        print(receipe_name)
        print(receipe_desciption)
        print(receipe_image)
        
        Receipe_1.objects.create(
            receipe_image= receipe_image,
            receipe_name= receipe_name,
            receipe_desciption= receipe_desciption,
        )
        
        return redirect('/recepies/')
    #context = {"page":'Add Recepi'}
    
    queryset = Receipe_1.objects.all()
    
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 2)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    
    # for Search ###################################################
    if request.GET.get("Search"):
        print(request.GET.get("Search"))
        queryset = queryset.filter(receipe_name__icontains = request.GET.get("Search")) 
    # for Search ###################################################

    context = {'recepies': queryset}
    return render(request, 'recepies.html', context)

def delete_recepi(request, id):
    print(id)
    queryset = Receipe_1.objects.get(id = id)
    queryset.delete()
    #return HttpResponse("a")
    return redirect('/recepies/')
    
def update_recepi(request, id):
    queryset = Receipe_1.objects.get(id = id)
    
    if request.method == "POST":
        data = request.POST
        
        receipe_image = request.FILES.get('receipe_image')
        receipe_name = data.get('receipe_name') 
        receipe_desciption = data.get('receipe_desciption')
                
        queryset.receipe_name = receipe_name
        queryset.receipe_desciption = receipe_desciption
        
        if receipe_image:
            queryset.receipe_image = receipe_image
        
        queryset.save()
        return redirect('/recepies/')
           
    context = {'recepie':queryset}
    return render(request, 'update_recepies.html', context )

def login_page(request):
    if request.method=="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        xpassword = password
        print('Xpassword', xpassword)
        print(username, password)
        user = User.objects.filter(username = username)
        if not user.exists():
            print('Not Exist')
            messages.error(request, "username "+username+" not exist")
            return redirect('/login/')  
        user = authenticate(username = username, password=password)
        print('USER___', user)
        if user == None:
            messages.error(request, "Invalid password for user : "+username)
            pass
        else:
            
            queryset = Project_1.objects.filter(user_id=user.id)
            print('___D', queryset.count())
            if queryset.count()==0:
                request.session['user_id'] = user.id
                login(request, user)
                return redirect('/intermediate/')  
            else:
                value = request.POST.get('project_id') 
                print("__A")
                if value == None:
                    print("__B")
                    messages.success(request, "select domain to proceed login")
                    login(request, user)
                else:
                    login(request, user)
                    print("__C")
                    #request.session['project_id'] = value
                    request.session['project_id'] = value
                    request.session['user_id'] = user.id
                    return redirect('/')  
                    
                
            #request.session['username'] = username
            #return redirect('/login/')  
            
            #print(request.session['project_id'])
            context = {'query':queryset, 'xpwd':xpassword}
            return render(request, 'login.html', context )
        
            #return redirect('/')
    #return render(request, 'login_frm.html')
    return render(request, 'login.html')

def logout_page(request):
    try:
        logout(request)
        if request.session:
            request.session.clear()
    except:
        pass
    return redirect('/login/')
    

def register(request):
    if request.method=="POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        
        user = User.objects.filter(username = username)
        if user.exists():
            messages.error(request, "user name "+username+" allready taken")
            return redirect('/register/')    
        
        user = User.objects.create(
            first_name = first_name,
            last_name = last_name,
            username = username,
            email = email
            )
        user.set_password(password)
        user.save()
        print('XVVVVVV_', user.pk)
        
        MyAppUser.objects.create(
            user_id = user.pk
        )
        messages.error(request, "User saved !")
        return redirect('/register/')
        
    return render(request, 'register_frm.html')

def profile_update(request, id):
    queryset = User.objects.get(id = id) 
    queryset_1 = MyAppUser.objects.get(user_id = id)
    if request.method=="POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
           
        queryset.first_name = first_name
        queryset.last_name = last_name
        queryset.save()
        
        organization = request.POST.get('OrgName')
        location = request.POST.get('Location')
        phone = request.POST.get('Phone')
        birth = request.POST.get('Birth')
        role = request.POST.get('role')
        gender = request.POST.get('gender')
        
        queryset_1.organization = organization
        queryset_1.location = location
        queryset_1.phone = phone
        queryset_1.birth = birth
        queryset_1.role = role
        queryset_1.gender = gender
        queryset_1.save()
               
        messages.error(request, "Profile Updated successfully !")
        return redirect('/profile/'+id+'/')
       
    
    context = {'users_1':queryset, 'appusers_1':queryset_1}
    return render(request, 'profile.html', context )
    
def conf(request, id):
    #queryset = userConfig.objects.get(id = id)
    if request.method=="POST":
        browser_type = request.POST.get("browser_type")
        speed = request.POST.get("speed")
        waittime = request.POST.get("waittime")
        retry = request.POST.get("retry")
        llm = request.POST.get("llm")
        g_api_key = request.POST.get("g_api_key")
        
        hiddentext = request.POST.get('hiddentext')
    
        if speed is None:
            speed = "off"
              
        
        
        try:
            queryset = conf_1.objects.get(id = id)
            queryset.browser_type = browser_type
            queryset.speed = speed
            queryset.waittime = waittime
            queryset.retry = retry
            queryset.llm = llm
            queryset.g_api_key = g_api_key
            queryset.user_id = int(id)
            queryset.project_id = int(request.session['project_id'])
            queryset.save()
            messages.error(request, "Configuration Updated !")
            return redirect('/conf/'+id+'/')
        except conf_1.DoesNotExist:
            print('XXXXXX=', request.session['project_id'])
            conf_1.objects.create(
                browser_type = browser_type,
                speed = speed,
                waittime = waittime,
                retry = retry,
                llm = llm,
                g_api_key = g_api_key,
                user_id = int(id),
                project_id = int(request.session['project_id'])
                )
            messages.success(request, "Configuration saved !")
            return redirect('/conf/'+id+'/')

    queryset = conf_1.objects.filter(id = id)
    if not queryset:
        context = {'conf':""}        
    else:
        context = {'conf':queryset}
    #print(queryset.query)
# else:
#         context = {'conf_1':""}
    return render(request, 'config.html', context )



def project(request):
    if request.method == "POST":
        data = request.POST
        project = data.get('project')
        project_Type = data.get('project_Type')
        url = data.get('url')
        active = data.get('active') 
        email_Flag = data.get('email_Flag')
        email_IDs = data.get('email_IDs')
        
        disable_extensions = data.get('disable_extensions')
        start_maximized = data.get('start_maximized')
        ignore_certificate_errors = data.get('ignore_certificate_errors')
        disable_popup_blocking = data.get('disable_popup_blocking')
        incognito = data.get('incognito')
        headless = data.get('headless')
        
        if disable_extensions == 'on': disable_extensions = True
        if disable_extensions == None: disable_extensions = False
            
        if start_maximized == 'on': start_maximized = True
        if start_maximized == None: start_maximized = False
              
        if ignore_certificate_errors == 'on': ignore_certificate_errors = True
        if ignore_certificate_errors == None: ignore_certificate_errors = False
        
        if disable_popup_blocking == 'on': disable_popup_blocking = True
        if disable_popup_blocking == None: disable_popup_blocking = False
        
        if incognito == 'on': incognito = True
        if incognito == None: incognito = False
        
        if headless == 'on': headless = True
        if headless == None: headless = False
        
                
        if active == None:
            active = 0
        else:
            active = 1
            
        if email_Flag == None:
            email_Flag = 0
        else:
            email_Flag = 1
            
        Project_1.objects.create(
            project = project,
            project_Type = project_Type,
            url = url,
            active = active,
            email_Flag = email_Flag,
            email_IDs = email_IDs,
            start_maximized = start_maximized,
            disable_extensions = disable_extensions ,           
            ignore_certificate_errors = ignore_certificate_errors,
            disable_popup_blocking = disable_popup_blocking,
            incognito = incognito,
            headless = headless,
            user_id = request.session['user_id']
        )
        print('YYYY-', Project_1.id)
        #request.session['project_id'] = 1
        #print('PROJ--', request.session['project_id'])

        messages.success(request, "Domain : "+ project +" added successfully")
        return redirect('/project/')
    
    queryset = Project_1.objects.filter(user_id=request.session['user_id'])
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 5)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    context = {'project': queryset}
    return render(request, 'project.html', context)

def delete_project(request, id):
    queryset = Project_1.objects.filter(id = id)
    queryset.delete()
    messages.error(request, "Domain deleted successfully")
    #return HttpResponse("a")
    return redirect('/project/')

def update_project(request, id):
    queryset = Project_1.objects.get(id = id)
    if request.method == "POST":
        data = request.POST
        project = data.get('project')
        project_Type = data.get('project_Type')
        url = data.get('url')
        active = data.get('active')
        email_Flag = data.get('email_Flag') 
        email_IDs = data.get('email_IDs')
        disable_extensions = data.get('disable_extensions')
        start_maximized = data.get('start_maximized')
        ignore_certificate_errors = data.get('ignore_certificate_errors')
        disable_popup_blocking = data.get('disable_popup_blocking')
        incognito = data.get('incognito')
        headless = data.get('headless')
        print('###########-',start_maximized)
        if active == None:
            active = 0
        else:
            active = 1
            
        if email_Flag == None:
            email_Flag = 0
        else:
            email_Flag = 1
            
        if disable_extensions == 'on': disable_extensions = True
        if disable_extensions == None: disable_extensions = False
        if start_maximized == 'on': start_maximized = True
        if start_maximized == None: start_maximized = False
        if ignore_certificate_errors == 'on': ignore_certificate_errors = True
        if ignore_certificate_errors == None: ignore_certificate_errors = False
        if disable_popup_blocking == 'on': disable_popup_blocking = True
        if disable_popup_blocking == None: disable_popup_blocking = False
        if incognito == 'on': incognito = True
        if incognito == None: incognito = False
        if headless == 'on': headless = True
        if headless == None: headless = False
              
        queryset.project = project
        queryset.project_Type = project_Type
        queryset.url = url
        queryset.active = active
        queryset.email_Flag = email_Flag 
        queryset.email_IDs = email_IDs
        queryset.start_maximized = start_maximized
        queryset.disable_extensions = disable_extensions          
        queryset.ignore_certificate_errors = ignore_certificate_errors
        queryset.disable_popup_blocking = disable_popup_blocking
        queryset.incognito = incognito
        queryset.headless = headless
        queryset.user_id = request.session['user_id']
        
        queryset.save()
        messages.success(request, "Domain : "+ project +" updated successfully")
        return redirect('/project/')
    context = {'project':queryset}
    return render(request, 'project.html', context )

def suite(request):
    if request.method == "POST":
        data = request.POST
        
        suite_value =  data.getlist('suite_value')
        if suite_value != []:
            print('suite_value---', suite_value)
            pid = request.session['project_id']
            customfunction(request, pid, suite_value)
        else:      
            suite_name = data.get('suite_name')
            main_BatchName_id = data.get('main_BatchName_id')
            module = data.get('module')
            test_cycle = data.get('test_cycle')
            build = data.get('build')
            priority = data.get('priority')
            impact = data.get('impact')
            Suite_1.objects.create(
                suite_name = suite_name,
                main_BatchName_id = main_BatchName_id,
                module = module,
                test_cycle = test_cycle,
                build = build,
                priority = priority,
                impact = impact,
                project_id = request.session['project_id']
                # user_id = request.session['project_id']
            )
            messages.success(request, "suite added successfully")
        return redirect('/suite/')
    
    queryset = Suite_1.objects.filter(project_id=request.session['project_id'])
    #queryset1 = MainBatch_1.objects.filter(project_id=request.session['project_id'])
    queryset1 = MainBatch_1.objects.filter(project_id=request.session['project_id'])
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)

    context = {'suite':queryset, 'batch':queryset1}
    #context = {'batch':queryset1}
    print(context)
    return render(request, 'suite.html', context)


def delete_suite(request, id):
    queryset = Suite_1.objects.get(id = id)
    queryset.delete()
    messages.error(request, "suite deleted successfully")
    #return HttpResponse("a")
    return redirect('/suite/')

def update_suite(request, id):
    queryset = Suite_1.objects.get(id = id)
    
    #print('$$$$$$', queryset.count())
    if request.method == "POST":
        data = request.POST
        suite_name = data.get('suite_name')
        main_BatchName_id = data.get('main_BatchName_id')
        module = data.get('module')
        test_cycle = data.get('test_cycle')
        build = data.get('build')
        priority = data.get('priority')
        impact = data.get('impact')
        
        queryset.suite_name = suite_name
        queryset.main_BatchName_id = main_BatchName_id
        queryset.module = module
        queryset.test_cycle = test_cycle
        queryset.build = build
        queryset.priority = priority
        queryset.impact = impact
        queryset.project_id = request.session['project_id']
        queryset.save()
        messages.success(request, "suite updated successfully")
        return redirect('/suite/')
    #if queryset.action.count
    context = {'suite':queryset}
    return render(request, 'updatesuite.html', context )


def execution(request):
    request.session['fav_color'] = 'blue'
    fav_color = request.session['fav_color']
    
    print('XXXXXXX_1', fav_color)
    # from django.test import LiveServerTestCase
    # from selenium import webdriver
    # from selenium.webdriver.common.keys import Keys
    # import time
    # import selenium
    # print("sample test case started")  
    # driver = webdriver.Chrome()  
    # driver.maximize_window()  
    # #navigate to the url  
    # driver.get("http://127.0.0.1:8000/")  
   
    # #elm = driver.find_element("name", "q")
    # time.sleep(2)
    # elm = driver.find_element("xpath", "//*[@id='exampleInputEmail1']")
    # highlight(elm)
    # elm.send_keys("munna")
    # time.sleep(2)
    # elm1 = driver.find_element("xpath", "//*[@id='exampleInputPassword1']")
    # highlight(elm1)
    # elm1.send_keys("Maryam@7712")
    # time.sleep(2)
    # elm2 = driver.find_element("xpath", "/html/body/div/form/button")
    # highlight(elm2)
    # time.sleep(2)
    # elm2.click()
    # elm.send_keys(Keys.TAB)
    # elm.send_keys(Keys.ENTER)
    # elm.click()
    # time.sleep(2)
    # elm3 = driver.find_element("xpath", "//*[@id='navbarSupportedContent']/form/a[2]")
    # highlight(elm3)
    # time.sleep(2)
    # elm3.click()
    
    #submit.send_keys(Keys.RETURN)
   
    return render(request, 'execution.html') 
    
def highlight(element):
    import time
    """Highlights (blinks) a Selenium Webdriver element"""
    driver = element._parent
    def apply_style(s):
        driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", element, s)
    original_style = element.get_attribute('style')
    apply_style("border: 2px solid red;")
    time.sleep(.3)
    apply_style(original_style)
    
def kwd(request):
    if request.method == "POST":
        component_Name = request.POST.get('ComponentName')
        Component_Desc = request.POST.get('ComponentDesc')
        
        component = KeyWord_1.objects.filter(keyword_Name = component_Name)
        if component.exists():
            messages.error(request, component_Name + ": Component already exist")
            return redirect('/kwd/') 
        else:
             KeyWord_1.objects.create(
                p_id = request.session['project_id'],
                u_id = request.session['user_id'],
                keyword_Name = component_Name,
                keyword_Desc = Component_Desc
             )
             messages.success(request, "component : " + component_Name + " added successfully")
        return redirect('/kwd/')
        
    queryset = KeyWord_1.objects.filter(p_id = request.session['project_id'],u_id = request.session['user_id'])
    #queryset = KeyWord_1.objects.all()
    print(queryset.query)
    
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    context = {'kwd': queryset}
    return render(request, 'kwd.html', context)

def updatekwd(request, id):
    queryset = KeyWord_1.objects.get(id = id)
    if request.method == "POST":
        data = request.POST
        queryset.keyword_Name = data.get('ComponentName')
        queryset.keyword_Desc = request.POST.get('ComponentDesc')
        queryset.save()
        messages.success(request, "component : " + data.get('ComponentName') + " updated successfully")
        return redirect('/kwd/')
    context = {'kwd':queryset}
    return render(request, 'updatekwd.html', context )

def deletekwd(request, id):
    queryset = KeyWord_1.objects.get(id = id)
    queryset.delete()
    print('-Deleted')
    messages.error(request, "component : " + queryset.keyword_Name + " deleted successfully")
    return redirect('/kwd/')

def customfunction(request, pid, suite_value):
    from django.test import LiveServerTestCase
    from selenium import webdriver
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.chrome.options import Options
    
    
    oProject = Project_1.objects.get(id=pid)
    s_url = oProject.url
    s_start_maximized = oProject.start_maximized
    s_disable_extensions = oProject.disable_extensions
    s_disable_popup_blocking = oProject.disable_popup_blocking
    s_ignore_certificate_errors = oProject.ignore_certificate_errors
    s_incognito = oProject.incognito
    s_headless = oProject.headless
        
    chrome_options = Options()
    if s_start_maximized:
        chrome_options.add_argument("--start-maximized")
    if s_disable_extensions:   
        chrome_options.add_argument("--disable-extensions")
    if s_disable_popup_blocking:
        chrome_options.add_argument("--disable-popup-blocking")
    if s_ignore_certificate_errors:
        chrome_options.add_argument("--ignore-certificate-errors")
    if s_incognito:
        chrome_options.add_argument("--incognito")
    if s_headless:
        chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        driver.get(str(s_url))
    except:
        print("An exception occurred")
    #Suite_1.objects.bulk_create()
    
   
    
    # lSuite = suite_value.replace("'", "")
    # lSuite = lSuite.strip('[]').replace('"', '').replace(' ', '').split(',')
    # print('lSuite-', lSuite)
    # for i in lSuite:
    #     print('XXXXXX-',i)
    for oSuite in suite_value:
        print('########oSuite-->', oSuite)
        obj_Suite = Suite_1.objects.get(id=oSuite, project_id=request.session['project_id'])
        obj_MainBatch = MainBatch_1.objects.get(id=obj_Suite.main_BatchName_id, project_id=request.session['project_id'])
       # print('---> obj_MainBatch', obj_MainBatch.main_BatchName)
        obj_Keyword = KeyWord_1.objects.filter(p_id = request.session['project_id'])
        #obj_Steps = Steps_1.objects.filter(k_id=id)
        oMainBatch_Id = obj_Suite.main_BatchName_id
        oSuiteName = obj_Suite.suite_name
        oKeywordId = obj_MainBatch.keyword_Data
        
        rep_1 = Report_1.objects.create(
            project_id=request.session['project_id'],
            tcs_Name = oSuiteName,
            status = True,
            test_Env = '',
            time = now,
            user_id = request.session['user_id'],
            run_by = request.user   
            )
        
        L1 = oKeywordId.replace("'", "")
        oKeywordList = L1.strip('[]').replace('"', '').replace(' ', '').split(',')
        #print('L1 ******- ', L1)
        #L2 = []
        try:
            for oList in oKeywordList:
                #print('$$$$$$----', oList)
                oSteps = Steps_1.objects.filter(k_id=int(oList))
                for oStep in oSteps:
                    # print('#######----', oStep.action)
                    fun_PageSync(driver, oStep)
                    if(oStep.action == "SetText"):
                        oStatus = fun_Settext(request, driver, oStep, rep_1.pk)
                        print('oStatus-', oStatus)
                        if not oStatus:
                            raise StopIteration
                    elif(oStep.action == "ButtonClick"):
                        oStatus = fun_Buttonclick(request, driver, oStep, rep_1.pk)
                        if not oStatus:
                            obj = Report_1.objects.get(id=rep_1.pk)
                            obj.status = False
                            obj.save()
                            #raise StopIteration
                    elif(oStep.action=="VerifyNonEditableText"):
                        oStatus = fun_VerifyNonEditableText(request, driver, oStep, rep_1.pk)
                        if not oStatus:
                            obj = Report_1.objects.get(id=rep_1.pk)
                            obj.status = False
                            obj.save()
                            #raise StopIteration
                    elif(oStep.action == "SelectListItem"):
                        oStatus = fun_SelectListItem(request, driver, oStep, rep_1.pk)
                        # if not oStatus:
                        #     raise StopIteration
                    
        except StopIteration:
            pass
                            
                
    
    # for oSuite in obj_Suite:
    #     print('*** Suite Id/Name - - ', oSuite.main_BatchName_id +'/'+oSuite.suite_name)
    #     for oMain in obj_MainBatch:
    #         print('*** Main name/Data - - ', oMain.main_BatchName +'/'+oMain.keyword_Data)
            

    
    
    # oMainBatch = obj_MainBatch.filter(id=obj_Suite.main_BatchName_id)
    # oKeyword = obj_Keyword.filter(id=oMainBatch.keyword_Data)
    # for oKey in oKeyword:
    #     print(oKey)
        
    
   
    # queryset = Project_1.objects.filter(id=pid)
    # s_url = queryset[0].url
    # print('EXEC-:'+s_url)
    # driver = webdriver.Chrome()  
    # driver.maximize_window()  
    
    # chrome_options = Options()
    # chrome_options.add_argument("--disable-extensions")
    # chrome_options.add_argument("--start-maximized")
    # chrome_options.add_argument("--ignore-certificate-errors")
    # chrome_options.add_argument("--disable-popup-blocking")
    # chrome_options.add_argument("--incognito")
    
    # driver = webdriver.Chrome(options=chrome_options)
    # try:
    #     driver.get(str(s_url))
    # except:
    #     print("An exception occurred")
    # #navigate to the url  
    # # driver.get('http://google.com')
    # Steps_1.objects.filter()
    # time.sleep(5)
    # elm = driver.find_element("name", "q")
    # time.sleep(2)
    # highlight(elm)
    # elm.send_keys("Munna Sarfraz")
    # time.sleep(2)
    # elm.send_keys(Keys.RETURN)
    
    return redirect('/suite/')
def fun_PageSync(driver, oStep):
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import TimeoutException
    from selenium.webdriver.common.by import By
    delay = 10 # seconds
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, oStep.object_Name)))
        #print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
        
def fun_Object_Identify(driver, oStep):
    try:
        oElm = driver.find_element("name", oStep.object_Name)
    except NoSuchElementException:
        try:
            oElm = driver.find_element("id", oStep.object_Name)
        except NoSuchElementException:
            try:
                oElm = driver.find_element("xpath", oStep.object_Name)
            except NoSuchElementException:
                #print("No element found. Breaking...")
                oElm = None
    except: 
       # print("Generic error message.")
        oElm = None
        
    return oElm

def is_enclosed_by_angle_brackets(s):
    return s.startswith('<') and s.endswith('>')

def remove_angle_brackets(tmp_input_value):
    if tmp_input_value.startswith('<') and tmp_input_value.endswith('>'):
        return tmp_input_value[1:-1]
    return tmp_input_value



def fun_Settext(request, driver, oStep, rid):
    oStatus = False
    oElement = fun_Object_Identify(driver, oStep)
    print('********** KID', oStep.k_id)
    print('********** request.session[is_AI]', request.session['is_AI'])
    if request.session['is_AI'] =="1":
        input_value = prompt_engineering_services(request, oStep)
    else:
        input_value = oStep.input_Value
        
        
    try:
        time.sleep(2)
        highlight(oElement)
        oElement.send_keys(input_value.strip())
        oStatus = True
    except NoSuchElementException:
            #print("No element found. Breaking...")
            oStatus = False
    # except:
    #     oStatus = False
    except Exception as e: print(e)
    
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], actual_Value=input_value, expected_Value=oStep.expected_Value, step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    return oStatus   

def prompt_engineering_services(request, oStep):
    return_Value = ""
    print('########## TEXT ', oStep.input_Value)
    print('########## is Text', is_enclosed_by_angle_brackets(oStep.input_Value))
    if is_enclosed_by_angle_brackets(oStep.input_Value):
        oDataParam = Data_Param_1.objects.get(k_id = oStep.k_id, var_Name = oStep.input_Value)
        if request.session['is_AI'] =="1":
            print('########## Project Id', int(request.session['project_id']))
            oConfig = get_Config(request, int(request.session['project_id']))
            print('########## API Key', oConfig[5])
            #print('########## LLM', oConfig[4])
            print(oStep.k_id)
            print(oStep.input_Value)
            
            print('########## LLM', oConfig[4])
            print('########## PROMPT', oDataParam.ai_Prompt)
            try:
                # genai.configure(api_key=oConfig[5])
                # model = genai.GenerativeModel(oConfig[4])
                # response = model.generate_content(oDataParam.ai_Prompt)
                # print('############# AI Response',response.text)  
                pass 
            except Exception as e: print(e)
            return_Value = response.text
        if request.session['is_AI'] =="0":
            return_Value = oDataParam.var_Value
            
    else:
        return_Value = oStep.input_Value   
    
    return return_Value


def fun_SelectListItem(request, driver, oStep, rid):
    oStatus = False
    oElement = fun_Object_Identify(driver, oStep)
    try:
        time.sleep(1)
        highlight(oElement)
        select = Select(oElement)
        select.select_by_visible_text(oStep.input_Value)
        oStatus = True
    except NoSuchElementException:
            #print("No element found. Breaking...")
            oStatus = False
    except:
        oStatus = False
        
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], actual_Value=oStep.input_Value, expected_Value=oStep.expected_Value, step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    return oStatus    
        
def fun_VerifyNonEditableText(request, driver, oStep, rid):
    oStatus = False
    oElement = fun_Object_Identify(driver, oStep)
    oActualValue = ""
    time.sleep(5)
    try:
        time.sleep(2)
        highlight(oElement)
        oActualValue = oElement.text
        print('ACTUALVALUE:',oActualValue)
        print('EXPECTEDVALUE:',oStep.expected_Value)
        if oStep.expected_Value == oActualValue: 
            print('TRUEEEEE')
            oStatus = True
        else:
            oStatus = False
            print('FALSEEEEE')
    except NoSuchElementException:
            #print("No element found. Breaking...")
            #print('NO ELM EXCEPTIONNNNNNNN')
            oStatus = False
    except:
        oStatus = False
        #print('EXCEPTIONNNNNNNN')
        
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], actual_Value=oStep.input_Value, expected_Value=oStep.expected_Value, step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    return oStatus    


def fun_Buttonclick(request, driver, oStep, rid):
    oStatus = False
    oElement = fun_Object_Identify(driver, oStep)
    if oElement:
        print('oElement - ', oElement)
    else:
        print('oElement - ', 'Not found')
    
    
    try:
        highlight(oElement)
        time.sleep(2)
        oElement.click()
        #time.sleep(7)
    
        oStatus = True
    except NoSuchElementException:
            print("No element found. Breaking...")
            oStatus = False
            pass
    except Exception as e: print(e)
    # except:
    #     oStatus = False
    #     pass
    #     print('XXXXXXXXXX-Fail')
    
    Report_Steps_1.objects.create(
        project_id=request.session['project_id'], step_Description=oStep.step_Descriptions, status=oStatus, r_id=rid, time=now
    )
    print('RETURN STATUS - ', oStatus)
    return oStatus  



def intermediate(request ):
    #context = {'sarfraz': "sarfraz"}
    return render(request, 'intermediate.html')
        
    
  
def report(request):
    # if request.method == "POST":
    #     data = request.POST
        
    #     suite_value =  data.getlist('suite_value')
    #     if suite_value != []:
    #         pid = request.session['project_id']
    #         customfunction(request, pid, suite_value)
    #     else:      
    #         suite_name = data.get('suite_name')
    #         main_BatchName_id = data.get('main_BatchName_id')
    #         module = data.get('module')
    #         test_cycle = data.get('test_cycle')
    #         build = data.get('build')
    #         priority = data.get('priority')
    #         impact = data.get('impact')
    #         Suite_1.objects.create(
    #             suite_name = suite_name,
    #             main_BatchName_id = main_BatchName_id,
    #             module = module,
    #             test_cycle = test_cycle,
    #             build = build,
    #             priority = priority,
    #             impact = impact,
    #             project_id = request.session['project_id']
    #             # user_id = request.session['project_id']
    #         )
    #         messages.success(request, "suite added successfully")
    #     return redirect('/suite/')
    
    queryset = Report_1.objects.filter(project_id=request.session['project_id']).order_by('-time')
    
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 14)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)

    context = {'report':queryset}
    return render(request, 'report.html', context)

def report_steps(request, id):
    # queryset = Report_1.objects.get(id=id, project_id=request.session['project_id'])
    queryset = Report_1.objects.get(id=id)
    queryset1 = Report_Steps_1.objects.filter(r_id=id, project_id=request.session['project_id']).order_by('id')
    page = request.GET.get('page',1)
    paginator = Paginator(queryset1, 100)
    try:
        queryset1 = paginator.page(page)
    except PageNotAnInteger:
        queryset1 = paginator.page(1)
    except EmptyPage:
        queryset1 = paginator.page(paginator.num_pages)
    
    context = {'report':queryset, 'report_steps':queryset1}
    return render(request, 'report_steps.html', context)


def add_job(request):
    queryset = Suite_1.objects.filter(project_id=request.session['project_id'])    
    
    if request.method == "POST":
        data = request.POST
        sValue = data.get('suites')
        sValue = sValue.replace('::::', ',')
        sValue = sValue.replace('::', '')
        print(sValue)
        job_name = data.get('jobname')
        job_id = data.get('jobid')
        datetime = data.get('datetime')
        priority = data.get('priority')
        impact = data.get('impact')
        
        job = Lab_1.objects.filter(job_name = job_name)
        print('ooooooo-', job)
        if job.exists():
            messages.error(request, "Job "+job_name+" allready exists")
            return redirect('/job/') 
        
        Lab_1.objects.create(
            job_name = job_name,
            job_id = job_id,
            datetime = datetime,
            priority = priority,
            impact = impact,
            suits = sValue,
            project_id = request.session['project_id'],
			user_id = request.session['user_id']
        )
        messages.success(request, "Job  : " + job_name + " created successfully")
        # queryset.keyword_Name = data.get('suites')
        # queryset.keyword_Desc = request.POST.get('ComponentDesc')
        # queryset.save()
         
        # return redirect('/kwd/')
    context = {'Suite':queryset}
    return render(request, 'lab.html', context)

def get_Config(request, id):
    print('********** id', id)  
    oConf = conf_1.objects.get(project_id=id)
    s_browser_type = oConf.browser_type
    s_Speed = oConf.speed
    s_Waittime = oConf.waittime
    s_Retry = oConf.retry
    s_llm = oConf.llm
    s_api_key = oConf.g_api_key
    
    tmpList = (s_browser_type , s_Speed, s_Waittime, s_Retry, s_llm, s_api_key)
    print('********** Tupple', tuple(tmpList))
    print('********** Browser', tuple(tmpList)[0])
    return tuple(tmpList)

def redirect_page(request):
    response = redirect('/jobs/')
    return response

def show_jobs(request):
    
    if request.method == "POST":
        data = request.POST
        
        suite_value =  data.getlist('suite_value')
        is_AI =  data.get('isAI')
        print('CCCCCCCCCCCCCC', is_AI)
        
        request.session['is_AI'] = is_AI
        
        # suite_value =  data.get('suite_value')
        print('#############', suite_value)
        pid = request.session['project_id']
        
        try:
            if suite_value != []: 
                # executionThread = Thread(target=runjob, args=(request, pid, suite_value))
                # executionThread.start()
                
                runjob(request, pid, suite_value)
                print('Thread Started')
                
                return redirect('/jobs/')
            
        
        except:
            pass
            print('Print Exception')
    queryset = Lab_1.objects.filter(project_id=request.session['project_id']).order_by('-datetime')
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 12)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
        
    context = {'job':queryset}
    return render(request, 'jobs.html', context)


def error_404(request, exception):
    return render(request, 'home/error_404.html', status=404)
 
def error_500(request):
    return render(request, 'home/error_505.html', status=500)


def invoke_Browser(request, pid):
    try:
        print('********** Inkoke Browser',pid)
        oProject = Project_1.objects.get(id=pid)
        s_url = oProject.url
        s_start_maximized = oProject.start_maximized
        s_disable_extensions = oProject.disable_extensions
        s_disable_popup_blocking = oProject.disable_popup_blocking
        s_ignore_certificate_errors = oProject.ignore_certificate_errors
        s_incognito = oProject.incognito
        s_headless = oProject.headless
        print('********** Headless',s_headless)
        print('********** pid',pid)
        pid
        
        browser_type = get_Config(request, pid)
        print('**********Final tupple', browser_type)
        print('**********Browser_Name', browser_type[0])
                
        if browser_type[0] == "Chrome":
            print('********** Chrome')
            chrome_options = Options()
            if s_start_maximized:
                print('XXXXXXXXXXXXXXX- MAX')
                chrome_options.add_argument("--start-maximized")
            if s_disable_extensions:   
                chrome_options.add_argument("--disable-extensions")
            if s_disable_popup_blocking:
                chrome_options.add_argument("--disable-popup-blocking")
            if s_ignore_certificate_errors:
                chrome_options.add_argument("--ignore-certificate-errors")
            if s_incognito:
                chrome_options.add_argument("--incognito")
            if s_headless:
                chrome_options.add_argument("--headless")
            # chrome_options.add_argument("--log-level=1") 
            # chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
        elif browser_type[0] == "Edge":
            print('********** Edge')
            edge_options = Options()
            if s_start_maximized:
                
                edge_options.add_argument("--start-maximized")
            if s_disable_extensions:   
                edge_options.add_argument("--disable-extensions")
            if s_disable_popup_blocking:
                edge_options.add_argument("--disable-popup-blocking")
            if s_ignore_certificate_errors:
                edge_options.add_argument("--ignore-certificate-errors")
            if s_incognito:
                edge_options.add_argument("--incognito")
            if s_headless:
                edge_options.add_argument("--headless")
            
        try:
            #service chd_Path = "C:\\Users\\munna\\Recipe_Project\\core\home\\static\\img\\driverPath\\chromedriver.exe"
            #browser_type = get_Config(request, pid)
             
            driver = ""
            # service = ChromeService(executable_path=ChromeDriverManager().install()) 
            # driver = webdriver.Chrome(service=service)
            if browser_type[0] == "Chrome":
                
                #driver = webdriver.Chrome(service=Service(executable_path=r"C:\Users\munna\Recipe_Project\core\home\static\img\driverPath\chromedriver.exe", options=chrome_options))
                driver = webdriver.Chrome(service=Service(executable_path=(ChromeDriverManager().install()), options=chrome_options))
            elif browser_type[0] == "Edge":
                driver = webdriver.Edge(options=edge_options)
        except Exception as e: print(e)
        
        try:
            driver.get(str(s_url))
            WebDriverWait(driver, 100).until(lambda driver: driver.execute_script('return document.readyState') == 'complete')
            driver.implicitly_wait(1)
        except:
            print("An exception occurred in invoke browser")
        #print('********** Driver Set', driver)    
        return driver
    except:
        pass

def close_Browser(request, driver):
    driver.close()
    return True

def runjob(request, pid, jobs_value):
    try:
        for oJobid in jobs_value:
            job_suite = Lab_1.objects.get(id=oJobid, project_id=request.session['project_id'])
            job_suite.execution = "In-Progress"
            job_suite.save()
            #(execution=["In-Progress"]) 
            suite_name = job_suite.suits.strip()
            print('**********Suite Name ', suite_name)
                       
            # for oSuite in suite_value:
            print('**********oSuite-->', job_suite.suits.strip())
            
            #xx = job_suite.suits.strip()
            #xx ="test_suite#4"
            xx = job_suite.suits.split()
            yx = ""
            for ix in xx:
                jx = ix.split('#')
                print('JX', jx)
                yx = yx + jx[1] + ","
                
            suite_ids = yx[:-1]
            print('********** suite id ', suite_ids)
            lst_suite_ids = suite_ids.split(',')
            
            for oSuiteId in lst_suite_ids:
                print('**********Suite ids loop - Suite id', oSuiteId)
                obj_Suite = Suite_1.objects.get(id=oSuiteId, project_id=request.session['project_id'])
                
                obj_MainBatch = MainBatch_1.objects.get(id=obj_Suite.main_BatchName_id, project_id=request.session['project_id'])
            # print('---> obj_MainBatch', obj_MainBatch.main_BatchName)
                
                oSuiteName = obj_Suite.suite_name
                
                x = obj_MainBatch.keyword_Data.split()
                y = ""
                for i in x:
                    j = i.split('#')
                    y = y + j[1] + ","

                
                
                oKeywordId = y[:-1]
                
                print('********** oKeywordId', oKeywordId)
                
                rep_1 = Report_1.objects.create(
                    project_id=request.session['project_id'],
                    tcs_Name = oSuiteName,
                    status = True,
                    test_Env = '',
                    time = now,
                    user_id = request.session['user_id'],
                    run_by = request.user   
                    )
                
                L1 = oKeywordId.replace("'", "")
                print('********** L1', L1)
                oKeywordList = L1.strip('[]').replace('"', '').replace(' ', '').split(',')
                print('********** oKeywordList', oKeywordList)
                #print('L1 ******- ', L1)
                #L2 = []
                # try:
                
                #redirect_page(request)
                print('********** Pid', pid)
                driver = invoke_Browser(request, pid)
                print('********** Driver Set', driver)   
                
                for oList in oKeywordList:
                    print('********** olist', oList)
                    oSteps = Steps_1.objects.filter(k_id=int(oList))
                    for oStep in oSteps:
                        print('********** Action', oStep.action)
                        #fun_PageSync(driver, oStep)
                        if(oStep.action == "SetText"):
                            oStatus = fun_Settext(request, driver, oStep, rep_1.pk)
                            print('********** Settext Status-', oStatus)
                            if not oStatus:
                                raise StopIteration
                        elif(oStep.action == "ButtonClick"):
                            oStatus = fun_Buttonclick(request, driver, oStep, rep_1.pk)
                            obj = Report_1.objects.get(id=rep_1.pk)
                            obj.actual_Value = oStep.input_Value
                            if not oStatus:
                                obj.status = False
                                obj.save()
                                raise StopIteration
                            
                        elif(oStep.action=="VerifyNonEditableText"):
                            oStatus = fun_VerifyNonEditableText(request, driver, oStep, rep_1.pk)
                            if not oStatus:
                                obj = Report_1.objects.get(id=rep_1.pk)
                                obj.status = False
                                obj.save()
                                raise StopIteration
                        elif(oStep.action == "SelectListItem"):
                            oStatus = fun_SelectListItem(request, driver, oStep, rep_1.pk)
                            if not oStatus:
                                obj = Report_1.objects.get(id=rep_1.pk)
                                obj.status = False
                                obj.save()
                                raise StopIteration
                        elif(oStep.action == "ElementClick"):
                            oStatus = fun_Buttonclick(request, driver, oStep, rep_1.pk)
                            obj = Report_1.objects.get(id=rep_1.pk)
                            obj.actual_Value = oStep.input_Value
                            if not oStatus:
                                obj.status = False
                                obj.save()
                                raise StopIteration
                        elif(oStep.action == "Sync"):
                            try:
                                print('##########SYNC')
                                element = WebDriverWait(driver, 10).until(
                                    EC.visibility_of_element_located((By.XPATH, oStep.object_Name))
                                )
                            except:
                                pass
                        
                            
                            
                            
                # except StopIteration:
                #     pass
                close_Browser(request, driver)  
                
            job_suite.execution = "Completed"
            job_suite.save()     
            #return redirect('/jobs/')           
        return redirect('/jobs/')
    except:
        pass



def data_param(request, id):
    print("request.method :", request.method)
    if request.method == "POST":
        data = request.POST
        var_Name = data.get('var_Name')
        var_Value = data.get('var_Value')
        var_AI = data.get('AI')
        ai_Prompt = data.get('ai_Prompt') 
        llm_Model = data.get('llm_Model')
        
        print('XXXXXXXXXXXXX', data.get('ai_Prompt') )
        
        hidIndex = data.get('hidIndex')
        print('hidIndex-->', hidIndex)
        Data_Param_1.objects.create(
            var_Name = var_Name,
            var_Value = var_Value,
            var_AI = var_AI,
            ai_Prompt = ai_Prompt,
            llm_Model = llm_Model,
            k_id = id
        )
        
        #get_API_completion(ai_Prompt)
        
        messages.success(request, "Row added successfullt")
        return redirect('/data-param/'+id+'/')
    #context = {"page":'Add Recepi'}
    # print(request.session['component_name'])
    queryset = Data_Param_1.objects.filter(k_id=id)
    queryset1 = KeyWord_1.objects.get(id = id)
    #print(queryset1.query)
    # if request.session['component_name']!=None:
    #     queryset = KeyWord_1.objects.filter(name=request.session['component_name'])
    #     #print(queryset.query)
    # else:
    #     queryset = KeyWord_1.objects.all()
        
    page = request.GET.get('page',1)
    paginator = Paginator(queryset, 10)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)
    
    
    
    # if request.GET.get("Search"):
    #     print(request.GET.get("Search"))
    #     queryset = queryset.filter(receipe_name__icontains = request.GET.get("Search")) 


    context = {'dataparam':queryset, 'component':queryset1}
    return render(request, 'DataParam.html', context)


def delete_dataparam(request, id, kid):
    queryset = Data_Param_1.objects.get(id=id)
    queryset.delete()
    #return HttpResponse("a")
    messages.error(request, "Param rows deleted successfullt")
    return redirect('/data-param/'+kid+'/')

def update_dataparam(request, id, kid):
    queryset = Data_Param_1.objects.get(id=id)
    queryset1 = KeyWord_1.objects.get(id = kid)
    
    if request.method == "POST":
        data = request.POST
        
        var_Name = data.get('var_Name')
        var_Value = data.get('var_Value')
        var_AI = data.get('AI')
        ai_Prompt = data.get('ai_Prompt') 
        llm_Model = data.get('llm_Model')
        hidIndex = data.get('hidIndex')
                
        queryset.var_Name = var_Name
        queryset.var_Value = var_Value
        queryset.var_AI = var_AI
        queryset.ai_Prompt = ai_Prompt
        queryset.llm_Model = llm_Model
               
        queryset.save()
        messages.success(request, "Data Param rows updated successfully")
        return redirect('/data-param/'+kid+'/')
    #if queryset.action.count
    print('///////////////////', queryset.var_Value)
    context = {'dataparam':queryset, 'component':queryset1}
    return render(request, 'update_dataParam.html', context)   

def get_API_completion(prompt): 
    print(prompt) 
    import os
    from openai import OpenAI

    client = OpenAI(
        api_key = os.getenv("OPENAI_API_KEY"),
    )

    completion = client.completions.create(
    model = "gpt-3.5-turbo-instruct",
    prompt = "Say this is a test",
    max_tokens = 7,
    temperature = 0
    )

    print(completion.choices[0].text.strip())