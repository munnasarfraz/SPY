from home.views import *
urlpatterns = [
]
