ANIMAL_CHOICES = (('DOG', 'DOG'),
                  ('cat', 'Cat'),
                  ('Horse', 'Horse'),
                  ('Rabbit', 'Rabbit'),                  
                  )

GENDER_CHOICES = (("Male","male"),
                  ("Female","Female"),
                  )