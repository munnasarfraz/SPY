from django.db import models
from django.contrib.auth.models import User
from .choices import ANIMAL_CHOICES, GENDER_CHOICES

# Create your models here.

class Category(models.Model)
    category_name = models.CharField(max_length=100)

class AnimalBreed(models.Model):
    animal_breed =  models.CharField(max_length=100)

class AnimalColor(models.Model):
    animal_color =  models.CharField(max_length=100)



class Animal(models.Model):
    animal_owner = models.ForeignKey(User, models.CASCADE, related_name="anmal")
    #animal_category = models.CharField(max_length=100, choices=ANIMAL_CHOICES)
    animal_category = models.models.ForeignKey(Category, models.CASCADE, related_name="anmal_category")
    animal_views = models.IntegerField(default=0)
    animal_likes = models.IntegerField(default=0)
    animal_name = models.CharField(max_length=100)
    animal_description = models.TextField()
    animal_slug = models.SlugField(max_length=1000, unique=True)
    animal_gender = models.CharField(choices=GENDER_CHOICES)
    animal_breed = models.ManyToManyField(AnimalBreed, null = True)
    animal_color = models.ManyToManyField(AnimalColor, null = True)

class AnimalLocation(models.Model):
    animal = models.ForeignKey(Animal, on_delete=models.CASCADE, related_name="animal_location") 
    location = models.CharField(max_length=100)


class AnimalImage(models.Model):
     animal = models.ForeignKey(Animal, on_delete=models.CASCADE, related_name="animal_location") 
     animal_image = models.ImageField(upload_to="animal")

    


    